/**
 * Animation Duration & 7-Day Trial System
 * "smaylik animatsiya yutib olsa sanaydi vaqt"
 * Har bir animatsiya yutib olinganda 7 kunlik vaqt sanashni boshlaydi.
 */

export interface AnimationTimeRemaining {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  totalMs: number;
  isActive: boolean;
  isPermanent: boolean;
}

const STORAGE_EXPIRIES_KEY = 'grand_anim_expiries';
const STORAGE_PERMANENT_KEY = 'grand_unlocked_animations';

export function getAnimationExpiries(): Record<string, number> {
  try {
    const raw = localStorage.getItem(STORAGE_EXPIRIES_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function getPermanentAnimations(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_PERMANENT_KEY);
    return raw ? JSON.parse(raw) : ['anim_salom'];
  } catch {
    return ['anim_salom'];
  }
}

export function isAnimationActive(animId: string): boolean {
  if (animId === 'anim_salom') return true; // Asosiy bepul salom
  const permanent = getPermanentAnimations();
  if (permanent.includes(animId)) return true;

  const expiries = getAnimationExpiries();
  const expiry = expiries[animId];
  return typeof expiry === 'number' && expiry > Date.now();
}

export function getAnimationTimeRemaining(animId: string): AnimationTimeRemaining {
  const permanent = getPermanentAnimations();
  if (animId === 'anim_salom' || permanent.includes(animId)) {
    return {
      days: 999,
      hours: 0,
      minutes: 0,
      seconds: 0,
      totalMs: Infinity,
      isActive: true,
      isPermanent: true,
    };
  }

  const expiries = getAnimationExpiries();
  const expiry = expiries[animId] || 0;
  const diff = Math.max(0, expiry - Date.now());

  if (diff <= 0) {
    return {
      days: 0,
      hours: 0,
      minutes: 0,
      seconds: 0,
      totalMs: 0,
      isActive: false,
      isPermanent: false,
    };
  }

  const days = Math.floor(diff / (24 * 3600 * 1000));
  const hours = Math.floor((diff % (24 * 3600 * 1000)) / (3600 * 1000));
  const minutes = Math.floor((diff % (3600 * 1000)) / (60 * 1000));
  const seconds = Math.floor((diff % (60 * 1000)) / 1000);

  return {
    days,
    hours,
    minutes,
    seconds,
    totalMs: diff,
    isActive: true,
    isPermanent: false,
  };
}

/**
 * Yutib olinganda yoki xarid qilinganda 7 kun (yoki berilgan kun) vaqt qo'shish
 */
export function grantAnimationDuration(animId: string, days: number = 7): number {
  const expiries = getAnimationExpiries();
  const now = Date.now();
  const currentExpiry = expiries[animId] || 0;
  
  // Agar hali muddati tugamagan bo'lsa, qolgan vaqt ustiga 7 kun qo'shiladi
  const baseTime = currentExpiry > now ? currentExpiry : now;
  const newExpiry = baseTime + days * 24 * 60 * 60 * 1000;

  expiries[animId] = newExpiry;
  localStorage.setItem(STORAGE_EXPIRIES_KEY, JSON.stringify(expiries));

  // Ochiq oynalarni xabardor qilish
  window.dispatchEvent(new CustomEvent('grand_anim_updated', { detail: { animId, newExpiry } }));

  return newExpiry;
}

export function unlockAnimationPermanently(animId: string): void {
  const permanent = getPermanentAnimations();
  if (!permanent.includes(animId)) {
    permanent.push(animId);
    localStorage.setItem(STORAGE_PERMANENT_KEY, JSON.stringify(permanent));
    window.dispatchEvent(new CustomEvent('grand_anim_updated', { detail: { animId, permanent: true } }));
  }
}
