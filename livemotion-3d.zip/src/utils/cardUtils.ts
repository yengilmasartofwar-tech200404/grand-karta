import { Card, DurakRank, StandardRank, Suit } from '../types/cards';

export const SUITS: { type: Suit; symbol: string; nameUz: string; isRed: boolean }[] = [
  { type: 'spades', symbol: '♠', nameUz: "Qarg'a", isRed: false },
  { type: 'hearts', symbol: '♥', nameUz: 'Yurak', isRed: true },
  { type: 'diamonds', symbol: '♦', nameUz: "G'isht", isRed: true },
  { type: 'clubs', symbol: '♣', nameUz: 'Chillak', isRed: false },
];

export const DURAK_RANKS: { rank: DurakRank; value: number }[] = [
  { rank: '6', value: 6 },
  { rank: '7', value: 7 },
  { rank: '8', value: 8 },
  { rank: '9', value: 9 },
  { rank: '10', value: 10 },
  { rank: 'J', value: 11 },
  { rank: 'Q', value: 12 },
  { rank: 'K', value: 13 },
  { rank: 'A', value: 14 },
];

export const STANDARD_RANKS: { rank: StandardRank; value: number }[] = [
  { rank: 'A', value: 1 },
  { rank: '2', value: 2 },
  { rank: '3', value: 3 },
  { rank: '4', value: 4 },
  { rank: '5', value: 5 },
  { rank: '6', value: 6 },
  { rank: '7', value: 7 },
  { rank: '8', value: 8 },
  { rank: '9', value: 9 },
  { rank: '10', value: 10 },
  { rank: 'J', value: 11 },
  { rank: 'Q', value: 12 },
  { rank: 'K', value: 13 },
];

export function createDurakDeck(): Card[] {
  const deck: Card[] = [];
  for (const s of SUITS) {
    for (const r of DURAK_RANKS) {
      deck.push({
        id: `${s.type}-${r.rank}`,
        suit: s.type,
        rank: r.rank,
        value: r.value,
        faceUp: false,
      });
    }
  }
  return shuffle(deck);
}

export function createStandardDeck(): Card[] {
  const deck: Card[] = [];
  for (const s of SUITS) {
    for (const r of STANDARD_RANKS) {
      deck.push({
        id: `${s.type}-${r.rank}`,
        suit: s.type,
        rank: r.rank,
        value: r.value,
        faceUp: false,
      });
    }
  }
  return shuffle(deck);
}

export function shuffle<T>(array: T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

export function getSuitInfo(suit: Suit) {
  return SUITS.find((s) => s.type === suit) || SUITS[0];
}

/**
 * Checks if a defending card can beat an attacking card in Durak
 */
export function canBeat(defenseCard: Card, attackCard: Card, trumpSuit: Suit): boolean {
  if (defenseCard.suit === attackCard.suit) {
    return defenseCard.value > attackCard.value;
  }
  if (defenseCard.suit === trumpSuit && attackCard.suit !== trumpSuit) {
    return true;
  }
  return false;
}

/**
 * Calculate Ochko (Blackjack / 21) hand score
 * In classic 21 Ochko:
 * Ace = 11 (or 1 if bust)
 * King = 4 (or 10 in standard 21)
 * Queen = 3 (or 10 in standard 21)
 * Jack = 2 (or 10 in standard 21)
 * 10 = 10, 9 = 9, 8 = 8, 7 = 7, 6 = 6
 * Two Aces = "Oltin Ochko" (Instant Win!)
 */
export function calculateOchkoScore(cards: Card[], isClassicOchko: boolean = true): { score: number; isGolden: boolean } {
  if (cards.length === 2 && cards[0].rank === 'A' && cards[1].rank === 'A') {
    return { score: 21, isGolden: true };
  }

  let total = 0;
  let aceCount = 0;

  for (const card of cards) {
    if (card.rank === 'A') {
      aceCount += 1;
      total += 11;
    } else if (card.rank === 'K') {
      total += isClassicOchko ? 4 : 10;
    } else if (card.rank === 'Q') {
      total += isClassicOchko ? 3 : 10;
    } else if (card.rank === 'J') {
      total += isClassicOchko ? 2 : 10;
    } else {
      total += parseInt(card.rank as string, 10) || 10;
    }
  }

  // Adjust Aces if bust
  while (total > 21 && aceCount > 0) {
    total -= 10;
    aceCount -= 1;
  }

  return { score: total, isGolden: false };
}

/**
 * 1000 (Ming) Card Game Specific Constants & Helpers
 * Total 24 cards: 9, J, Q, K, 10, A
 * Total card points: 120 points
 * Power: 9 < J < Q < K < 10 < A
 */
export const MING_CARD_POINTS: Record<string, number> = {
  '9': 0,
  'J': 2,
  'Q': 3,
  'K': 4,
  '10': 10,
  'A': 11,
};

export const MING_POWER: Record<string, number> = {
  '9': 1,
  'J': 2,
  'Q': 3,
  'K': 4,
  '10': 5,
  'A': 6,
};

export const MING_MARRIAGES: Record<Suit, { points: number; nameUz: string; icon: string; isRed: boolean }> = {
  spades: { points: 40, nameUz: "Qarg'a (Pika)", icon: '♠', isRed: false },
  clubs: { points: 60, nameUz: "Chillak / G'isht (Tref)", icon: '♣', isRed: false },
  diamonds: { points: 80, nameUz: "Qizil G'isht (Bubna)", icon: '♦', isRed: true },
  hearts: { points: 100, nameUz: 'Yurak (Cherva)', icon: '♥', isRed: true },
};

export function createMingDeck(): Card[] {
  const ranks: (DurakRank | StandardRank)[] = ['9', 'J', 'Q', 'K', '10', 'A'];
  const suits: Suit[] = ['spades', 'hearts', 'diamonds', 'clubs'];
  const deck: Card[] = [];

  for (const s of suits) {
    for (const r of ranks) {
      deck.push({
        id: `ming-${s}-${r}`,
        suit: s,
        rank: r,
        value: MING_POWER[r] || 0,
        faceUp: false,
      });
    }
  }
  return shuffle(deck);
}

/**
 * Check for Pererazdacha (Re-deal)
 * If any player has 4 Aces, 4 Kings, or 4 Queens in their hand
 */
export function checkMingPererazdacha(hand: Card[]): { triggered: boolean; reason: string } | null {
  const counts: Record<string, number> = { A: 0, K: 0, Q: 0 };
  for (const c of hand) {
    if (counts[c.rank] !== undefined) {
      counts[c.rank]++;
    }
  }

  if (counts['A'] >= 4) {
    return { triggered: true, reason: '4 ta Tuz (A)' };
  }
  if (counts['K'] >= 4) {
    return { triggered: true, reason: '4 ta Karol (K)' };
  }
  if (counts['Q'] >= 4) {
    return { triggered: true, reason: '4 ta Dama (Q)' };
  }
  return null;
}

/**
 * Check if player has a specific marriage (K and Q of suit)
 */
export function hasMarriageInHand(hand: Card[], suit: Suit): boolean {
  const hasK = hand.some((c) => c.suit === suit && c.rank === 'K');
  const hasQ = hand.some((c) => c.suit === suit && c.rank === 'Q');
  return hasK && hasQ;
}

/**
 * Check if player has any Red Marriage (♥ or ♦) required to bid over 120
 */
export function hasRedMarriage(hand: Card[]): boolean {
  return hasMarriageInHand(hand, 'hearts') || hasMarriageInHand(hand, 'diamonds');
}

/**
 * Get all available marriages in a hand
 */
export function getAvailableMarriages(hand: Card[]): Suit[] {
  const suits: Suit[] = ['hearts', 'diamonds', 'clubs', 'spades'];
  return suits.filter((s) => hasMarriageInHand(hand, s));
}

/**
 * Check if a card is legally playable according to 1000 rules:
 * 1. Must follow lead suit if hand contains cards of lead suit.
 * 2. If void of lead suit, must play active trump (kozır) if hand has trump.
 * 3. If void of lead suit and void of trump, any card can be discarded.
 */
export function isMingCardPlayable(
  card: Card,
  hand: Card[],
  leadCard: Card | null,
  activeTrump: Suit | null
): boolean {
  if (!leadCard) return true; // Leading player can play any card

  const hasLeadSuit = hand.some((c) => c.suit === leadCard.suit);
  if (hasLeadSuit) {
    return card.suit === leadCard.suit;
  }

  // Void of lead suit
  if (activeTrump) {
    const hasTrump = hand.some((c) => c.suit === activeTrump);
    if (hasTrump) {
      return card.suit === activeTrump;
    }
  }

  // Void of lead suit and void of trump: can play any card
  return true;
}

/**
 * Determine winner of a trick in 1000:
 * Returns the winning card object and index
 */
export function determineMingTrickWinner(
  trickCards: { playerId: string; card: Card }[],
  activeTrump: Suit | null
): { playerId: string; card: Card } {
  if (trickCards.length === 0) throw new Error('Empty trick');

  const leadCard = trickCards[0].card;
  let winningEntry = trickCards[0];

  for (let i = 1; i < trickCards.length; i++) {
    const entry = trickCards[i];
    const bestCard = winningEntry.card;
    const currentCard = entry.card;

    if (activeTrump) {
      // If current is trump and best is not trump -> current wins
      if (currentCard.suit === activeTrump && bestCard.suit !== activeTrump) {
        winningEntry = entry;
        continue;
      }
      // If both are trump -> higher power wins
      if (currentCard.suit === activeTrump && bestCard.suit === activeTrump) {
        if (MING_POWER[currentCard.rank] > MING_POWER[bestCard.rank]) {
          winningEntry = entry;
        }
        continue;
      }
    }

    // Neither is trump or trump wasn't played:
    // Only cards of leadSuit can beat the bestCard (if bestCard is leadSuit)
    if (bestCard.suit === leadCard.suit) {
      if (currentCard.suit === leadCard.suit && MING_POWER[currentCard.rank] > MING_POWER[bestCard.rank]) {
        winningEntry = entry;
      }
    }
  }

  return winningEntry;
}
