import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  onSnapshot, 
  query, 
  orderBy, 
  limit, 
  serverTimestamp,
  updateDoc
} from 'firebase/firestore';
import { 
  getAuth, 
  signInAnonymously, 
  onAuthStateChanged,
  User
} from 'firebase/auth';

// User provided Firebase configuration
export const firebaseConfig = {
  apiKey: "AIzaSyD7lFMqeIzoWZ-tuEByt-U1Zj6KaWFDr1s",
  authDomain: "bahadir-b268a.firebaseapp.com",
  projectId: "bahadir-b268a",
  storageBucket: "bahadir-b268a.firebasestorage.app",
  messagingSenderId: "397777392294",
  appId: "1:397777392294:web:956a8e5eeba66acc795a67",
  measurementId: "G-HMXK7YCJ41"
};

// Initialize Firebase safely
export const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);

export interface UserProfileData {
  uid: string;
  displayName: string;
  avatar: string;
  chips: number;
  level: number;
  xp?: number;
  claimedRewards?: number[];
  spinTickets?: number;
  lastSpinTime?: number;
  vipExpiresAt?: number;
  unlockedItems?: string[];
  durakWins: number;
  durakLosses: number;
  ochkoWins: number;
  ochkoLosses: number;
  solitaireWins: number;
  lastDailyBonus?: number;
  updatedAt?: unknown;
}

export interface MultiplayerRoom {
  id: string;
  code: string;
  gameType: 'durak' | 'ochko';
  hostUid: string;
  hostName: string;
  hostAvatar: string;
  guestUid?: string;
  guestName?: string;
  guestAvatar?: string;
  status: 'waiting' | 'playing' | 'finished';
  createdAt: unknown;
  gameState?: Record<string, unknown>;
}

/**
 * Sign in anonymously or retrieve current user
 */
export async function getOrCreateUser(initialName = "O'yinchi"): Promise<UserProfileData> {
  return new Promise((resolve) => {
    onAuthStateChanged(auth, async (user) => {
      let activeUser: User | null = user;
      if (!activeUser) {
        try {
          const cred = await signInAnonymously(auth);
          activeUser = cred.user;
        } catch (err) {
          console.warn("Firebase Auth fallback to local:", err);
        }
      }

      const localUid = activeUser?.uid || localStorage.getItem('grand_uid') || `user_${Date.now()}`;
      localStorage.setItem('grand_uid', localUid);

      const localProfile: UserProfileData = {
        uid: localUid,
        displayName: localStorage.getItem('grand_name') || initialName,
        avatar: localStorage.getItem('grand_avatar') || '👑',
        chips: parseInt(localStorage.getItem('grand_chips') || '1000', 10),
        level: parseInt(localStorage.getItem('grand_level') || '1', 10),
        xp: parseInt(localStorage.getItem('grand_xp') || '0', 10),
        spinTickets: parseInt(localStorage.getItem('grand_spin_tickets') || '3', 10),
        lastSpinTime: parseInt(localStorage.getItem('grand_last_spin') || '0', 10),
        vipExpiresAt: parseInt(localStorage.getItem('grand_vip_expires') || '0', 10),
        claimedRewards: JSON.parse(localStorage.getItem('grand_claimed_lvl') || '[]'),
        unlockedItems: JSON.parse(localStorage.getItem('grand_unlocked_items') || '[]'),
        durakWins: parseInt(localStorage.getItem('grand_durak_wins') || '0', 10),
        durakLosses: parseInt(localStorage.getItem('grand_durak_losses') || '0', 10),
        ochkoWins: parseInt(localStorage.getItem('grand_ochko_wins') || '0', 10),
        ochkoLosses: parseInt(localStorage.getItem('grand_ochko_losses') || '0', 10),
        solitaireWins: parseInt(localStorage.getItem('grand_solitaire_wins') || '0', 10),
      };

      try {
        const userRef = doc(db, 'users', localUid);
        const snap = await getDoc(userRef);
        if (snap.exists()) {
          const remoteData = snap.data() as UserProfileData;
          resolve({ ...localProfile, ...remoteData });
          return;
        } else {
          await setDoc(userRef, {
            ...localProfile,
            updatedAt: serverTimestamp(),
          });
        }
      } catch (err) {
        console.warn("Firestore sync warning (using local fallback):", err);
      }

      resolve(localProfile);
    });
  });
}

/**
 * Sync user profile to Firestore & LocalStorage
 */
export async function saveUserProfile(data: Partial<UserProfileData> & { uid: string }) {
  if (data.displayName) localStorage.setItem('grand_name', data.displayName);
  if (data.avatar) localStorage.setItem('grand_avatar', data.avatar);
  if (data.chips !== undefined) localStorage.setItem('grand_chips', data.chips.toString());
  if (data.level !== undefined) localStorage.setItem('grand_level', data.level.toString());
  if (data.xp !== undefined) localStorage.setItem('grand_xp', data.xp.toString());
  if (data.spinTickets !== undefined) localStorage.setItem('grand_spin_tickets', data.spinTickets.toString());
  if (data.lastSpinTime !== undefined) localStorage.setItem('grand_last_spin', data.lastSpinTime.toString());
  if (data.vipExpiresAt !== undefined) localStorage.setItem('grand_vip_expires', data.vipExpiresAt.toString());
  if (data.claimedRewards) localStorage.setItem('grand_claimed_lvl', JSON.stringify(data.claimedRewards));
  if (data.unlockedItems) localStorage.setItem('grand_unlocked_items', JSON.stringify(data.unlockedItems));
  if (data.durakWins !== undefined) localStorage.setItem('grand_durak_wins', data.durakWins.toString());
  if (data.durakLosses !== undefined) localStorage.setItem('grand_durak_losses', data.durakLosses.toString());
  if (data.ochkoWins !== undefined) localStorage.setItem('grand_ochko_wins', data.ochkoWins.toString());
  if (data.solitaireWins !== undefined) localStorage.setItem('grand_solitaire_wins', data.solitaireWins.toString());

  try {
    const userRef = doc(db, 'users', data.uid);
    await setDoc(userRef, { ...data, updatedAt: serverTimestamp() }, { merge: true });
  } catch (err) {
    console.warn("Firestore save fallback:", err);
  }
}

/**
 * Fetch top players for Leaderboard
 */
export async function getLeaderboard(): Promise<UserProfileData[]> {
  try {
    const q = query(collection(db, 'users'), orderBy('chips', 'desc'), limit(15));
    const snap = await getDocs(q);
    if (!snap.empty) {
      return snap.docs.map((d) => d.data() as UserProfileData);
    }
  } catch (err) {
    console.warn("Leaderboard fetch fallback:", err);
  }

  // Fallback realistic leader list
  return [
    { uid: 'bot1', displayName: 'Sherzod Xon', avatar: '🦁', chips: 18450, level: 12, durakWins: 42, durakLosses: 8, ochkoWins: 25, ochkoLosses: 6, solitaireWins: 14 },
    { uid: 'bot2', displayName: 'Alisher B.', avatar: '👑', chips: 14200, level: 9, durakWins: 31, durakLosses: 10, ochkoWins: 18, ochkoLosses: 7, solitaireWins: 9 },
    { uid: 'bot3', displayName: 'Malika Q.', avatar: '👸', chips: 9800, level: 7, durakWins: 24, durakLosses: 9, ochkoWins: 12, ochkoLosses: 5, solitaireWins: 21 },
    { uid: 'bot4', displayName: 'Jasur_King', avatar: '🐯', chips: 7650, level: 6, durakWins: 19, durakLosses: 12, ochkoWins: 14, ochkoLosses: 9, solitaireWins: 5 },
    { uid: 'bot5', displayName: 'Bobur_Card', avatar: '🦅', chips: 5400, level: 5, durakWins: 15, durakLosses: 11, ochkoWins: 9, ochkoLosses: 4, solitaireWins: 8 },
  ];
}

/**
 * Multiplayer Room Operations
 */
export async function createRoom(user: UserProfileData, gameType: 'durak' | 'ochko'): Promise<MultiplayerRoom> {
  const code = Math.random().toString(36).substring(2, 8).toUpperCase();
  const roomData: MultiplayerRoom = {
    id: `room_${code}`,
    code,
    gameType,
    hostUid: user.uid,
    hostName: user.displayName,
    hostAvatar: user.avatar,
    status: 'waiting',
    createdAt: Date.now(),
  };

  try {
    const roomRef = doc(db, 'rooms', roomData.id);
    await setDoc(roomRef, roomData);
  } catch (err) {
    console.warn("Create room fallback:", err);
  }

  return roomData;
}

export async function joinRoomByCode(code: string, user: UserProfileData): Promise<MultiplayerRoom | null> {
  try {
    const roomRef = doc(db, 'rooms', `room_${code.toUpperCase().trim()}`);
    const snap = await getDoc(roomRef);
    if (snap.exists()) {
      const room = snap.data() as MultiplayerRoom;
      if (room.status === 'waiting' && room.hostUid !== user.uid) {
        await updateDoc(roomRef, {
          guestUid: user.uid,
          guestName: user.displayName,
          guestAvatar: user.avatar,
          status: 'playing',
        });
        return {
          ...room,
          guestUid: user.uid,
          guestName: user.displayName,
          guestAvatar: user.avatar,
          status: 'playing',
        };
      }
      return room;
    }
  } catch (err) {
    console.warn("Join room fallback:", err);
  }
  return null;
}

export function subscribeToRoom(roomId: string, callback: (room: MultiplayerRoom | null) => void) {
  try {
    const roomRef = doc(db, 'rooms', roomId);
    return onSnapshot(roomRef, (snap) => {
      if (snap.exists()) {
        callback(snap.data() as MultiplayerRoom);
      } else {
        callback(null);
      }
    });
  } catch {
    return () => {};
  }
}
