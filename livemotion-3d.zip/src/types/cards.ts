export type Suit = 'spades' | 'hearts' | 'diamonds' | 'clubs';

export type DurakRank = '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K' | 'A';
export type StandardRank = 'A' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K';

export interface Card {
  id: string;
  suit: Suit;
  rank: DurakRank | StandardRank;
  value: number; // For sorting and game scoring
  faceUp?: boolean;
}

export interface DurakAttackPair {
  attack: Card;
  defense?: Card;
}

export type DurakRole = 'player' | 'bot';

export type GameMode = 'durak' | 'ochko' | 'solitaire' | 'ming';

export type MingRank = '9' | '10' | 'J' | 'Q' | 'K' | 'A';

export interface MingPlayer {
  id: 'player' | 'bot1' | 'bot2';
  name: string;
  avatar: string;
  hand: Card[];
  tricksWon: Card[][];
  tricksCount: number;
  cardPointsRound: number;
  marriagePointsRound: number;
  totalScore: number;
  minusesCount: number; // 0..3 (3 minuses = -120 pts)
  isOnBarrel: boolean; // >= 800 pts
  isLockedFromBidding: boolean; // <= -240 pts
  currentBid: number | 'PAS' | null;
  hasPassedBid: boolean;
  modelId?: string;
}

export interface GameStats {
  durakWins: number;
  durakLosses: number;
  ochkoWins: number;
  ochkoLosses: number;
  solitaireWins: number;
  chips: number;
}
