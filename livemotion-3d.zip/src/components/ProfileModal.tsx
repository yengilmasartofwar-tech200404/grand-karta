import React, { useState, useEffect, useRef } from 'react';
import { UserProfileData, saveUserProfile } from '../lib/firebase';
import { sounds } from '../utils/audio';
import confetti from 'canvas-confetti';
import { ThreeDCharacter } from './ThreeDCharacter';
import { 
  isAnimationActive, 
  getAnimationTimeRemaining, 
  grantAnimationDuration, 
  unlockAnimationPermanently,
  getAnimationExpiries,
  getPermanentAnimations 
} from '../utils/animationTrial';
import { 
  X, 
  Share2, 
  Coins, 
  Trophy, 
  Gift, 
  Check, 
  Copy, 
  Sparkles, 
  Award, 
  User, 
  Shield, 
  Palette, 
  Settings, 
  History, 
  RotateCw, 
  Ticket, 
  Flame, 
  Lock, 
  Star, 
  Download, 
  Smile, 
  Clock, 
  Hourglass,
  Crown
} from 'lucide-react';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfileData;
  onUpdateProfile: (updated: UserProfileData) => void;
  tableTheme: string;
  onChangeTableTheme: (theme: string) => void;
  cardBackTheme: string;
  onChangeCardBackTheme: (theme: string) => void;
  onOpenAvatarStudio?: () => void;
}

export const AVATAR_OPTIONS = [
  { icon: '👑', label: 'Qirol' },
  { icon: '👸', label: 'Malika' },
  { icon: '🦁', label: 'Sher' },
  { icon: '🐯', label: 'Yo\'lbars' },
  { icon: '🦅', label: 'Burgut' },
  { icon: '🃏', label: 'Joker' },
  { icon: '🥷', label: 'Ninja' },
  { icon: '🐺', label: 'Bo\'ri' },
  { icon: '🐉', label: 'Ajdaho' },
  { icon: '🛡️', label: 'Ritsar' },
  { icon: '🎩', label: 'Gentleman' },
  { icon: '💎', label: 'Olmos' }
];

export const AVATAR_FRAMES = [
  { id: 'bronze', name: 'Bronza Ramka', border: 'border-amber-700/80', minLvl: 1 },
  { id: 'silver', name: 'Kumush Ramka', border: 'border-slate-300 ring-2 ring-slate-300/40', minLvl: 3 },
  { id: 'gold', name: 'Oltin Ramka', border: 'border-amber-400 ring-2 ring-amber-400/60 shadow-lg shadow-amber-500/30', minLvl: 5 },
  { id: 'flame', name: 'Alanga Ramka', border: 'border-red-500 ring-2 ring-orange-500 shadow-lg shadow-red-500/40 animate-pulse', minLvl: 8 },
  { id: 'diamond', name: 'Olmos VIP', border: 'border-cyan-400 ring-2 ring-cyan-300 shadow-xl shadow-cyan-500/40', minLvl: 12 },
];

export const ACHIEVEMENTS = [
  { id: 'first_win', title: 'Birinchi G\'alaba', desc: 'Har qanday o\'yinda 1-marta yuting', reward: 200, icon: '🏆' },
  { id: 'durak_5', title: 'Durak Mahorati', desc: 'Durak o\'yinida 5 ta g\'alaba qozoning', reward: 500, icon: '⚔️', reqCount: 5, type: 'durak' },
  { id: 'durak_20', title: 'Qaroqchilar Qiroli', desc: 'Durakda 20 marta g\'olib bo\'ling', reward: 2000, icon: '👑', reqCount: 20, type: 'durak' },
  { id: 'ochko_golden', title: 'Oltin Ochko Egasi', desc: '21 Ochkoda A+A (Oltin Ochko) oling', reward: 1000, icon: '🔥' },
  { id: 'ochko_10', title: 'Kazinoning Qahramoni', desc: '21 Ochko o\'yinida 10 ta g\'alaba', reward: 1500, icon: '🎖️', reqCount: 10, type: 'ochko' },
  { id: 'solitaire_master', title: 'Pas\'yans Sehrgari', desc: 'Klondike pas\'yansini to\'liq yig\'ing', reward: 800, icon: '✨', reqCount: 1, type: 'solitaire' },
  { id: 'rich_5000', title: 'Katta Boylik', desc: 'Hisobingizda 5,000 tanga to\'plang', reward: 1000, icon: '💰' },
  { id: 'referral_friend', title: 'Do\'stlar Sardori', desc: 'O\'yin havolasini do\'stlaringizga ulashing', reward: 500, icon: '👥' },
  { id: 'spin_wheel', title: 'Omadli Qimorboz', desc: 'Omad g\'ildiragini aylantiring', reward: 300, icon: '🎡' },
];

export const TABLE_THEMES = [
  { id: 'green', name: 'Klassik Zumrad', class: 'from-emerald-950 via-emerald-900 to-slate-950', preview: 'bg-emerald-900' },
  { id: 'navy', name: 'Qirollik Ko\'k', class: 'from-blue-950 via-indigo-950 to-slate-950', preview: 'bg-indigo-900' },
  { id: 'ruby', name: 'To\'q Qizil Velvet', class: 'from-red-950 via-rose-950 to-slate-950', preview: 'bg-red-950' },
  { id: 'black', name: 'Tungi Qora Kazino', class: 'from-slate-950 via-zinc-900 to-black', preview: 'bg-zinc-900' },
];

// 3D Personaj Animatsiyalari
export interface CharacterAnimationItem {
  id: string;
  name: string;
  icon: string;
  emoji: string;
  price: number;
  desc: string;
  badge?: string;
  actionKey: string;
}

export const CHARACTER_ANIMATIONS: CharacterAnimationItem[] = [
  { id: 'anim_salom', name: 'Qo\'l Silkish (Salom)', icon: '👋', emoji: '👋', price: 0, desc: 'Do\'stona va samimiy qo\'l silkish', actionKey: 'anim_salom' },
  { id: 'anim_qarsak', name: 'Chempion Qarsagi', icon: '👏', emoji: '👏', price: 500, desc: 'Jonli qarsak chalish va olqishlash', badge: 'MASHHUR', actionKey: 'anim_qarsak' },
  { id: 'anim_zor', name: 'Bosh Barmog\'i (Zo\'r)', icon: '👍', emoji: '👍', price: 800, desc: 'O\'yinda ma\'qullash va barakalla ishorasi', actionKey: 'anim_zor' },
  { id: 'anim_qahqaha', name: 'Qahqaha Otib Kulish', icon: '😂', emoji: '😂', price: 1200, desc: 'Boshni orqaga tashlab, quvnoq kulish', badge: 'TOP', actionKey: 'anim_qahqaha' },
  { id: 'anim_oylash', name: 'Katta Strateg O\'ylashi', icon: '🤔', emoji: '🤔', price: 1500, desc: 'Barmog\'ini iyagiga qo\'yib chuqur mulohaza', actionKey: 'anim_oylash' },
  { id: 'anim_galaba_sakrash', name: 'G\'alaba Sakrashi', icon: '🏆', emoji: '🏆', price: 2000, desc: 'Qo\'llarini ko\'tarib g\'olibona sakrash', badge: 'VIP', actionKey: 'anim_galaba_sakrash' },
  { id: 'anim_salobat', name: 'Salobatli Ko\'zoynak', icon: '😎', emoji: '😎', price: 2500, desc: 'Ko\'zoynakni to\'g\'rilab xarizmatik jilmayish', actionKey: 'anim_salobat' },
  { id: 'anim_musht', name: 'Polvon Kuch Mushti', icon: '💪', emoji: '💪', price: 3000, desc: 'Kuch va matonat ramzi, bisseps ko\'rsatish', actionKey: 'anim_musht' },
  { id: 'anim_mehr', name: 'Mehr va Yurak', icon: '❤️', emoji: '❤️', price: 2200, desc: 'Qo\'llarni yurakka qo\'yib mehr bildirish', actionKey: 'anim_mehr' },
  { id: 'anim_hayrat', name: 'Dahshatli Hayrat (O-face)', icon: '😱', emoji: '😱', price: 2800, desc: 'Og\'zi ochilib orqaga tisarilish', actionKey: 'anim_hayrat' },
  { id: 'anim_gazab', name: 'G\'azab bilan Qaltirash', icon: '😡', emoji: '😡', price: 3500, desc: 'Mushtlarni tugib g\'azab bilan qarash', actionKey: 'anim_gazab' },
  { id: 'anim_yiglash', name: 'Achchiq Ko\'z Yoshi', icon: '😭', emoji: '😭', price: 1800, desc: 'Ko\'zlarni to\'sib yig\'lash harakati', actionKey: 'anim_yiglash' },
  { id: 'anim_kofe', name: 'Qaynoq Kofe Sip', icon: '☕', emoji: '☕', price: 1400, desc: 'Xushbo\'y kofe yoki choy ho\'plash', actionKey: 'anim_kofe' },
  { id: 'anim_tazim', name: 'Sharqona Ta\'zim (Rahmat)', icon: '🙏', emoji: '🙏', price: 2400, desc: 'Kaftlarni birlashtirib bosh egish', actionKey: 'anim_tazim' },
  { id: 'anim_raqs', name: 'Afsonaviy G\'alaba Raqsi', icon: '🕺', emoji: '🕺', price: 5000, desc: 'Ritmli g\'alaba raqsi va aylanish', badge: 'AFSONAVIY', actionKey: 'anim_raqs' },
  { id: 'anim_tanga_yomgiri', name: 'Tanga Sanash / Boylik', icon: '💸', emoji: '💸', price: 6000, desc: 'Qo\'llarini bir-biriga ishqab boylik hissi', badge: 'OLTIN', actionKey: 'anim_tanga_yomgiri' },
];

// 12 ta Ko'rinib Turuvchi Sektorli Omad G'ildiragi
export interface ProfileWheelSector {
  id: string;
  type: 'coins' | 'anim' | 'vip' | 'ticket';
  title: string;
  amount?: number;
  animId?: string;
  days?: number;
  icon: string;
  bgColor: string;
  textColor: string;
}

export const PROFILE_WHEEL_SECTORS: ProfileWheelSector[] = [
  { id: 'p1', type: 'coins', title: '500 Tanga', amount: 500, icon: '🪙', bgColor: '#1e293b', textColor: '#fef08a' },
  { id: 'p2', type: 'anim', title: 'Qarsak (7k)', animId: 'anim_qarsak', icon: '👏', bgColor: '#854d0e', textColor: '#fef08a' },
  { id: 'p3', type: 'coins', title: '1,000 Tanga', amount: 1000, icon: '💰', bgColor: '#0f766e', textColor: '#ccfbf1' },
  { id: 'p4', type: 'anim', title: 'Raqs (7k)', animId: 'anim_raqs', icon: '🕺', bgColor: '#9333ea', textColor: '#fae8ff' },
  { id: 'p5', type: 'vip', title: '3 Kun VIP', days: 3, icon: '👑', bgColor: '#701a75', textColor: '#f5d0fe' },
  { id: 'p6', type: 'coins', title: '2,000 Tanga', amount: 2000, icon: '🪙', bgColor: '#1e3a8a', textColor: '#bfdbfe' },
  { id: 'p7', type: 'anim', title: 'Kulish (7k)', animId: 'anim_qahqaha', icon: '😂', bgColor: '#c2410c', textColor: '#ffedd5' },
  { id: 'p8', type: 'coins', title: '3,500 Tanga', amount: 3500, icon: '💰', bgColor: '#047857', textColor: '#a7f3d0' },
  { id: 'p9', type: 'anim', title: 'G\'alaba (7k)', animId: 'anim_galaba_sakrash', icon: '🏆', bgColor: '#b45309', textColor: '#fef3c7' },
  { id: 'p10', type: 'ticket', title: '3x Bilet', amount: 3, icon: '🎟️', bgColor: '#334155', textColor: '#cbd5e1' },
  { id: 'p11', type: 'anim', title: 'Zo\'r (7k)', animId: 'anim_zor', icon: '👍', bgColor: '#134e4a', textColor: '#99f6e4' },
  { id: 'p12', type: 'coins', title: '50,000 JEKPOT', amount: 50000, icon: '💎', bgColor: '#dc2626', textColor: '#fee2e2' },
];

export interface CoinPackage {
  id: string;
  coins: number;
  bonusCoins: number;
  somPrice: number;
  somLabel: string;
  title: string;
  badge?: string;
  vipDays?: number;
}

export const COIN_PACKAGES: CoinPackage[] = [
  { id: 'pack_10k', coins: 10000, bonusCoins: 0, somPrice: 10000, somLabel: '10,000 so\'m', title: 'Boshlang\'ich Xalta' },
  { id: 'pack_35k', coins: 30000, bonusCoins: 5000, somPrice: 25000, somLabel: '25,000 so\'m', title: 'Ustalar Sandig\'i', badge: 'ENG FOYDALI 🔥' },
  { id: 'pack_90k', coins: 75000, bonusCoins: 15000, somPrice: 50000, somLabel: '50,000 so\'m', title: 'Qirollik Xazinasi', badge: 'VIP + 3 KUN 👑', vipDays: 3 },
  { id: 'pack_250k', coins: 200000, bonusCoins: 50000, somPrice: 100000, somLabel: '100,000 so\'m', title: 'Imperator Boyligi', badge: 'MEGA PACK 💎', vipDays: 7 },
  { id: 'pack_600k', coins: 500000, bonusCoins: 100000, somPrice: 200000, somLabel: '200,000 so\'m', title: 'Sulton Jackpoti', badge: 'CHEKSIZ VIP 🏆', vipDays: 30 },
];

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  profile,
  onUpdateProfile,
  tableTheme,
  onChangeTableTheme,
  cardBackTheme,
  onChangeCardBackTheme,
  onOpenAvatarStudio,
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'bonus' | 'animations' | 'shop' | 'achievements' | 'design' | 'settings'>('bonus');
  const [name, setName] = useState(profile.displayName);
  const [selectedAvatar, setSelectedAvatar] = useState(profile.avatar);
  const [selectedFrame, setSelectedFrame] = useState(localStorage.getItem('grand_frame') || 'bronze');
  const [copiedLink, setCopiedLink] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Per-animation real-time ticker ("smaylik animatsiya yutib olsa sanaydi vaqt")
  const [animTicker, setAnimTicker] = useState(0);

  useEffect(() => {
    const timerId = setInterval(() => {
      setAnimTicker((prev) => prev + 1);
    }, 1000);

    const handleAnimEvent = () => {
      setAnimTicker((prev) => prev + 1);
    };
    window.addEventListener('grand_anim_updated', handleAnimEvent);

    return () => {
      clearInterval(timerId);
      window.removeEventListener('grand_anim_updated', handleAnimEvent);
    };
  }, []);

  // Animation Live Preview
  const [previewAnimation, setPreviewAnimation] = useState<string>('anim_salom');
  const [previewTriggerKey, setPreviewTriggerKey] = useState<number>(0);

  // Wheel State (Fully Populated Visible SVG Wheel)
  const [spinning, setSpinning] = useState(false);
  const [wheelRotation, setWheelRotation] = useState(0);
  const [wheelResult, setWheelResult] = useState<string | null>(null);
  const [canSpinToday, setCanSpinToday] = useState(true);

  // Payment checkout modal state
  const [selectedPackageForCheckout, setSelectedPackageForCheckout] = useState<CoinPackage | null>(null);
  const [selectedPaymentProvider, setSelectedPaymentProvider] = useState<'payme' | 'click' | 'uzum' | 'visa'>('payme');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);

  // Promo code state
  const [promoCode, setPromoCode] = useState('');
  const [promoMessage, setPromoMessage] = useState<{ text: string; isError: boolean } | null>(null);

  // Daily calendar state
  const [claimedDays, setClaimedDays] = useState<number[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('grand_claimed_days') || '[1]');
    } catch {
      return [1];
    }
  });

  useEffect(() => {
    setName(profile.displayName);
    setSelectedAvatar(profile.avatar);
  }, [profile]);

  if (!isOpen) return null;

  const totalSectors = PROFILE_WHEEL_SECTORS.length;
  const sectorAngle = 360 / totalSectors;

  const handleSaveProfile = async () => {
    const updated = {
      ...profile,
      displayName: name.trim() || profile.displayName,
      avatar: selectedAvatar,
    };
    localStorage.setItem('grand_frame', selectedFrame);
    onUpdateProfile(updated);
    await saveUserProfile(updated);
    sounds.playChip();
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const handleShareWithFriends = async () => {
    sounds.playChip();
    const shareUrl = `${window.location.origin}${window.location.pathname}?ref=${profile.uid}`;
    const shareData = {
      title: "Grand Karta Klubi — Do'stlar bilan o'ynang!",
      text: `${profile.displayName} sizni Durak va 21 Ochko karta o'yinlariga taklif qilmoqda! Kiring va 1000 tanga oling:`,
      url: shareUrl,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch {
        navigator.clipboard.writeText(shareUrl);
      }
    } else {
      navigator.clipboard.writeText(shareUrl);
    }

    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);

    const updated = { ...profile, chips: profile.chips + 500 };
    onUpdateProfile(updated);
    saveUserProfile(updated);
    confetti({ particleCount: 70, spread: 60 });
  };

  // Wheel Spin: Lands accurately on one of the 12 visible wedges
  const handleSpinWheel = () => {
    if (spinning || !canSpinToday) return;
    sounds.playCardPlay();
    setSpinning(true);
    setWheelResult(null);

    const winningIndex = Math.floor(Math.random() * totalSectors);
    const chosen = PROFILE_WHEEL_SECTORS[winningIndex];

    const extraRounds = (6 + Math.floor(Math.random() * 3)) * 360;
    const targetSectorCenter = winningIndex * sectorAngle + sectorAngle / 2;
    const desiredAngle = (360 - targetSectorCenter) % 360;
    const finalRotation = wheelRotation + extraRounds + (desiredAngle - (wheelRotation % 360) + 360) % 360;

    setWheelRotation(finalRotation);

    setTimeout(() => {
      setSpinning(false);
      setWheelResult(`${chosen.title} ${chosen.icon}`);
      sounds.playWheelJackpot();
      confetti({ particleCount: 110, spread: 80, origin: { y: 0.6 } });
      setCanSpinToday(false);

      let newChips = profile.chips;
      let newVip = profile.vipExpiresAt || 0;
      let newTix = profile.spinTickets ?? 3;

      if (chosen.type === 'coins' && chosen.amount) {
        newChips += chosen.amount;
      } else if (chosen.type === 'anim' && chosen.animId) {
        grantAnimationDuration(chosen.animId, 7);
        setWheelResult(`7 KUNGA: ${chosen.title} ${chosen.icon} yutib olindi! Vaqt sanash boshlandi!`);
        sounds.playCheer();
      } else if (chosen.type === 'vip' && chosen.days) {
        const nowMs = Date.now();
        const base = newVip > nowMs ? newVip : nowMs;
        newVip = base + chosen.days * 24 * 60 * 60 * 1000;
      } else if (chosen.type === 'ticket' && chosen.amount) {
        newTix += chosen.amount;
      }

      const updated = {
        ...profile,
        chips: newChips,
        vipExpiresAt: newVip,
        spinTickets: newTix,
      };
      onUpdateProfile(updated);
      saveUserProfile(updated);
    }, 4500);
  };

  // Preview animation
  const handleSelectAnimation = (anim: CharacterAnimationItem) => {
    sounds.playChip();
    setPreviewAnimation(anim.actionKey);
    setPreviewTriggerKey((prev) => prev + 1);
  };

  // 7 kunga ijaraga / ochish (500 tanga)
  const handleRentAnimation = (anim: CharacterAnimationItem) => {
    sounds.playChip();
    const rentalCost = 500;
    if (profile.chips < rentalCost) {
      alert("Hisobingizda 500 tanga yetarli emas! O'yinlarda yutib yoki do'kondan tanga xarid qiling.");
      return;
    }
    const updated = { ...profile, chips: profile.chips - rentalCost };
    onUpdateProfile(updated);
    saveUserProfile(updated);
    grantAnimationDuration(anim.id, 7);
    sounds.playWin();
    confetti({ particleCount: 75, spread: 60 });
  };

  // Doimiyga xarid qilish
  const handleBuyAnimationPermanently = (anim: CharacterAnimationItem) => {
    sounds.playChip();
    if (profile.chips < anim.price) {
      setSelectedPackageForCheckout(COIN_PACKAGES[1]);
      return;
    }

    const newChips = profile.chips - anim.price;
    const updated = { ...profile, chips: newChips };
    onUpdateProfile(updated);
    saveUserProfile(updated);
    unlockAnimationPermanently(anim.id);

    sounds.playWin();
    confetti({ particleCount: 90, spread: 70 });
  };

  // Coin purchase checkout
  const handleCompleteCoinPurchase = (pack: CoinPackage) => {
    setIsProcessingPayment(true);
    sounds.playCardDeal();

    setTimeout(() => {
      setIsProcessingPayment(false);
      setSelectedPackageForCheckout(null);

      const totalCoinsAdded = pack.coins + pack.bonusCoins;
      let newChips = profile.chips + totalCoinsAdded;
      let newVip = profile.vipExpiresAt || 0;

      if (pack.vipDays) {
        const nowMs = Date.now();
        const base = newVip > nowMs ? newVip : nowMs;
        newVip = base + pack.vipDays * 24 * 60 * 60 * 1000;
      }

      const updated = {
        ...profile,
        chips: newChips,
        vipExpiresAt: newVip,
      };
      onUpdateProfile(updated);
      saveUserProfile(updated);

      sounds.playWin();
      confetti({ particleCount: 140, spread: 90 });
    }, 1200);
  };

  const handleApplyPromoCode = () => {
    const code = promoCode.trim().toUpperCase();
    if (!code) return;
    sounds.playChip();

    const usedCodes = JSON.parse(localStorage.getItem('grand_used_promos') || '[]');
    if (usedCodes.includes(code)) {
      setPromoMessage({ text: "Bu promo-kod allaqachon ishlatilgan!", isError: true });
      return;
    }

    let bonus = 0;
    if (code === 'KARTA2026' || code === 'KARTA') bonus = 1500;
    else if (code === 'BAHADIR' || code === 'YANGI') bonus = 2000;
    else if (code === 'UZBEKISTAN' || code === 'TOSHKENT') bonus = 3000;
    else if (code === 'VIP777' || code === 'JEKPOT') bonus = 5000;
    else {
      setPromoMessage({ text: "Noto'g'ri promo-kod! Boshqa kodni sinab ko'ring (Masalan: KARTA2026)", isError: true });
      return;
    }

    usedCodes.push(code);
    localStorage.setItem('grand_used_promos', JSON.stringify(usedCodes));
    sounds.playWin();
    confetti({ particleCount: 100, spread: 70 });

    const updated = { ...profile, chips: profile.chips + bonus };
    onUpdateProfile(updated);
    saveUserProfile(updated);
    setPromoMessage({ text: `Tabriklaymiz! +${bonus.toLocaleString()} tanga hisobingizga qo'shildi!`, isError: false });
    setPromoCode('');
  };

  const handleClaimDay = (day: number, reward: number) => {
    if (claimedDays.includes(day)) return;
    sounds.playWin();
    confetti({ particleCount: 80, spread: 60 });
    const nextClaimed = [...claimedDays, day];
    setClaimedDays(nextClaimed);
    localStorage.setItem('grand_claimed_days', JSON.stringify(nextClaimed));

    const updated = { ...profile, chips: profile.chips + reward };
    onUpdateProfile(updated);
    saveUserProfile(updated);
  };

  const handleExportData = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(profile, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `grand_karta_${profile.displayName}_backup.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const totalWins = profile.durakWins + profile.ochkoWins + profile.solitaireWins;
  const totalGames = totalWins + profile.durakLosses + profile.ochkoLosses;
  const winRate = totalGames > 0 ? Math.round((totalWins / totalGames) * 100) : 0;

  const getVipTier = () => {
    if (profile.level >= 12) return { name: 'Afsonaviy VIP', color: 'text-cyan-400', badge: 'bg-cyan-500/20 border-cyan-400' };
    if (profile.level >= 8) return { name: 'Platina VIP', color: 'text-purple-400', badge: 'bg-purple-500/20 border-purple-400' };
    if (profile.level >= 5) return { name: 'Oltin Usta', color: 'text-amber-400', badge: 'bg-amber-500/20 border-amber-400' };
    if (profile.level >= 3) return { name: 'Kumush O\'yinchi', color: 'text-slate-300', badge: 'bg-slate-500/20 border-slate-300' };
    return { name: 'Boshlang\'ich', color: 'text-emerald-400', badge: 'bg-emerald-500/20 border-emerald-400' };
  };

  const vipInfo = getVipTier();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-amber-500/40 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[94vh]">
        {/* Top Header Card */}
        <div className="px-5 sm:px-6 py-4 border-b border-slate-800 bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-2xl bg-slate-800 border-2 flex items-center justify-center text-2xl shadow-lg transition-transform ${
              AVATAR_FRAMES.find((f) => f.id === selectedFrame)?.border || 'border-amber-500'
            }`}>
              {selectedAvatar}
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-slate-100 font-serif">
                  {profile.displayName}
                </h2>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${vipInfo.badge} ${vipInfo.color}`}>
                  {vipInfo.name}
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono">
                LVL {profile.level} · Balans: <span className="text-amber-300 font-bold">{profile.chips.toLocaleString()} tanga</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                sounds.playChip();
                setActiveTab('shop');
              }}
              className="hidden xs:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 hover:scale-105 active:scale-95 transition-transform"
            >
              <Coins className="w-4 h-4 fill-slate-950" />
              <span>+ Tanga Sotib Olish</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 px-4 pt-3 border-b border-slate-800 bg-slate-950/60 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab('bonus')}
            className={`flex items-center gap-1.5 pb-2.5 px-3 text-xs font-bold transition-all border-b-2 whitespace-nowrap ${
              activeTab === 'bonus'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Gift className="w-3.5 h-3.5" />
            <span>Sovg'alar & G'ildirak</span>
          </button>

          <button
            onClick={() => setActiveTab('animations')}
            className={`flex items-center gap-1.5 pb-2.5 px-3 text-xs font-bold transition-all border-b-2 whitespace-nowrap ${
              activeTab === 'animations'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Smile className="w-3.5 h-3.5 text-amber-400" />
            <span>🎭 3D Animatsiyalar ({CHARACTER_ANIMATIONS.length})</span>
            <span className="px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 text-[10px] font-mono font-black">
              {CHARACTER_ANIMATIONS.filter(a => getAnimationTimeRemaining(a.id).isActive && !getAnimationTimeRemaining(a.id).isPermanent).length > 0
                ? `${CHARACTER_ANIMATIONS.filter(a => getAnimationTimeRemaining(a.id).isActive && !getAnimationTimeRemaining(a.id).isPermanent).length} TA FAOL`
                : "DO'KON"}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('shop')}
            className={`flex items-center gap-1.5 pb-2.5 px-3 text-xs font-bold transition-all border-b-2 whitespace-nowrap ${
              activeTab === 'shop'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Coins className="w-3.5 h-3.5 text-emerald-400" />
            <span>💰 Tanga Sotib Olish</span>
          </button>

          <button
            onClick={() => setActiveTab('profile')}
            className={`flex items-center gap-1.5 pb-2.5 px-3 text-xs font-bold transition-all border-b-2 whitespace-nowrap ${
              activeTab === 'profile'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Profil & Do'stlar</span>
          </button>

          <button
            onClick={() => setActiveTab('achievements')}
            className={`flex items-center gap-1.5 pb-2.5 px-3 text-xs font-bold transition-all border-b-2 whitespace-nowrap ${
              activeTab === 'achievements'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Trophy className="w-3.5 h-3.5" />
            <span>Yutuqlar ({ACHIEVEMENTS.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('design')}
            className={`flex items-center gap-1.5 pb-2.5 px-3 text-xs font-bold transition-all border-b-2 whitespace-nowrap ${
              activeTab === 'design'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Stol & Karta Movuti</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-1.5 pb-2.5 px-3 text-xs font-bold transition-all border-b-2 whitespace-nowrap ${
              activeTab === 'settings'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Sozlamalar</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 text-sm text-slate-300">

          {/* TAB 1: SOVG'ALAR & OMAD G'ILDIRAGI */}
          {activeTab === 'bonus' && (
            <div className="space-y-5">
              
              {/* 1. FULLY-POPULATED 12-SECTOR SVG WHEEL (Addresses user's "ichiga to'ldir, o'yinchi ko'rsin") */}
              <div className="bg-slate-950/70 p-4 sm:p-5 rounded-3xl border border-amber-500/30 flex flex-col items-center space-y-4 text-center relative overflow-hidden shadow-xl">
                <div className="flex items-center gap-2 text-amber-300 font-bold text-sm">
                  <RotateCw className="w-4 h-4 text-amber-400" />
                  <span>Omad G'ildiragi (Kunlik Bepul Aylantirish)</span>
                </div>
                <p className="text-xs text-slate-400 max-w-md">
                  G'ildirakni aylantiring: 3D Personaj Animatsiyalari, VIP Status, 50,000 gacha tangalar va jekpot!
                </p>

                {/* FULL VISIBLE 12-SECTOR SVG WHEEL */}
                <div className="relative w-72 h-72 sm:w-80 sm:h-80 my-2 flex items-center justify-center">
                  {/* Top Pointer Needle */}
                  <div className="absolute -top-3 z-30 flex flex-col items-center pointer-events-none drop-shadow-[0_4px_10px_rgba(245,158,11,0.7)]">
                    <div 
                      className="w-6 h-8 bg-gradient-to-b from-amber-300 via-amber-500 to-amber-600 shadow-2xl border-x-2 border-white animate-pulse"
                      style={{ clipPath: 'polygon(50% 100%, 0 0, 100% 0)' }}
                    />
                    <div className="w-3.5 h-3.5 rounded-full bg-amber-200 border-2 border-amber-600 -mt-7" />
                  </div>

                  {/* ROTATING SVG WHEEL WITH VISIBLE SLICES, ICONS & LABELS */}
                  <div className="w-full h-full rounded-full p-2 bg-gradient-to-br from-amber-500 via-yellow-600 to-amber-800 shadow-[0_0_40px_rgba(245,158,11,0.3)] border-4 border-amber-400/70">
                    <svg
                      viewBox="0 0 400 400"
                      style={{
                        transform: `rotate(${wheelRotation}deg)`,
                        transition: spinning ? 'transform 4.5s cubic-bezier(0.15, 0.95, 0.35, 1)' : 'none',
                      }}
                      className="w-full h-full rounded-full select-none"
                    >
                      {PROFILE_WHEEL_SECTORS.map((sector, i) => {
                        const startAngle = (i * sectorAngle) * (Math.PI / 180);
                        const endAngle = ((i + 1) * sectorAngle) * (Math.PI / 180);
                        const midAngle = ((i + 0.5) * sectorAngle) * (Math.PI / 180);

                        const x1 = 200 + 195 * Math.cos(startAngle);
                        const y1 = 200 + 195 * Math.sin(startAngle);
                        const x2 = 200 + 195 * Math.cos(endAngle);
                        const y2 = 200 + 195 * Math.sin(endAngle);

                        const textR = 135;
                        const tx = 200 + textR * Math.cos(midAngle);
                        const ty = 200 + textR * Math.sin(midAngle);
                        const textAngle = (i + 0.5) * sectorAngle;

                        return (
                          <g key={sector.id}>
                            <path
                              d={`M 200 200 L ${x1} ${y1} A 195 195 0 0 1 ${x2} ${y2} Z`}
                              fill={sector.bgColor}
                              stroke="#0f172a"
                              strokeWidth="2"
                            />
                            <g transform={`rotate(${textAngle}, ${tx}, ${ty})`}>
                              <text
                                x={tx}
                                y={ty - 10}
                                textAnchor="middle"
                                dominantBaseline="central"
                                fontSize="16"
                              >
                                {sector.icon}
                              </text>
                              <text
                                x={tx}
                                y={ty + 11}
                                textAnchor="middle"
                                dominantBaseline="central"
                                fill={sector.textColor}
                                fontSize="9"
                                fontWeight="bold"
                                letterSpacing="0.2px"
                              >
                                {sector.title}
                              </text>
                            </g>
                          </g>
                        );
                      })}

                      {/* Border pegs */}
                      {Array.from({ length: totalSectors * 2 }).map((_, idx) => {
                        const angle = (idx * (360 / (totalSectors * 2))) * (Math.PI / 180);
                        const px = 200 + 192 * Math.cos(angle);
                        const py = 200 + 192 * Math.sin(angle);
                        return (
                          <circle
                            key={idx}
                            cx={px}
                            cy={py}
                            r="2.5"
                            fill="#fef08a"
                            stroke="#854d0e"
                            strokeWidth="1"
                          />
                        );
                      })}
                    </svg>

                    {/* Center Spin Hub Button */}
                    <button
                      onClick={handleSpinWheel}
                      disabled={spinning || !canSpinToday}
                      className="absolute inset-0 m-auto w-20 h-20 rounded-full bg-gradient-to-br from-amber-400 via-amber-500 to-amber-700 text-slate-950 font-black flex flex-col items-center justify-center shadow-2xl border-4 border-slate-950 hover:scale-105 active:scale-95 transition-transform z-20 disabled:opacity-80 disabled:scale-100 cursor-pointer"
                    >
                      <RotateCw className={`w-5 h-5 stroke-[3] ${spinning ? 'animate-spin' : ''}`} />
                      <span className="text-[10px] font-extrabold uppercase mt-0.5 tracking-wider">
                        {spinning ? 'Aylanmoqda' : 'AYLANTIR'}
                      </span>
                    </button>
                  </div>
                </div>

                {wheelResult && (
                  <div className="px-5 py-2 rounded-2xl bg-gradient-to-r from-emerald-500/20 via-amber-500/20 to-emerald-500/20 border border-amber-400 text-amber-300 font-bold text-xs sm:text-sm animate-bounce shadow-lg">
                    Yutuq: {wheelResult}! 🎉
                  </div>
                )}

                <button
                  onClick={handleSpinWheel}
                  disabled={spinning || !canSpinToday}
                  className={`px-8 py-3 rounded-2xl font-black text-xs sm:text-sm uppercase tracking-wider transition-all shadow-lg ${
                    spinning || !canSpinToday
                      ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      : 'bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-amber-500/30 hover:scale-105 active:scale-95'
                  }`}
                >
                  {spinning ? 'Aylanmoqda...' : !canSpinToday ? 'Bugun olingan ✓' : 'Aylantirish (Tekin)'}
                </button>
              </div>

              {/* 2. OMAD G'ILDIRAGI YUTUQ VAQTI TIZIMI ("smaylik animatsiya yutib olsa sanaydi vaqt") */}
              <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-purple-950/60 via-slate-950 to-amber-950/40 border-2 border-amber-500/50 shadow-xl space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                      <Clock className="w-5 h-5 animate-spin" style={{ animationDuration: '6s' }} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-100 font-serif">
                          3D ANIMATSIYA YUTUQ TIZIMI (7 KUNLIK LITSENZIYA)
                        </span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full font-bold bg-amber-500 text-slate-950">
                          {CHARACTER_ANIMATIONS.filter(a => getAnimationTimeRemaining(a.id).isActive && !getAnimationTimeRemaining(a.id).isPermanent).length > 0 
                            ? `${CHARACTER_ANIMATIONS.filter(a => getAnimationTimeRemaining(a.id).isActive && !getAnimationTimeRemaining(a.id).isPermanent).length} TA YUTIB OLINGAN` 
                            : "G'ILDIRAKDA YUTING"}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Omad G'ildiragida yoki o'yinda animatsiya yutib olganingizda, o'sha animatsiya uchun 7 kunlik vaqt sanashni boshlaydi! Muddat tugagach qulflanadi.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Yutib olingan faol animatsiyalar ro'yxati va taymerlari */}
                {CHARACTER_ANIMATIONS.filter(a => getAnimationTimeRemaining(a.id).isActive && !getAnimationTimeRemaining(a.id).isPermanent).length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                    {CHARACTER_ANIMATIONS.filter(a => getAnimationTimeRemaining(a.id).isActive && !getAnimationTimeRemaining(a.id).isPermanent).map(anim => {
                      const st = getAnimationTimeRemaining(anim.id);
                      return (
                        <div key={anim.id} className="p-2.5 rounded-xl bg-slate-900/90 border border-emerald-500/50 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="text-2xl">{anim.icon}</span>
                            <div>
                              <div className="text-xs font-bold text-slate-100">{anim.name}</div>
                              <div className="text-[10px] text-emerald-400 font-semibold">7 kunlik yutuq faol</div>
                            </div>
                          </div>
                          <div className="flex items-center gap-1 font-mono text-xs font-black text-amber-300 bg-slate-950 px-2 py-1 rounded-lg border border-amber-500/30">
                            <Clock className="w-3.5 h-3.5 text-amber-400" />
                            <span>{st.days}k {String(st.hours).padStart(2, '0')}:{String(st.minutes).padStart(2, '0')}:{String(st.seconds).padStart(2, '0')}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800 text-center text-xs text-slate-400 flex items-center justify-center gap-2">
                    <span>🎡 Hozircha g'ildirakdan animatsiya yutib olinmagan. Yuqoridagi g'ildirakni aylantiring va 7 kunga yutib oling!</span>
                  </div>
                )}
              </div>

              {/* 3. 3D PERSONAJ ANIMATSIYALARI (PER-ANIMATION WON / LOCKED STATUS) */}
              <div className="bg-slate-950/70 p-4 sm:p-5 rounded-3xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">🎭</span>
                    <div>
                      <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2 font-serif">
                        <span>3D Personaj Animatsiyalari</span>
                        <span className="text-[10px] bg-amber-500 text-slate-950 font-black px-1.5 py-0.5 rounded font-sans">
                          YUTIB OLSA 7 KUN SANAYDI
                        </span>
                      </h3>
                      <p className="text-xs text-slate-400">
                        Har bir animatsiya yutib olinganda 7 kunlik orqaga hisoblash faollashadi.
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab('animations')}
                    className="text-xs text-amber-400 font-bold hover:underline"
                  >
                    Barcha 16 ta animatsiya →
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
                  {CHARACTER_ANIMATIONS.slice(0, 8).map((anim) => {
                    const status = getAnimationTimeRemaining(anim.id);
                    const isCurrentlyActive = status.isActive;

                    return (
                      <div
                        key={anim.id}
                        onClick={() => handleSelectAnimation(anim)}
                        className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between relative group ${
                          status.isPermanent
                            ? 'bg-emerald-950/20 border-emerald-500/40 hover:border-emerald-400'
                            : isCurrentlyActive
                            ? 'bg-purple-950/20 border-purple-500/50 hover:border-amber-400 ring-1 ring-purple-500/30'
                            : 'bg-slate-900 border-slate-800 hover:border-amber-400/60 opacity-90'
                        }`}
                      >
                        {anim.badge && (
                          <span className="absolute top-2 right-2 px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 font-black text-[9px] font-sans">
                            {anim.badge}
                          </span>
                        )}

                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-2xl group-hover:scale-125 transition-transform">{anim.icon}</span>
                            {status.isPermanent ? (
                              <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold border border-emerald-500/40" title="Doimiy">
                                ✓
                              </span>
                            ) : isCurrentlyActive ? (
                              <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[9px] font-mono font-bold border border-emerald-500/40 animate-pulse">
                                Faol
                              </span>
                            ) : (
                              <Lock className="w-4 h-4 text-amber-400 shrink-0" />
                            )}
                          </div>
                          <h4 className="text-xs font-bold text-slate-100">{anim.name}</h4>
                          <p className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">{anim.desc}</p>
                        </div>

                        <div className="mt-2.5 pt-2 border-t border-slate-800 flex flex-col gap-1.5 text-xs">
                          {status.isPermanent ? (
                            <span className="text-[11px] text-emerald-400 font-bold">Doimiy ochiq</span>
                          ) : isCurrentlyActive ? (
                            <div className="flex items-center gap-1 text-[10px] font-mono font-bold text-amber-300 bg-slate-950 px-1.5 py-0.5 rounded">
                              <Clock className="w-3 h-3 text-amber-400" />
                              <span>{status.days}k {String(status.hours).padStart(2, '0')}:{String(status.minutes).padStart(2, '0')}:{String(status.seconds).padStart(2, '0')}</span>
                            </div>
                          ) : (
                            <div className="flex items-center justify-between text-[11px] text-amber-300 font-mono font-bold">
                              <span>7k: 500 🪙</span>
                              <button 
                                onClick={(e) => { e.stopPropagation(); handleRentAnimation(anim); }}
                                className="px-2 py-0.5 rounded bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-slate-950 text-[10px] font-bold border border-amber-500/40 transition-colors"
                              >
                                Ochish
                              </button>
                            </div>
                          )}

                          <span className="text-[10px] text-slate-400 uppercase font-semibold text-center">
                            {isCurrentlyActive ? 'Jonli Sinash ▶' : 'Qulflangan'}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 4. PULGA TANGA SOTIB OLISH (COIN PACKAGES) BANNER */}
              <div className="bg-gradient-to-r from-emerald-950/50 via-slate-900 to-amber-950/40 p-4 sm:p-5 rounded-3xl border border-amber-500/30 flex items-center justify-between flex-wrap gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 flex items-center justify-center shadow-lg">
                    <Coins className="w-6 h-6 stroke-[2.5]" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-100 font-serif">
                      Tanga Yetarli Emasmi? Pulga Tanga Sotib Oling!
                    </h3>
                    <p className="text-xs text-slate-300">
                      Payme, Click, Uzum orqali tanga xarid qiling va barcha 3D animatsiyalarni doimiy qulfdan chiqaring.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    sounds.playChip();
                    setActiveTab('shop');
                  }}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/20 hover:scale-105 active:scale-95 transition-transform"
                >
                  Xarid Qilish →
                </button>
              </div>

              {/* 5. 7-Day Login Calendar */}
              <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <Gift className="w-4 h-4 text-amber-400" />
                    7 Kunlik Kirish Mukofoti
                  </span>
                  <span className="text-xs text-emerald-400 font-mono">Har kuni yangi sovg'a</span>
                </div>

                <div className="grid grid-cols-7 gap-1.5 text-center">
                  {[
                    { day: 1, reward: 100 },
                    { day: 2, reward: 250 },
                    { day: 3, reward: 400 },
                    { day: 4, reward: 600 },
                    { day: 5, reward: 800 },
                    { day: 6, reward: 1200 },
                    { day: 7, reward: 2500 },
                  ].map((d) => {
                    const isClaimed = claimedDays.includes(d.day);
                    return (
                      <button
                        key={d.day}
                        onClick={() => handleClaimDay(d.day, d.reward)}
                        className={`p-1.5 rounded-xl border flex flex-col items-center justify-between h-20 transition-all ${
                          isClaimed
                            ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
                            : 'bg-slate-900 border-slate-800 hover:border-amber-400 text-slate-200'
                        }`}
                      >
                        <span className="text-[10px] text-slate-400">{d.day}-kun</span>
                        <span className="text-base">{d.day === 7 ? '👑' : '🎁'}</span>
                        <span className="text-[10px] font-mono font-bold text-amber-300">
                          {isClaimed ? 'Olingan' : `+${d.reward}`}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 6. Promo Code Redemption */}
              <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 space-y-2.5">
                <div className="flex items-center gap-2 text-slate-100 font-bold text-xs uppercase tracking-wider">
                  <Ticket className="w-4 h-4 text-amber-400" />
                  Promo-kod Kiritish
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
                    placeholder="Masalan: KARTA2026, BAHADIR, VIP777"
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-slate-100 font-mono tracking-wider uppercase focus:outline-none focus:border-amber-400"
                  />
                  <button
                    onClick={handleApplyPromoCode}
                    className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-colors shadow-md shrink-0"
                  >
                    Faollashtirish
                  </button>
                </div>
                {promoMessage && (
                  <p className={`text-xs ${promoMessage.isError ? 'text-red-400' : 'text-emerald-400 font-semibold'}`}>
                    {promoMessage.text}
                  </p>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: 3D ANIMATSIYALAR DO'KONI (FULL VIEW WITH 7-DAY TIMER & LIVE PREVIEW) */}
          {activeTab === 'animations' && (
            <div className="space-y-4">
              {/* PER-ANIMATION WON COUNTDOWN BANNER ("smaylik animatsiya yutib olsa sanaydi vaqt") */}
              <div className="p-4 rounded-3xl bg-gradient-to-r from-purple-950/70 via-slate-900 to-amber-950/40 border border-amber-500/40 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xl">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-2xl">
                    ⏳
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                      <span>3D PERSONAJ ANIMATSIYALARI</span>
                      <span className="px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 text-[10px] font-black font-mono">
                        YUTSA 7 KUN SANAYDI
                      </span>
                    </h3>
                    <p className="text-xs text-slate-400">
                      Omad G'ildiragidan yutib olingan har bir animatsiya 7 kun davomida faol bo'lib, uning qolgan vaqti soniyalargacha hisoblab boriladi.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs font-mono">
                  <span className="text-slate-400">Yutib olingan faol:</span>
                  <span className="text-emerald-400 font-black">
                    {CHARACTER_ANIMATIONS.filter(a => getAnimationTimeRemaining(a.id).isActive && !getAnimationTimeRemaining(a.id).isPermanent).length} ta
                  </span>
                </div>
              </div>

              {/* 3D Character Live Preview Stage */}
              <div className="bg-slate-950 p-4 rounded-3xl border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-24 h-28 flex items-center justify-center shrink-0">
                    <ThreeDCharacter
                      name="Jonli Sinash"
                      activeEmoji={previewAnimation}
                      triggerKey={previewTriggerKey}
                      cardsCount={4}
                      nameplatePosition="none"
                      className="scale-90"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-widest block">
                      3D JONLI HARAKAT SINASH
                    </span>
                    <h4 className="text-base font-bold text-slate-100 font-serif">
                      Animatsiyani bosing va personajingizda ko'ring!
                    </h4>
                    <p className="text-xs text-slate-400">
                      Har bir harakat 3D formatda qo'llar, bosh, og'iz va yuz ifodalari bilan ijro etiladi.
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setActiveTab('shop')}
                  className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-black text-xs hover:bg-amber-400 shadow-md transition-all shrink-0"
                >
                  + Tanga Xarid Qilish
                </button>
              </div>

              {/* Full Grid of All 16+ 3D Animations */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {CHARACTER_ANIMATIONS.map((anim) => {
                  const status = getAnimationTimeRemaining(anim.id);
                  const isCurrentlyActive = status.isActive;
                  const isCurrentlyPreviewed = previewAnimation === anim.actionKey;

                  return (
                    <div
                      key={anim.id}
                      onClick={() => handleSelectAnimation(anim)}
                      className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between relative group ${
                        isCurrentlyPreviewed
                          ? 'ring-2 ring-amber-400 bg-amber-500/15 border-amber-400 shadow-lg'
                          : status.isPermanent
                          ? 'bg-slate-950/70 border-emerald-500/40 hover:border-emerald-300'
                          : isCurrentlyActive
                          ? 'bg-slate-950/70 border-purple-500/50 hover:border-amber-400 ring-1 ring-purple-500/30'
                          : 'bg-slate-950/50 border-slate-800 hover:border-amber-400/60 opacity-90'
                      }`}
                    >
                      {anim.badge && (
                        <span className="absolute top-2 right-2 px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 font-black text-[9px] font-sans">
                          {anim.badge}
                        </span>
                      )}

                      <div>
                        <div className="flex items-center gap-2 mb-1.5">
                          <span className="text-2xl group-hover:scale-125 transition-transform">{anim.icon}</span>
                          <div>
                            <h4 className="text-xs font-bold text-slate-100">{anim.name}</h4>
                            <span className="text-[10px] text-slate-400 line-clamp-1">{anim.desc}</span>
                          </div>
                        </div>
                      </div>

                      <div className="mt-3 pt-2 border-t border-slate-800 flex flex-col gap-1.5 text-xs">
                        {status.isPermanent ? (
                          <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
                            <Check className="w-3.5 h-3.5" /> Doimiy sizniki
                          </span>
                        ) : isCurrentlyActive ? (
                          <div className="flex items-center justify-between bg-slate-950 px-2 py-1 rounded-lg border border-emerald-500/40 text-[10px] font-mono font-bold text-amber-300">
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3 text-amber-400" />
                              <span>{status.days}k {String(status.hours).padStart(2, '0')}:{String(status.minutes).padStart(2, '0')}:{String(status.seconds).padStart(2, '0')}</span>
                            </span>
                            <span className="text-emerald-400 text-[9px]">FAOL</span>
                          </div>
                        ) : (
                          <div className="flex items-center justify-between gap-1 text-[10px]">
                            <button
                              onClick={(e) => { e.stopPropagation(); handleRentAnimation(anim); }}
                              className="px-2 py-1 rounded bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-slate-950 font-bold border border-amber-500/40 transition-colors flex items-center gap-0.5"
                            >
                              <span>7k: 500 🪙</span>
                            </button>
                            <button
                              onClick={(e) => { e.stopPropagation(); handleBuyAnimationPermanently(anim); }}
                              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold border border-slate-700 transition-colors"
                            >
                              {anim.price.toLocaleString()} 🪙
                            </button>
                          </div>
                        )}

                        <span className="text-[10px] text-slate-400 uppercase font-semibold text-center">
                          {isCurrentlyActive ? 'Jonli Sinash ▶' : 'Qulflangan'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: TANGA SOTIB OLISH (COIN PACKAGES & PAYMENT) */}
          {activeTab === 'shop' && (
            <div className="space-y-4">
              <div className="bg-gradient-to-r from-amber-950/60 via-slate-900 to-slate-950 p-4 sm:p-5 rounded-3xl border border-amber-500/40 flex items-center justify-between flex-wrap gap-3 shadow-xl">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xl">💳</span>
                    <h3 className="text-base sm:text-lg font-black text-amber-300 font-serif">
                      Rasmiy Tangalar Do'koni
                    </h3>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Hamyonbop paketlar orqali tanga xarid qiling, personajingizga yangi 3D animatsiyalar va VIP sovrinlar oling!
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400">To'lov usullari:</span>
                  <div className="flex items-center gap-1 text-[11px] font-bold font-mono">
                    <span className="px-2 py-0.5 rounded bg-blue-600 text-white">PAYME</span>
                    <span className="px-2 py-0.5 rounded bg-emerald-600 text-white">CLICK</span>
                    <span className="px-2 py-0.5 rounded bg-purple-600 text-white">UZUM</span>
                    <span className="px-2 py-0.5 rounded bg-amber-600 text-white">HUMO</span>
                  </div>
                </div>
              </div>

              {/* Package cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {COIN_PACKAGES.map((pack) => (
                  <div
                    key={pack.id}
                    className="p-4 rounded-3xl bg-slate-950/70 border border-slate-800 hover:border-amber-400 transition-all flex flex-col justify-between relative group shadow-lg"
                  >
                    {pack.badge && (
                      <span className="absolute -top-2.5 right-4 px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 text-[10px] font-black shadow">
                        {pack.badge}
                      </span>
                    )}

                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                          <Coins className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="text-sm font-bold text-slate-100">{pack.title}</h4>
                          <span className="text-xs font-mono font-bold text-amber-300">
                            {pack.coins.toLocaleString()} Tanga
                          </span>
                        </div>
                      </div>

                      <div className="space-y-1 text-xs text-slate-400 pt-1">
                        {pack.bonusCoins > 0 && (
                          <div className="text-emerald-400 font-semibold flex items-center gap-1">
                            <span>+ {pack.bonusCoins.toLocaleString()} Bonus Tanga!</span>
                          </div>
                        )}
                        {pack.vipDays && (
                          <div className="text-purple-300 font-semibold flex items-center gap-1">
                            <Crown className="w-3.5 h-3.5 text-amber-400" />
                            <span>{pack.vipDays} Kunlik VIP Status!</span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                      <span className="text-sm font-black font-mono text-slate-100">
                        {pack.somLabel}
                      </span>
                      <button
                        onClick={() => setSelectedPackageForCheckout(pack)}
                        className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 hover:scale-105 active:scale-95 transition-all"
                      >
                        Sotib Olish
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: PROFIL & STATISTIKA */}
          {activeTab === 'profile' && (
            <div className="space-y-4">
              {/* 3D Avatar Studiyasi Button */}
              {onOpenAvatarStudio && (
                <div
                  onClick={() => {
                    sounds.playChip();
                    onOpenAvatarStudio();
                  }}
                  className="cursor-pointer p-4 rounded-2xl bg-gradient-to-r from-indigo-900/60 via-purple-900/40 to-slate-900 border border-indigo-500/40 hover:border-amber-400 transition-all flex items-center justify-between group shadow-lg"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-indigo-500 text-white flex items-center justify-center text-xl shadow-md group-hover:scale-110 transition-transform">
                      🎭
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-slate-100 font-serif">3D Qahramon Studiyasi & Do'koni</span>
                        <span className="text-[10px] bg-amber-500 text-slate-950 font-black px-1.5 py-0.5 rounded">30 QAHRAMON</span>
                      </div>
                      <p className="text-xs text-slate-300 mt-0.5">Soch rangi, liboslar, tojlar va aksessuarlarni sozlash</p>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-amber-400 group-hover:translate-x-1 transition-transform">Ochish →</span>
                </div>
              )}

              {/* Nickname & Avatar & Frame Selection */}
              <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Avatarni Tanlang:
                  </span>
                  <span className="text-xs text-amber-400 font-mono">12 xil avatar</span>
                </div>

                <div className="grid grid-cols-6 sm:grid-cols-6 gap-2">
                  {AVATAR_OPTIONS.map((item) => (
                    <button
                      key={item.icon}
                      onClick={() => setSelectedAvatar(item.icon)}
                      className={`h-11 rounded-xl text-xl flex items-center justify-center transition-all ${
                        selectedAvatar === item.icon
                          ? 'bg-amber-500/25 border-2 border-amber-400 scale-105 shadow-md shadow-amber-500/30'
                          : 'bg-slate-900 border border-slate-800 hover:bg-slate-800'
                      }`}
                      title={item.label}
                    >
                      {item.icon}
                    </button>
                  ))}
                </div>

                {/* VIP Frames */}
                <div className="pt-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-2">
                    Profil Ramkasi:
                  </span>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {AVATAR_FRAMES.map((f) => {
                      const isUnlocked = profile.level >= f.minLvl;
                      return (
                        <button
                          key={f.id}
                          disabled={!isUnlocked}
                          onClick={() => setSelectedFrame(f.id)}
                          className={`p-2 rounded-xl text-xs font-semibold border flex items-center justify-between transition-all ${
                            selectedFrame === f.id
                              ? 'bg-amber-500/15 border-amber-400 text-amber-300'
                              : isUnlocked
                              ? 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850'
                              : 'bg-slate-950/60 border-slate-850 text-slate-600 cursor-not-allowed'
                          }`}
                        >
                          <span className="truncate">{f.name}</span>
                          {!isUnlocked && <Lock className="w-3 h-3 text-slate-600 shrink-0" />}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Nickname input */}
                <div className="pt-2 flex items-center gap-2">
                  <input
                    type="text"
                    value={name}
                    maxLength={20}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ismingizni yozing..."
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 focus:outline-none focus:border-amber-400"
                  />
                  <button
                    onClick={handleSaveProfile}
                    className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-colors shrink-0 shadow-md shadow-amber-500/20"
                  >
                    {saveSuccess ? 'Saqlandi! ✓' : 'Saqlash'}
                  </button>
                </div>
              </div>

              {/* Match Statistics & Win Rates */}
              <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <History className="w-4 h-4 text-amber-400" />
                    O'yinlar Ko'rsatkichi & Tarix
                  </h3>
                  <span className="text-xs font-mono text-emerald-400 font-bold">
                    {winRate}% Umumiy Yutuq
                  </span>
                </div>

                <div className="grid grid-cols-4 gap-2 text-center text-xs">
                  <div className="bg-slate-900 p-2 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Jami</span>
                    <span className="font-bold text-slate-100 font-mono text-sm">{totalGames}</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Durak</span>
                    <span className="font-bold text-emerald-400 font-mono text-sm">{profile.durakWins}W/{profile.durakLosses}L</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">21 Ochko</span>
                    <span className="font-bold text-emerald-400 font-mono text-sm">{profile.ochkoWins}W/{profile.ochkoLosses}L</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Pas'yans</span>
                    <span className="font-bold text-amber-300 font-mono text-sm">{profile.solitaireWins} ta</span>
                  </div>
                </div>
              </div>

              {/* Share with Friends */}
              <div className="bg-gradient-to-r from-amber-500/15 via-amber-600/10 to-transparent p-4 rounded-2xl border border-amber-500/30 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-amber-300 font-bold text-sm">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    Do'stlar Bilan Ulashish (+500 Tanga Bonus)
                  </div>
                  <span className="text-[11px] font-mono text-emerald-400 font-bold">Tekin tangalar</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Shaxsiy taklif havolangiz orqali do'stlaringizni taklif qiling va har bir do'stingiz uchun 500 tangaga ega bo'ling!
                </p>
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={handleShareWithFriends}
                    className="flex-1 py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md shadow-amber-500/20"
                  >
                    <Share2 className="w-4 h-4" />
                    Havolani Ulashish (+500 Tanga)
                  </button>
                  {copiedLink && (
                    <span className="text-xs text-emerald-400 flex items-center gap-1 font-semibold shrink-0">
                      <Check className="w-4 h-4" /> Nusxalandi!
                    </span>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: YUTUQLAR */}
          {activeTab === 'achievements' && (
            <div className="space-y-3">
              <div className="text-xs text-slate-400 flex items-center justify-between pb-1">
                <span>Vazifalarni bajaring va maxsus mukofotlarga ega bo'ling:</span>
                <span className="text-amber-400 font-mono font-bold">{ACHIEVEMENTS.length} ta yutuq</span>
              </div>

              <div className="space-y-2">
                {ACHIEVEMENTS.map((ach) => {
                  let isDone = false;
                  if (ach.id === 'first_win' && totalWins >= 1) isDone = true;
                  if (ach.id === 'durak_5' && profile.durakWins >= 5) isDone = true;
                  if (ach.id === 'durak_20' && profile.durakWins >= 20) isDone = true;
                  if (ach.id === 'ochko_10' && profile.ochkoWins >= 10) isDone = true;
                  if (ach.id === 'solitaire_master' && profile.solitaireWins >= 1) isDone = true;
                  if (ach.id === 'rich_5000' && profile.chips >= 5000) isDone = true;

                  return (
                    <div
                      key={ach.id}
                      className={`p-3 rounded-2xl border flex items-center justify-between gap-3 transition-all ${
                        isDone
                          ? 'bg-gradient-to-r from-emerald-950/40 to-slate-900 border-emerald-500/40 shadow-sm'
                          : 'bg-slate-950/50 border-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-xl shrink-0">
                          {ach.icon}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-slate-100">{ach.title}</span>
                            {isDone && (
                              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.2 rounded font-bold border border-emerald-500/40">
                                Bajarildi ✓
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-slate-400">{ach.desc}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800 text-amber-300 font-mono text-xs font-bold shrink-0">
                        <Coins className="w-3.5 h-3.5 text-amber-400" />
                        <span>+{ach.reward}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 6: STOL & KARTA MOVUTI */}
          {activeTab === 'design' && (
            <div className="space-y-4">
              <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 space-y-3">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
                  Karta Stoli Movuti (Felt Rangini Tanlang):
                </span>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {TABLE_THEMES.map((theme) => (
                    <button
                      key={theme.id}
                      onClick={() => {
                        sounds.playChip();
                        onChangeTableTheme(theme.id);
                      }}
                      className={`p-3 rounded-xl border flex flex-col items-center gap-2 transition-all ${
                        tableTheme === theme.id
                          ? 'border-amber-400 ring-2 ring-amber-400/40 bg-slate-900'
                          : 'border-slate-800 bg-slate-950 hover:bg-slate-900'
                      }`}
                    >
                      <div className={`w-full h-10 rounded-lg ${theme.preview} border border-white/20 shadow-inner`} />
                      <span className="text-xs font-semibold text-slate-200">{theme.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 space-y-3">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
                  Karta Orqa Foni (Card Back):
                </span>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {[
                    { id: 'royal_blue', name: 'Qirollik Ko\'k', color: 'from-blue-900 to-indigo-950' },
                    { id: 'ruby_red', name: 'Qirmizi Qizil', color: 'from-red-900 to-rose-950' },
                    { id: 'golden_gold', name: 'Oltin Naqsh', color: 'from-amber-700 to-yellow-950' },
                  ].map((cb) => (
                    <button
                      key={cb.id}
                      onClick={() => {
                        sounds.playCardPlay();
                        onChangeCardBackTheme(cb.id);
                      }}
                      className={`p-3 rounded-xl border flex flex-col items-center gap-2 transition-all ${
                        cardBackTheme === cb.id
                          ? 'border-amber-400 ring-2 ring-amber-400/40 bg-slate-900'
                          : 'border-slate-800 bg-slate-950 hover:bg-slate-900'
                      }`}
                    >
                      <div className={`w-12 h-16 rounded-md bg-gradient-to-br ${cb.color} border border-amber-300/40 flex items-center justify-center text-amber-300 font-serif text-sm shadow`}>
                        👑
                      </div>
                      <span className="text-xs font-semibold text-slate-200">{cb.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 7: SOZLAMALAR & ZAXIRA */}
          {activeTab === 'settings' && (
            <div className="space-y-4">
              <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 space-y-3">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
                  O'yin Qulayliklari:
                </span>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                    <div>
                      <span className="text-xs font-semibold text-slate-200 block">Web Audio Ovoz Effektlari</span>
                      <span className="text-[11px] text-slate-400">Kartalar urilishi, yutuq sadolari</span>
                    </div>
                    <span className="text-xs font-bold text-emerald-400">Yoqilgan ✓</span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                    <div>
                      <span className="text-xs font-semibold text-slate-200 block">Firebase Bulutli Saqlash</span>
                      <span className="text-[11px] text-slate-400">Sizning tangalaringiz doim xavfsiz</span>
                    </div>
                    <span className="text-xs font-bold text-emerald-400">Faol ✓</span>
                  </div>
                </div>
              </div>

              <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 space-y-2.5">
                <div className="flex items-center gap-2 text-slate-200 font-bold text-xs uppercase tracking-wider">
                  <Download className="w-4 h-4 text-amber-400" />
                  Ma'lumotlarni Zaxiralash (Export)
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  O'yin statistikangiz va tangalaringizni fayl ko'rinishida qurilmangizga yuklab oling.
                </p>
                <button
                  onClick={handleExportData}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-2 transition-colors border border-slate-700"
                >
                  <Download className="w-4 h-4" />
                  JSON Faylni Yuklab Olish
                </button>
              </div>
            </div>
          )}

        </div>

        {/* PAYMENT CHECKOUT MODAL */}
        {selectedPackageForCheckout && (
          <div className="absolute inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
            <div className="w-full max-w-md bg-slate-900 border-2 border-amber-500 rounded-3xl p-6 text-center space-y-4 shadow-2xl">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-3xl">
                💳
              </div>

              <div>
                <h3 className="text-lg font-black text-slate-100 font-serif">
                  Tangalar Xaridini Tasdiqlash
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Paket: <strong className="text-amber-300">{selectedPackageForCheckout.title}</strong>
                </p>
              </div>

              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-left space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">Asosiy tangalar:</span>
                  <span className="font-mono font-bold text-amber-300">
                    +{selectedPackageForCheckout.coins.toLocaleString()} tanga
                  </span>
                </div>
                {selectedPackageForCheckout.bonusCoins > 0 && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">Sovg'a bonus:</span>
                    <span className="font-mono font-bold text-emerald-400">
                      +{selectedPackageForCheckout.bonusCoins.toLocaleString()} tanga
                    </span>
                  </div>
                )}
                {selectedPackageForCheckout.vipDays && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">VIP Status:</span>
                    <span className="font-mono font-bold text-purple-300">
                      +{selectedPackageForCheckout.vipDays} kun VIP
                    </span>
                  </div>
                )}
                <div className="pt-2 border-t border-slate-800 flex justify-between text-sm">
                  <span className="font-bold text-slate-200">To'lov summasi:</span>
                  <span className="font-mono font-black text-amber-400">
                    {selectedPackageForCheckout.somLabel}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-2">
                {[
                  { id: 'payme', label: 'PAYME', color: 'bg-blue-600' },
                  { id: 'click', label: 'CLICK', color: 'bg-emerald-600' },
                  { id: 'uzum', label: 'UZUM', color: 'bg-purple-600' },
                  { id: 'visa', label: 'HUMO', color: 'bg-amber-600' },
                ].map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setSelectedPaymentProvider(p.id as any)}
                    className={`py-2 rounded-xl text-[11px] font-black text-white border transition-all ${
                      selectedPaymentProvider === p.id
                        ? `${p.color} ring-2 ring-white/50 border-white scale-105`
                        : 'bg-slate-800 border-slate-700 opacity-60 hover:opacity-100'
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  onClick={() => setSelectedPackageForCheckout(null)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
                >
                  Bekor qilish
                </button>
                <button
                  onClick={() => handleCompleteCoinPurchase(selectedPackageForCheckout)}
                  disabled={isProcessingPayment}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/30 flex items-center justify-center gap-1.5 transition-all"
                >
                  {isProcessingPayment ? (
                    <span>To'lanmoqda...</span>
                  ) : (
                    <>
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>To'lash ({selectedPackageForCheckout.somLabel})</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/80 flex justify-between items-center text-xs text-slate-400">
          <span>Grand Karta Klubi VIP Profil v3.9</span>
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 transition-colors shadow-md"
          >
            Tugatish (Yopish)
          </button>
        </div>
      </div>
    </div>
  );
};
