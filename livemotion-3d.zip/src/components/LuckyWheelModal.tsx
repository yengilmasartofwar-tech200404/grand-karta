import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Sparkles, 
  Coins, 
  Crown, 
  Ticket, 
  Gift, 
  RotateCw, 
  Check, 
  Flame, 
  Award,
  Zap,
  Clock
} from 'lucide-react';
import { UserProfileData } from '../lib/firebase';
import { sounds } from '../utils/audio';
import confetti from 'canvas-confetti';

export interface WheelSector {
  id: string;
  type: 'coins' | '3d_item' | 'vip' | 'ticket' | 'free_spin';
  title: string;
  sub: string;
  amount?: number;
  itemKey?: string;
  icon: string;
  bgColor: string;
  textColor: string;
  badge?: string;
}

// Exactly satisfying user request:
// - 10 ta tanga yutuqlari (500, 1000, 2000, 3500, 5000, 7500, 10000, 15000, 25000, 50000 Jackpot)
// - 2 ta 3D mukofot (3D Oltin Toj & Zanjir, 3D Afsonaviy Qahramon)
// - 3 kunga VIP Abuna
// - Boshqa yutuqlar (3x Bilet, Bepul Spin, Oltin Karta)
export const WHEEL_SECTORS: WheelSector[] = [
  {
    id: 'c1',
    type: 'coins',
    title: '500 Tanga',
    sub: 'Tanga',
    amount: 500,
    icon: '🪙',
    bgColor: '#1e293b',
    textColor: '#fef08a',
  },
  {
    id: '3d_1',
    type: '3d_item',
    title: '3D Oltin Toj',
    sub: '3D Buyum',
    itemKey: 'item_gold_crown',
    icon: '👑',
    bgColor: '#854d0e',
    textColor: '#fef08a',
    badge: '3D MUKOFOT',
  },
  {
    id: 'c2',
    type: 'coins',
    title: '1,000 Tanga',
    sub: 'Tanga',
    amount: 1000,
    icon: '💰',
    bgColor: '#0f766e',
    textColor: '#ccfbf1',
  },
  {
    id: 'vip_3d',
    type: 'vip',
    title: '3 Kun VIP',
    sub: 'Abuna (3 kun)',
    amount: 3, // 3 days
    icon: '💎',
    bgColor: '#701a75',
    textColor: '#f5d0fe',
    badge: 'VIP ABUNA',
  },
  {
    id: 'c3',
    type: 'coins',
    title: '2,000 Tanga',
    sub: 'Tanga',
    amount: 2000,
    icon: '🪙',
    bgColor: '#1e3a8a',
    textColor: '#bfdbfe',
  },
  {
    id: 'ticket_3',
    type: 'ticket',
    title: '3x Bilet',
    sub: 'Biletlar',
    amount: 3,
    icon: '🎟️',
    bgColor: '#c2410c',
    textColor: '#ffedd5',
  },
  {
    id: 'c4',
    type: 'coins',
    title: '3,500 Tanga',
    sub: 'Tanga',
    amount: 3500,
    icon: '💰',
    bgColor: '#047857',
    textColor: '#a7f3d0',
  },
  {
    id: '3d_2',
    type: '3d_item',
    title: '3D Qahramon',
    sub: '3D Qiyofa',
    itemKey: 'char_legend_sultan',
    icon: '🎭',
    bgColor: '#9333ea',
    textColor: '#fae8ff',
    badge: '3D PERSANAJ',
  },
  {
    id: 'c5',
    type: 'coins',
    title: '5,000 Tanga',
    sub: 'Tanga',
    amount: 5000,
    icon: '💎',
    bgColor: '#b45309',
    textColor: '#fef3c7',
  },
  {
    id: 'free_spin',
    type: 'free_spin',
    title: 'Qayta Spin',
    sub: 'Bepul',
    icon: '🔄',
    bgColor: '#334155',
    textColor: '#cbd5e1',
  },
  {
    id: 'c6',
    type: 'coins',
    title: '7,500 Tanga',
    sub: 'Tanga',
    amount: 7500,
    icon: '🪙',
    bgColor: '#134e4a',
    textColor: '#99f6e4',
  },
  {
    id: 'c7',
    type: 'coins',
    title: '10,000 Tanga',
    sub: 'Tanga',
    amount: 10000,
    icon: '💰',
    bgColor: '#312e81',
    textColor: '#c7d2fe',
  },
  {
    id: 'c8',
    type: 'coins',
    title: '15,000 Tanga',
    sub: 'Tanga',
    amount: 15000,
    icon: '🌟',
    bgColor: '#831843',
    textColor: '#fbcfe8',
  },
  {
    id: 'c9',
    type: 'coins',
    title: '25,000 Tanga',
    sub: 'Tanga',
    amount: 25000,
    icon: '🔥',
    bgColor: '#9a3412',
    textColor: '#fed7aa',
    badge: 'SUPER',
  },
  {
    id: 'card_gold',
    type: '3d_item',
    title: 'Oltin Karta',
    sub: '3D Dizayn',
    itemKey: 'skin_card_gold',
    icon: '🃏',
    bgColor: '#a16207',
    textColor: '#fef08a',
  },
  {
    id: 'c10_jackpot',
    type: 'coins',
    title: '50,000 JACKPOT',
    sub: 'Mega Jackpot',
    amount: 50000,
    icon: '🏆',
    bgColor: '#dc2626',
    textColor: '#fee2e2',
    badge: 'JACKPOT',
  },
];

interface LuckyWheelModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfileData;
  onUpdateProfile: (updated: UserProfileData) => void;
}

export const LuckyWheelModal: React.FC<LuckyWheelModalProps> = ({
  isOpen,
  onClose,
  profile,
  onUpdateProfile,
}) => {
  const [rotation, setRotation] = useState<number>(0);
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [wonSector, setWonSector] = useState<WheelSector | null>(null);
  const [showWinModal, setShowWinModal] = useState<boolean>(false);
  const wheelRef = useRef<SVGSVGElement | null>(null);
  const lastTickAngleRef = useRef<number>(0);

  const totalSectors = WHEEL_SECTORS.length;
  const sectorAngle = 360 / totalSectors;

  // Spin availability: 1 free spin every 24h, or use tickets, or 500 chips
  const now = Date.now();
  const lastSpinTime = profile.lastSpinTime || 0;
  const isDailyFree = now - lastSpinTime > 24 * 60 * 60 * 1000;
  const ticketsCount = profile.spinTickets ?? 3;
  const spinCost = 500;

  // VIP active?
  const isVipActive = (profile.vipExpiresAt || 0) > now;

  const handleSpin = () => {
    if (isSpinning) return;

    // Check payment / ticket
    if (!isDailyFree && ticketsCount <= 0 && profile.chips < spinCost) {
      alert("Aylantirish uchun tangalar yoki bilet yetarli emas! (500 tanga talab qilinadi)");
      return;
    }

    sounds.playCardPlay();
    setIsSpinning(true);
    setWonSector(null);
    setShowWinModal(false);

    // Deduct ticket or chips if not daily free
    let updatedChips = profile.chips;
    let updatedTickets = ticketsCount;
    let newLastSpin = profile.lastSpinTime;

    if (isDailyFree) {
      newLastSpin = now;
    } else if (ticketsCount > 0) {
      updatedTickets -= 1;
    } else {
      updatedChips -= spinCost;
    }

    // Pick random sector (weighted so 3D items and Jackpot are truly rewarding)
    const winningIndex = Math.floor(Math.random() * totalSectors);
    const targetSector = WHEEL_SECTORS[winningIndex];

    // Compute rotation: multiple full rounds (6 to 9 full turns) + exact angle to align needle at top (270 deg / -90 deg)
    const extraRounds = (6 + Math.floor(Math.random() * 3)) * 360;
    // Needle is at top (270 deg in SVG polar, or top point). Sector center in SVG = i * sectorAngle + sectorAngle / 2.
    // SVG needle is at 0 degrees (top / 12 o'clock).
    const targetSectorCenter = winningIndex * sectorAngle + sectorAngle / 2;
    // To bring targetSectorCenter to 0 (top), rotation must satisfy: (finalRotation + targetSectorCenter) % 360 == 0
    const desiredAngle = (360 - targetSectorCenter) % 360;
    const finalRotation = rotation + extraRounds + (desiredAngle - (rotation % 360) + 360) % 360;

    // Sound ticks during spin
    let animId: number;
    const startTime = performance.now();
    const duration = 5000; // 5 seconds spin

    const animateTicks = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(1, elapsed / duration);
      // Ease out cubic
      const easeOut = 1 - Math.pow(1 - progress, 3);
      const currentRot = rotation + (finalRotation - rotation) * easeOut;

      // Play tick sound every time a sector line passes top
      if (Math.abs(currentRot - lastTickAngleRef.current) >= sectorAngle) {
        sounds.playWheelTick();
        lastTickAngleRef.current = currentRot;
      }

      if (progress < 1) {
        animId = requestAnimationFrame(animateTicks);
      }
    };

    animId = requestAnimationFrame(animateTicks);
    setRotation(finalRotation);

    setTimeout(() => {
      cancelAnimationFrame(animId);
      setIsSpinning(false);
      setWonSector(targetSector);
      setShowWinModal(true);
      sounds.playWheelJackpot();
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.55 },
      });

      // Apply reward
      let newChips = updatedChips;
      let newVip = profile.vipExpiresAt || 0;
      let newTix = updatedTickets;
      const newItems = [...(profile.unlockedItems || [])];

      if (targetSector.type === 'coins' && targetSector.amount) {
        newChips += targetSector.amount;
      } else if (targetSector.type === '3d_item' && targetSector.itemKey) {
        if (!newItems.includes(targetSector.itemKey)) {
          newItems.push(targetSector.itemKey);
        }
        newChips += 2000; // extra bonus
      } else if (targetSector.type === 'vip' && targetSector.amount) {
        const cur = newVip > now ? newVip : now;
        newVip = cur + targetSector.amount * 24 * 60 * 60 * 1000;
        newChips += 5000;
      } else if (targetSector.type === 'ticket' && targetSector.amount) {
        newTix += targetSector.amount;
      } else if (targetSector.type === 'free_spin') {
        newTix += 1;
      }

      onUpdateProfile({
        ...profile,
        chips: newChips,
        vipExpiresAt: newVip,
        spinTickets: newTix,
        unlockedItems: newItems,
        lastSpinTime: newLastSpin,
      });
    }, duration);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl bg-slate-950 border border-amber-500/50 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-slate-100">
        
        {/* HEADER */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-950 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-slate-950 shadow-lg shadow-amber-500/20">
              <RotateCw className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black font-serif text-amber-300">
                  Omad G'ildiragi
                </h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">
                  LUCKY SPIN
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Aylantiring: 10 ta tanga yutuqlari, 3D aksessuarlar, 3 kunlik VIP va boshqa sovg'alar!
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              if (isSpinning) return;
              sounds.playChip();
              onClose();
            }}
            disabled={isSpinning}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors disabled:opacity-40"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* STATUS STRIP */}
        <div className="px-4 py-2 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-amber-300">
              <Coins className="w-4 h-4 text-amber-400" />
              <span>{profile.chips.toLocaleString()} Tanga</span>
            </div>
            <div className="flex items-center gap-1.5 text-cyan-300">
              <Ticket className="w-4 h-4 text-cyan-400" />
              <span>{ticketsCount} Bilet</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isVipActive && (
              <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/40 font-bold flex items-center gap-1">
                <Crown className="w-3 h-3 text-amber-300 fill-amber-300" />
                VIP FAOL
              </span>
            )}
            {isDailyFree ? (
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">
                ✨ KUNLIK BEPUL SPIN!
              </span>
            ) : (
              <span className="text-slate-400">
                1 Spin = {ticketsCount > 0 ? '1 Bilet' : '500 Tanga'}
              </span>
            )}
          </div>
        </div>

        {/* WHEEL BODY */}
        <div className="p-4 sm:p-6 flex flex-col items-center justify-center relative overflow-hidden bg-radial from-slate-900 via-slate-950 to-slate-950">
          
          {/* Top Pointer Needle */}
          <div className="absolute top-2 z-20 flex flex-col items-center pointer-events-none drop-shadow-[0_4px_12px_rgba(245,158,11,0.6)]">
            <div className="w-6 h-8 bg-gradient-to-b from-amber-300 via-amber-500 to-amber-600 clip-needle shadow-2xl border-x-2 border-white/60 animate-pulse" 
                 style={{ clipPath: 'polygon(50% 100%, 0 0, 100% 0)' }}
            />
            <div className="w-3 h-3 rounded-full bg-amber-200 border-2 border-amber-600 -mt-7" />
          </div>

          {/* SVG WHEEL */}
          <div className="relative w-72 h-72 sm:w-88 sm:h-88 mt-4 rounded-full p-2 bg-gradient-to-br from-amber-500 via-yellow-600 to-amber-800 shadow-[0_0_50px_rgba(245,158,11,0.25)] border-4 border-amber-400/50">
            <svg
              ref={wheelRef}
              viewBox="0 0 400 400"
              style={{
                transform: `rotate(${rotation}deg)`,
                transition: isSpinning ? 'transform 5s cubic-bezier(0.15, 0.95, 0.35, 1)' : 'none',
              }}
              className="w-full h-full rounded-full"
            >
              <defs>
                <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
                  <feDropShadow dx="0" dy="2" stdDeviation="3" floodOpacity="0.5" />
                </filter>
              </defs>

              {WHEEL_SECTORS.map((sector, i) => {
                const startAngle = (i * sectorAngle) * (Math.PI / 180);
                const endAngle = ((i + 1) * sectorAngle) * (Math.PI / 180);
                const midAngle = ((i + 0.5) * sectorAngle) * (Math.PI / 180);

                const x1 = 200 + 195 * Math.cos(startAngle);
                const y1 = 200 + 195 * Math.sin(startAngle);
                const x2 = 200 + 195 * Math.cos(endAngle);
                const y2 = 200 + 195 * Math.sin(endAngle);

                // Label position
                const textR = 135;
                const tx = 200 + textR * Math.cos(midAngle);
                const ty = 200 + textR * Math.sin(midAngle);
                const textAngle = (i + 0.5) * sectorAngle;

                return (
                  <g key={sector.id}>
                    {/* Wedge Slice */}
                    <path
                      d={`M 200 200 L ${x1} ${y1} A 195 195 0 0 1 ${x2} ${y2} Z`}
                      fill={sector.bgColor}
                      stroke="#0f172a"
                      strokeWidth="2"
                    />

                    {/* Sector Text & Icon */}
                    <g transform={`rotate(${textAngle}, ${tx}, ${ty})`}>
                      <text
                        x={tx}
                        y={ty - 10}
                        textAnchor="middle"
                        dominantBaseline="central"
                        fontSize="15"
                      >
                        {sector.icon}
                      </text>
                      <text
                        x={tx}
                        y={ty + 10}
                        textAnchor="middle"
                        dominantBaseline="central"
                        fill={sector.textColor}
                        fontSize="9"
                        fontWeight="bold"
                        letterSpacing="0.2px"
                      >
                        {sector.title}
                      </text>
                    </g>
                  </g>
                );
              })}

              {/* Pegs on border */}
              {Array.from({ length: totalSectors * 2 }).map((_, idx) => {
                const angle = (idx * (360 / (totalSectors * 2))) * (Math.PI / 180);
                const px = 200 + 192 * Math.cos(angle);
                const py = 200 + 192 * Math.sin(angle);
                return (
                  <circle
                    key={idx}
                    cx={px}
                    cy={py}
                    r="2.5"
                    fill="#fef08a"
                    stroke="#854d0e"
                    strokeWidth="1"
                  />
                );
              })}
            </svg>

            {/* Center Hub / Spin Button */}
            <button
              onClick={handleSpin}
              disabled={isSpinning}
              className="absolute inset-0 m-auto w-20 h-20 sm:w-22 sm:h-22 rounded-full bg-gradient-to-br from-amber-400 via-amber-500 to-amber-700 text-slate-950 font-black flex flex-col items-center justify-center shadow-2xl border-4 border-slate-950 hover:scale-105 active:scale-95 transition-transform z-10 disabled:opacity-80 disabled:scale-100 cursor-pointer"
            >
              <RotateCw className={`w-5 h-5 stroke-[3] ${isSpinning ? 'animate-spin' : ''}`} />
              <span className="text-[11px] font-extrabold uppercase mt-0.5 tracking-wider">
                {isSpinning ? 'Aylanmoqda' : 'AYLANTIR'}
              </span>
            </button>
          </div>

          {/* Quick Info Under Wheel */}
          <div className="mt-4 flex items-center justify-center gap-4 text-xs text-slate-400">
            <span className="flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              100% Kafolatlangan Sovg'a
            </span>
            <span>•</span>
            <span className="flex items-center gap-1 text-amber-300">
              <Crown className="w-3.5 h-3.5 text-amber-400" />
              3D Mukofotlar & VIP
            </span>
          </div>
        </div>

        {/* WINNER POPUP MODAL */}
        {showWinModal && wonSector && (
          <div className="absolute inset-0 z-30 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
            <div className="w-full max-w-sm bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-amber-500 rounded-3xl p-6 text-center space-y-4 shadow-[0_0_40px_rgba(245,158,11,0.3)]">
              
              <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-br from-amber-500/20 to-amber-600/30 border-2 border-amber-400 flex items-center justify-center text-4xl shadow-lg shadow-amber-500/20 animate-bounce">
                {wonSector.icon}
              </div>

              <div>
                <span className="text-[11px] font-mono uppercase font-bold text-amber-400 tracking-wider block">
                  TABRIKLAYMIZ! YUTUQ:
                </span>
                <h3 className="text-2xl font-black font-serif text-white mt-1">
                  {wonSector.title}
                </h3>
                <p className="text-xs text-slate-300 mt-1">
                  {wonSector.type === 'coins' && `${wonSector.amount?.toLocaleString()} Tanga balansingizga qo'shildi!`}
                  {wonSector.type === '3d_item' && "3D Eksklyuziv aksessuar qahramoningiz garderobiga qo'shildi!"}
                  {wonSector.type === 'vip' && "3 Kunlik VIP Status faollashtirildi! (2x XP va bepul spinlar)"}
                  {wonSector.type === 'ticket' && "3 ta Omadli Bilet hisobingizga qo'shildi!"}
                  {wonSector.type === 'free_spin' && "Qayta bepul aylantirish imkoniyati taqdim etildi!"}
                </p>
              </div>

              <button
                onClick={() => {
                  sounds.playChip();
                  setShowWinModal(false);
                }}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 text-slate-950 font-black text-sm shadow-xl shadow-amber-500/30 hover:scale-[1.02] active:scale-98 transition-transform flex items-center justify-center gap-2"
              >
                <Check className="w-5 h-5 stroke-[3]" />
                <span>Qabul Qilish</span>
              </button>
            </div>
          </div>
        )}

        {/* FOOTER */}
        <div className="p-3 bg-slate-950 border-t border-slate-900 flex items-center justify-between text-xs text-slate-500">
          <span>Har kuni kirib bepul g'ildirakni aylantiring va boylik to'plang!</span>
          <button
            onClick={() => {
              sounds.playChip();
              onClose();
            }}
            disabled={isSpinning}
            className="px-4 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 font-bold border border-slate-800 transition-colors disabled:opacity-40"
          >
            Yopish
          </button>
        </div>

      </div>
    </div>
  );
};
