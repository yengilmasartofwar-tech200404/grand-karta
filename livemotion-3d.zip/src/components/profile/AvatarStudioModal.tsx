import React, { useState, useEffect } from 'react';
import { UserProfileData } from '../../lib/firebase';
import { ThreeDCharacter, CharacterCustomization } from '../ThreeDCharacter';
import { CHARACTER_ANIMATIONS, CharacterAnimationItem } from '../ProfileModal';
import { 
  isAnimationActive, 
  getAnimationTimeRemaining, 
  grantAnimationDuration, 
  unlockAnimationPermanently 
} from '../../utils/animationTrial';
import { sounds } from '../../utils/audio';
import confetti from 'canvas-confetti';
import { 
  X, 
  Sparkles, 
  Check, 
  Coins, 
  Lock, 
  Palette, 
  Shirt, 
  Crown, 
  Glasses, 
  RotateCcw,
  Smile,
  Scissors,
  Layers,
  Sparkle,
  Eye,
  Clock
} from 'lucide-react';

interface AvatarStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfileData;
  onUpdateProfile: (updated: UserProfileData) => void;
  currentCustomization: CharacterCustomization;
  onSaveCustomization: (custom: CharacterCustomization) => void;
}

// 1. QAHRAMONLAR (30 ta Asosiy Boshlang'ich Personajlar)
export const CHARACTERS_CATALOG = [
  { id: 'alisher', name: 'Alisher (Strateg)', price: 0, desc: 'Boshlang\'ich klassik o\'yinchi' },
  { id: 'jasur', name: 'Jasur (Chempion)', price: 300, desc: 'Tajribali va chaqqon karta ustasi' },
  { id: 'malika', name: 'Malika (Go\'zal)', price: 500, desc: 'Qirollik saroyi vakili' },
  { id: 'sherzod', name: 'Sherzod (VIP Xon)', price: 1000, desc: 'Oltin toj sohibi va saxiy boy' },
  { id: 'dealer', name: 'Kazino Dileri', price: 800, desc: 'Professional blackjack ustasi' },
  { id: 'sheyx', name: 'Sheyx Mansur', price: 2500, desc: 'Cheksiz boylik va hashamat' },
  { id: 'karleone', name: 'Don Karleone', price: 1500, desc: 'Karta mafiyasi sardori' },
  { id: 'kiber', name: 'Kiber O\'yinchi', price: 1200, desc: 'Kelajak texnologiyalari ustasi' },
  { id: 'samurai', name: 'Samuray Kenshi', price: 1800, desc: 'Shafqatsiz hisob-kitob ustasi' },
  { id: 'viking', name: 'Ragnar (Viking)', price: 1600, desc: 'Qo\'rqmas jangchi' },
  { id: 'qaroqchi', name: 'Kapitan Qaroqchi', price: 2000, desc: 'Xazinalar ovchisi' },
  { id: 'sehrgar', name: 'Sehrgar Merlin', price: 2200, desc: 'Kartalarni ko\'ra oladigan afsungar' },
  { id: 'bobur', name: 'Shahzoda Bobur', price: 1400, desc: 'Buyuk sulola vorisi' },
  { id: 'lola', name: 'Lola (Yulduz)', price: 1000, desc: 'Estrada yulduzi' },
  { id: 'kamola', name: 'Qirolicha Kamola', price: 2800, desc: 'Oliy tabaqa hukmdori' },
  { id: 'timur', name: 'Amir Timur', price: 3000, desc: 'Yengilmas sarkarda' },
  { id: 'gentleman', name: 'Lord Artur', price: 1100, desc: 'Aristokrat gentleman' },
  { id: 'rok', name: 'Rok-Yulduz Jon', price: 1300, desc: 'Alovli musiqachi' },
  { id: 'sarvar', name: 'Sarvar Bokschi', price: 900, desc: 'Kuchli irodali bellashuvchi' },
  { id: 'olmos', name: 'Olmos Qiroli 777', price: 5000, desc: 'Afsonaviy elita o\'yinchisi' },
  { id: 'sniper', name: 'O\'tkir Mergan', price: 1400, desc: 'Xatolarsiz yurgizuvchi taktika' },
  { id: 'grandmaster', name: 'Grossmeyster', price: 2100, desc: '10 qadam oldindan ko\'radi' },
  { id: 'astronaut', name: 'Koinot Sayyohi', price: 2600, desc: 'Yulduzlar orasidan tashrif' },
  { id: 'knyaz', name: 'Knyaz Aleksandr', price: 1750, desc: 'Sharq va G\'arb aristokrati' },
  { id: 'polvon', name: 'Zafar Polvon', price: 1250, desc: 'Xalq sevgan mard kurashchi' },
  { id: 'nilufar', name: 'Nilufar Bonu', price: 1650, desc: 'Chiroyli va xushmuomala strateg' },
  { id: 'diplomat', name: 'Sardor Diplomat', price: 1900, desc: 'Tinchlik va muzokara ustasi' },
  { id: 'temur_malik', name: 'Temur Malik', price: 3200, desc: 'Xo\'jand qal\'asi himoyachisi' },
  { id: 'manguberdi', name: 'Jaloliddin', price: 3500, desc: 'Tengsiz matonat ramzi' },
  { id: 'feniks', name: 'Afsonaviy Feniks', price: 4500, desc: 'Har doim qayta g\'alaba qozonuvchi' },
];

// 2. SOCH RANGLARI (40 ta Turli Ranglar - Tabiiy, Oltin, Qizil, Muz, Neon, Pastel)
export const HAIR_COLORS_CATALOG = [
  // Tabiiy & Klassik
  { id: '#18181b', name: 'Klassik Qora', price: 0 },
  { id: '#09090b', name: 'Qatron Qora', price: 100 },
  { id: '#3f2e21', name: 'Qahva To\'q', price: 150 },
  { id: '#451a03', name: 'Shokolad', price: 150 },
  { id: '#78350f', name: 'Kashtan', price: 200 },
  { id: '#854d0e', name: 'Bronza', price: 250 },
  { id: '#92400e', name: 'Karamel', price: 250 },
  { id: '#a16207', name: 'Zanjabil', price: 300 },
  // Oltin & Sariq
  { id: '#ca8a04', name: 'Oltin Sariq', price: 300 },
  { id: '#eab308', name: 'Yorqin Oltin', price: 350 },
  { id: '#facc15', name: 'Bug\'doyrang', price: 350 },
  { id: '#fde047', name: 'Och Sariq', price: 400 },
  { id: '#d97706', name: 'Zafar Sariq', price: 400 },
  // Qizil & Olovli
  { id: '#ea580c', name: 'Olov Qizil', price: 400 },
  { id: '#dc2626', name: 'Yoqut Qizil', price: 450 },
  { id: '#b91c1c', name: 'Qirmizi', price: 450 },
  { id: '#991b1b', name: 'Bordo Qizil', price: 500 },
  { id: '#f97316', name: 'Apelsin Nuri', price: 450 },
  // Oq & Kumush & Muz
  { id: '#94a3b8', name: 'Kumush Oq', price: 500 },
  { id: '#cbd5e1', name: 'Platina Muz', price: 550 },
  { id: '#f8fafc', name: 'Qor Oq', price: 600 },
  { id: '#64748b', name: 'Kulrang Po\'lat', price: 450 },
  { id: '#475569', name: 'Tungi Tutun', price: 400 },
  // Zamonaviy & Neon
  { id: '#06b6d4', name: 'Neon Moviy', price: 800 },
  { id: '#0284c7', name: 'Safir Ko\'k', price: 750 },
  { id: '#2563eb', name: 'Kobalt Ko\'k', price: 700 },
  { id: '#4f46e5', name: 'Indigo Tungi', price: 750 },
  { id: '#7c3aed', name: 'Nilufar Binafsha', price: 850 },
  { id: '#9333ea', name: 'Ametist Binafsha', price: 850 },
  { id: '#c026d3', name: 'Qizg\'ish Pushti', price: 800 },
  { id: '#db2777', name: 'Pushti Flamingo', price: 750 },
  { id: '#e11d48', name: 'Malina Nuri', price: 750 },
  { id: '#10b981', name: 'Zumrad Yashil', price: 800 },
  { id: '#059669', name: 'Nefrit Yashil', price: 850 },
  { id: '#84cc16', name: 'Laym Yashil', price: 700 },
  { id: '#14b8a6', name: 'Kiber Turkuaz', price: 900 },
  { id: '#065f46', name: "To'q O'rmon", price: 600 },
  { id: '#312e81', name: 'Kosmik Tungi', price: 950 },
  { id: '#581c87', name: 'Sehrgar Binafsha', price: 1000 },
  { id: '#fbbf24', name: 'Quyosh Chaqnashi', price: 1100 },
];

// 3. SOCH TURMAKLARI (8 ta Alohida Turmak)
export const HAIR_STYLES_CATALOG = [
  { id: 'classic', name: 'Klassik Turmak', icon: '💇', price: 0, desc: 'Barcha davrlar klassikasi' },
  { id: 'short', name: 'Sport Qisqa', icon: '⚡', price: 200, desc: 'Qat\'iy va qulay' },
  { id: 'curly', name: 'Jingalak Soch', icon: '🌀', price: 400, desc: 'To\'lqinsimon jozibali' },
  { id: 'long', name: 'Uzun Oqimli', icon: '✨', price: 500, desc: 'Elita va go\'zallik timsoli' },
  { id: 'spiky', name: 'Kiber Spayk', icon: '🔥', price: 650, desc: 'Zamonaviy kiber uslub' },
  { id: 'turban', name: 'Sharqona Salla', icon: '👳', price: 900, desc: 'Podshohona zardo\'z salla' },
  { id: 'bald', name: 'Bokschi / Kal', icon: '🥊', price: 150, desc: 'Jangovar qat\'iyat' },
];

// 4. YUZ, OG'IZ & QULOQLAR (20+ Xususiyatlar: Mo'ylov, Soqol, Sirg'alar)
export const FACE_FEATURES_CATALOG = [
  // Mo'ylov & Soqol
  { id: 'facial_none', name: 'Yuz Sochlari Yo\'q', category: 'facial', value: 'none', price: 0 },
  { id: 'facial_mustache', name: 'Klassik Mo\'ylov', category: 'facial', value: 'mustache', price: 300 },
  { id: 'facial_goatee', name: 'Goatee (Echki Soqol)', category: 'facial', value: 'goatee', price: 450 },
  { id: 'facial_full_beard', name: 'To\'liq Viking Soqoli', category: 'facial', value: 'full_beard', price: 600 },
  // Quloqlar & Zargarlik
  { id: 'earring_none', name: 'Sirg\'a Yo\'q', category: 'earring', value: 'none', price: 0 },
  { id: 'earring_gold_ring', name: 'Oltin Halqa Sirg\'a', category: 'earring', value: 'gold_ring', price: 500 },
  { id: 'earring_diamond', name: 'Brilliant Ziraklar', category: 'earring', value: 'diamond', price: 1000 },
  // Teri Tuslari
  { id: 'skin_fair', name: 'Oqish Teri', category: 'skin', value: '#fed7aa', price: 0 },
  { id: 'skin_wheat', name: 'Bug\'doyrang Teri', category: 'skin', value: '#fdba74', price: 100 },
  { id: 'skin_bronze', name: 'Bronza Teri', category: 'skin', value: '#fb923c', price: 200 },
  { id: 'skin_gold', name: 'Oltinrang Tus', category: 'skin', value: '#f59e0b', price: 400 },
  { id: 'skin_dark', name: 'Qoramtir Teri', category: 'skin', value: '#9a3412', price: 250 },
];

// 5. LIBOS & KOSTYUM RANGLARI (45 ta Ranglar)
export const SUIT_COLORS_CATALOG = [
  { id: '#1e3a8a', name: 'Qirollik Ko\'k', price: 0 },
  { id: '#09090b', name: 'Tungi Qora', price: 200 },
  { id: '#991b1b', name: 'Velvet Qizil', price: 250 },
  { id: '#065f46', name: 'Zumrad Yashil', price: 300 },
  { id: '#ca8a04', name: 'Zardo\'z Oltin', price: 600 },
  { id: '#f8fafc', name: 'Oq Smoking', price: 800 },
  { id: '#1e1b4b', name: 'Tungi Safir', price: 350 },
  { id: '#312e81', name: 'Indigo Atlas', price: 400 },
  { id: '#4c0519', name: 'Bordo Velvet', price: 450 },
  { id: '#701a75', name: 'Sultonina Binafsha', price: 550 },
  { id: '#14532d', name: 'To\'q Malaxit', price: 400 },
  { id: '#78350f', name: 'Jigarrang Charm', price: 350 },
  { id: '#3f3f46', name: 'Titan Kulrang', price: 300 },
  { id: '#e11d48', name: 'Kardinal Qizil', price: 500 },
  { id: '#0284c7', name: 'Dengiz To\'lqini', price: 450 },
  { id: '#0d9488', name: 'Zumrad Nefrit', price: 500 },
  { id: '#d97706', name: 'Qahrabo Zardo\'z', price: 650 },
  { id: '#0f172a', name: 'Prezident Kostyumi', price: 700 },
  { id: '#be123c', name: 'Yoqut Smoking', price: 750 },
  { id: '#4338ca', name: 'Lapis Lazuli', price: 600 },
  { id: '#15803d', name: 'Yashil Saroy', price: 550 },
  { id: '#b45309', name: 'Mis Bronza', price: 600 },
  { id: '#6b21a8', name: 'Imperator Binafsha', price: 900 },
  { id: '#831843', name: 'Qirolicha Velvet', price: 850 },
  { id: '#047857', name: 'Sharqona Zumrad', price: 650 },
  { id: '#1d4ed8', name: 'Brilliant Moviy', price: 700 },
  { id: '#6d28d9', name: 'Ametist Zarbof', price: 800 },
  { id: '#be185d', name: 'Atirgul Qirmizi', price: 750 },
  { id: '#a21caf', name: 'Sehrli Nilufar', price: 850 },
  { id: '#0e7490', name: 'Okean Tubi', price: 600 },
  { id: '#334155', name: 'Diplomat Smok', price: 500 },
  { id: '#eab308', name: 'Sof Oltin Zarbof', price: 1500 },
  { id: '#38bdf8', name: 'Kiber Moviy', price: 1000 },
  { id: '#4ade80', name: 'Kiber Matritsa', price: 1100 },
  { id: '#f43f5e', name: 'Neon Qizil', price: 1000 },
  { id: '#a855f7', name: 'Neon Fiolet', price: 1050 },
  { id: '#cbd5e1', name: 'Kumush Sovut', price: 1200 },
  { id: '#fdba74', name: 'Ipak Karamel', price: 600 },
  { id: '#f472b6', name: 'Pushti Atlas', price: 700 },
  { id: '#2dd4bf', name: 'Turkuaz Zardo\'z', price: 850 },
];

// 6. LIBOS STILLARI (8 ta Stil)
export const SUIT_STYLES_CATALOG = [
  { id: 'classic', name: 'Klassik Kostyum & Kapalak', icon: '👔', price: 0, desc: 'Doimiy elegatlik' },
  { id: 'tuxedo', name: 'VIP Smoking (Tuxedo)', icon: '🎩', price: 400, desc: 'Kazino va bayram libosi' },
  { id: 'chapan', name: 'Zardo\'z Milliy To\'n', icon: '🥻', price: 800, desc: 'Oltin ipli sharqona chapan' },
  { id: 'gold_armor', name: 'Jangovar Oltin Sovut', icon: '🛡️', price: 1500, desc: 'Yengilmas sarkarda sovuti' },
  { id: 'vest', name: 'Aristokrat Jilet', icon: '💼', price: 350, desc: 'Qat\'iy shahar aristokrati' },
  { id: 'hoodie', name: 'Sport Kiber Xudi', icon: '🧥', price: 300, desc: 'Yoshlar kiber uslubi' },
];

// 7. AKSESSUARLAR (30 ta Aksessuar - Toj, Ko'zoynak, Quloqchin, Zanjir, Maska, Monokl)
export const ACCESSORIES_CATALOG = [
  { id: 'none', name: 'Aksessuarsiz', icon: '✕', price: 0, desc: 'Oddiy ko\'rinish' },
  { id: 'crown', name: 'Qirollik Oltin Toji', icon: '👑', price: 1200, desc: 'Hukmdorlar toji' },
  { id: 'sunglasses', name: 'Qora Klassik Ko\'zoynak', icon: '🕶️', price: 600, desc: 'Sirli va xarizmatik' },
  { id: 'cap', name: 'Qizil Sport Kepka', icon: '🧢', price: 400, desc: 'Chaqqon va zamonaviy' },
  { id: 'top_hat', name: 'Aristokrat Silindr Shlyapa', icon: '🎩', price: 900, desc: 'Lord va serlar shlyapasi' },
  { id: 'headset', name: 'Kiber Quloqchin (Gamer)', icon: '🎧', price: 850, desc: 'Jonli mikrofonli quloqchin' },
  { id: 'gold_chain', name: 'Katta Oltin Zanjir', icon: '⛓️', price: 1000, desc: 'Boylik va nufuz ramzi' },
  { id: 'monocle', name: 'Oltin Monokl', icon: '🧐', price: 750, desc: 'Aristokrat ko\'z oynagi' },
  { id: 'mask', name: 'Tungi Qora Maska', icon: '🎭', price: 700, desc: 'Yuzni yashiruvchi maska' },
  { id: 'earring', name: 'Oltin Halqa Sirg\'a', icon: '💍', price: 500, desc: 'Qaroqchi uslubidagi sirg\'a' },
];

export const AvatarStudioModal: React.FC<AvatarStudioModalProps> = ({
  isOpen,
  onClose,
  profile,
  onUpdateProfile,
  currentCustomization,
  onSaveCustomization,
}) => {
  const [selectedChar, setSelectedChar] = useState(currentCustomization.modelId || 'alisher');
  const [hairColor, setHairColor] = useState(currentCustomization.hairColor || '#18181b');
  const [hairStyle, setHairStyle] = useState(currentCustomization.hairStyle || 'classic');
  const [suitColor, setSuitColor] = useState(currentCustomization.suitColor || '#1e3a8a');
  const [suitStyle, setSuitStyle] = useState(currentCustomization.suitStyle || 'classic');
  const [accessory, setAccessory] = useState(currentCustomization.accessory || 'none');
  const [facialHair, setFacialHair] = useState(currentCustomization.facialHair || 'none');
  const [earring, setEarring] = useState(currentCustomization.earring || 'none');
  const [skinColor, setSkinColor] = useState(currentCustomization.skinColor || '#fed7aa');

  // Preview interactive reaction emoji
  const [previewEmoji, setPreviewEmoji] = useState<string | null>(null);
  const [previewTriggerKey, setPreviewTriggerKey] = useState<number>(0);

  // Unlocked items
  const [unlockedItems, setUnlockedItems] = useState<string[]>(() => {
    try {
      return JSON.parse(
        localStorage.getItem('grand_unlocked_3d_items') ||
          '["alisher", "#18181b", "classic", "#1e3a8a", "none", "facial_none", "earring_none", "skin_fair"]'
      );
    } catch {
      return ['alisher', '#18181b', 'classic', '#1e3a8a', 'none', 'facial_none', 'earring_none', 'skin_fair'];
    }
  });

  // Per-animation real-time ticker ("smaylik animatsiya yutib olsa sanaydi vaqt")
  const [animTicker, setAnimTicker] = useState(0);

  useEffect(() => {
    const timerId = setInterval(() => {
      setAnimTicker((prev) => prev + 1);
    }, 1000);

    const onAnimEvent = () => setAnimTicker((prev) => prev + 1);
    window.addEventListener('grand_anim_updated', onAnimEvent);

    return () => {
      clearInterval(timerId);
      window.removeEventListener('grand_anim_updated', onAnimEvent);
    };
  }, []);

  // Dedicated separate tabs ("adelniy adelniy")
  type TabType = 'characters' | 'hair_colors' | 'hair_styles' | 'face' | 'suit_colors' | 'suit_styles' | 'accessories' | 'animations';
  const [activeTab, setActiveTab] = useState<TabType>('characters');

  if (!isOpen) return null;

  const triggerPreviewReaction = (emoji: string) => {
    setPreviewEmoji(emoji);
    setPreviewTriggerKey((prev) => prev + 1);
    sounds.playChip();
  };

  const handleBuyOrEquip = (itemId: string, price: number, category: TabType) => {
    sounds.playChip();

    if (category === 'animations') {
      const status = getAnimationTimeRemaining(itemId);
      if (status.isActive) {
        applyItem(itemId, category);
        return;
      }

      // If not active, allow 7-day unlock for 500 coins
      if (profile.chips < 500) {
        alert("7 kunga ochish uchun hisobingizda 500 tanga yetarli emas! O'yinlarda yutib yoki do'kondan tanga xarid qiling.");
        return;
      }

      const newChips = profile.chips - 500;
      const updatedProfile = { ...profile, chips: newChips };
      onUpdateProfile(updatedProfile);
      grantAnimationDuration(itemId, 7);

      sounds.playWin();
      confetti({ particleCount: 80, spread: 60 });
      applyItem(itemId, category);
      return;
    }

    const isUnlocked = unlockedItems.includes(itemId) || price === 0;

    if (isUnlocked) {
      applyItem(itemId, category);
    } else {
      if (profile.chips < price) {
        alert("Hisobingizda tanga yetarli emas! O'yinlarda yutib yoki do'kondan tanga xarid qiling.");
        return;
      }
      const newChips = profile.chips - price;
      const updatedProfile = { ...profile, chips: newChips };
      onUpdateProfile(updatedProfile);

      const nextUnlocked = [...unlockedItems, itemId];
      setUnlockedItems(nextUnlocked);
      localStorage.setItem('grand_unlocked_3d_items', JSON.stringify(nextUnlocked));

      sounds.playWin();
      confetti({ particleCount: 75, spread: 60 });
      applyItem(itemId, category);
    }
  };

  const applyItem = (itemId: string, category: TabType) => {
    if (category === 'characters') setSelectedChar(itemId);
    else if (category === 'hair_colors') setHairColor(itemId);
    else if (category === 'hair_styles') setHairStyle(itemId as any);
    else if (category === 'suit_colors') setSuitColor(itemId);
    else if (category === 'suit_styles') setSuitStyle(itemId as any);
    else if (category === 'accessories') setAccessory(itemId as any);
    else if (category === 'animations') {
      const match = CHARACTER_ANIMATIONS.find(a => a.id === itemId);
      if (match) triggerPreviewReaction(match.actionKey);
    }
    else if (category === 'face') {
      const match = FACE_FEATURES_CATALOG.find((f) => f.id === itemId);
      if (match) {
        if (match.category === 'facial') setFacialHair(match.value as any);
        else if (match.category === 'earring') setEarring(match.value as any);
        else if (match.category === 'skin') setSkinColor(match.value as any);
      }
    }
  };

  const handleSaveAll = () => {
    const finalCustom: CharacterCustomization = {
      modelId: selectedChar,
      hairColor,
      hairStyle,
      suitColor,
      suitStyle,
      accessory,
      facialHair,
      earring,
      skinColor,
    };
    onSaveCustomization(finalCustom);
    localStorage.setItem('grand_character_custom', JSON.stringify(finalCustom));
    sounds.playWin();
    confetti({ particleCount: 90, spread: 70 });
    onClose();
  };

  const currentPreviewCustom: CharacterCustomization = {
    modelId: selectedChar,
    hairColor,
    hairStyle,
    suitColor,
    suitStyle,
    accessory,
    facialHair,
    earring,
    skinColor,
  };

  const tabsConfig = [
    { id: 'characters', label: 'Qahramonlar', count: CHARACTERS_CATALOG.length, icon: '🎭' },
    { id: 'hair_colors', label: 'Soch Rangi', count: HAIR_COLORS_CATALOG.length, icon: '🎨' },
    { id: 'hair_styles', label: 'Soch Turmagi', count: HAIR_STYLES_CATALOG.length, icon: '💇' },
    { id: 'face', label: 'Og\'iz, Quloq & Yuz', count: FACE_FEATURES_CATALOG.length, icon: '🧔' },
    { id: 'suit_colors', label: 'Libos Rangi', count: SUIT_COLORS_CATALOG.length, icon: '👔' },
    { id: 'suit_styles', label: 'Libos Stili', count: SUIT_STYLES_CATALOG.length, icon: '🧥' },
    { id: 'accessories', label: 'Aksessuarlar', count: ACCESSORIES_CATALOG.length, icon: '👑' },
    { id: 'animations', label: '3D Animatsiyalar', count: CHARACTER_ANIMATIONS.length, icon: '🕺' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-xs">
      <div className="relative w-full max-w-5xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[94vh]">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-100 font-serif flex items-center gap-2">
                <span>3D Personaj & Kiyimlar Studiyasi</span>
                <span className="text-[10px] font-mono bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded-full">
                  300+ Elementlar · Alohida Bo'limlar
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Og'iz, quloqlar, soqol, soch ranglari va liboslar — har birini alohida moslang!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 bg-slate-900 border border-amber-500/40 px-3 py-1.5 rounded-xl text-amber-300 font-mono font-bold text-xs shadow-inner">
              <Coins className="w-4 h-4 text-amber-400" />
              <span>{profile.chips.toLocaleString()} tanga</span>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Studio Body: Split View (Left: 3D Canvas, Right: Dedicated Tabs & Grids) */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          {/* Left: Interactive 3D Model Stage */}
          <div className="w-full md:w-5/12 bg-gradient-to-b from-slate-950 via-slate-900 to-black p-4 sm:p-6 flex flex-col items-center justify-between border-b md:border-b-0 md:border-r border-slate-800 relative">
            <div className="w-full flex items-center justify-between">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-[11px] font-bold">
                <Sparkle className="w-3.5 h-3.5" />
                Jonli 3D Ko'rinish
              </div>

              <div className="text-[10px] text-slate-400 font-mono">
                Og'iz & Quloqlar faol
              </div>
            </div>

            {/* Live 3D Character Rendering */}
            <div className="my-2 flex flex-col items-center">
              <ThreeDCharacter
                name="Sizning Personajingiz"
                variant={selectedChar}
                customization={currentPreviewCustom}
                activeEmoji={previewEmoji}
                triggerKey={previewTriggerKey}
                cardsCount={6}
                nameplatePosition="top"
                className="scale-110"
              />
            </div>

            {/* Quick Emotion / Mouth test buttons */}
            <div className="w-full bg-slate-950/70 p-3 rounded-2xl border border-slate-800 flex flex-col items-center gap-2">
              <div className="text-[11px] font-semibold text-slate-300 flex items-center gap-1.5">
                <Smile className="w-3.5 h-3.5 text-amber-400" />
                <span>Og'iz va yuz harakatini tekshiring:</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => triggerPreviewReaction('😂')}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 flex items-center gap-1 transition-transform active:scale-95"
                >
                  <span>😂 Kulish</span>
                </button>
                <button
                  onClick={() => triggerPreviewReaction('😎')}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 flex items-center gap-1 transition-transform active:scale-95"
                >
                  <span>😎 Zo'r</span>
                </button>
                <button
                  onClick={() => triggerPreviewReaction('👏')}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 flex items-center gap-1 transition-transform active:scale-95"
                >
                  <span>👏 Qarsak</span>
                </button>
                <button
                  onClick={() => triggerPreviewReaction('🏆')}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 flex items-center gap-1 transition-transform active:scale-95"
                >
                  <span>🏆 Yutuq</span>
                </button>
              </div>
            </div>
          </div>

          {/* Right: Customization Controls with Separate Tabs ("adelniy adelniy") */}
          <div className="w-full md:w-7/12 flex flex-col bg-slate-900/60 overflow-hidden">
            {/* Category Navigation Tabs */}
            <div className="flex items-center overflow-x-auto p-2 gap-1.5 bg-slate-950 border-b border-slate-800 no-scrollbar">
              {tabsConfig.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => {
                    sounds.playChip();
                    setActiveTab(tab.id as TabType);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition-all ${
                    activeTab === tab.id
                      ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  <span>{tab.icon}</span>
                  <span>{tab.label}</span>
                  {tab.id === 'animations' ? (
                    <span
                      className="text-[9px] px-1.5 py-0.5 rounded-full font-bold font-mono bg-amber-400 text-slate-950"
                    >
                      {CHARACTER_ANIMATIONS.filter(a => getAnimationTimeRemaining(a.id).isActive && !getAnimationTimeRemaining(a.id).isPermanent).length > 0
                        ? `${CHARACTER_ANIMATIONS.filter(a => getAnimationTimeRemaining(a.id).isActive && !getAnimationTimeRemaining(a.id).isPermanent).length} FAOL`
                        : "DO'KON"}
                    </span>
                  ) : (
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                        activeTab === tab.id ? 'bg-slate-950/30 text-slate-950' : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {tab.count}
                    </span>
                  )}
                </button>
              ))}
            </div>

            {/* Items Grid Container */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-5">
              {/* TAB 1: Qahramonlar */}
              {activeTab === 'characters' && (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {CHARACTERS_CATALOG.map((char) => {
                    const isUnlocked = unlockedItems.includes(char.id) || char.price === 0;
                    const isSelected = selectedChar === char.id;
                    return (
                      <div
                        key={char.id}
                        onClick={() => handleBuyOrEquip(char.id, char.price, 'characters')}
                        className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between relative ${
                          isSelected
                            ? 'bg-amber-500/15 border-amber-500 ring-2 ring-amber-500/40 shadow-lg'
                            : 'bg-slate-800/60 border-slate-700/60 hover:bg-slate-800 hover:border-slate-600'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs font-bold text-slate-100">{char.name}</span>
                            {isSelected && <Check className="w-4 h-4 text-amber-400" />}
                          </div>
                          <p className="text-[11px] text-slate-400 leading-snug line-clamp-2">
                            {char.desc}
                          </p>
                        </div>

                        <div className="mt-3 flex items-center justify-between text-xs pt-2 border-t border-slate-700/50">
                          {isUnlocked ? (
                            <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                              <Check className="w-3 h-3" /> Ochilgan
                            </span>
                          ) : (
                            <span className="text-amber-400 font-mono font-bold flex items-center gap-1">
                              <Coins className="w-3.5 h-3.5" /> {char.price}
                            </span>
                          )}
                          <span className="text-[10px] text-slate-400 uppercase tracking-wider">
                            {isSelected ? 'Tanlangan' : isUnlocked ? 'Kiyish' : 'Sotib olish'}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* TAB 2: Soch Ranglari (40+ Rang) */}
              {activeTab === 'hair_colors' && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {HAIR_COLORS_CATALOG.map((color) => {
                    const isUnlocked = unlockedItems.includes(color.id) || color.price === 0;
                    const isSelected = hairColor === color.id;
                    return (
                      <div
                        key={color.id}
                        onClick={() => handleBuyOrEquip(color.id, color.price, 'hair_colors')}
                        className={`p-2.5 rounded-2xl border cursor-pointer transition-all flex flex-col items-center gap-2 ${
                          isSelected
                            ? 'bg-amber-500/15 border-amber-500 ring-2 ring-amber-500/40'
                            : 'bg-slate-800/60 border-slate-700/60 hover:bg-slate-800'
                        }`}
                      >
                        <div
                          className="w-10 h-10 rounded-full border-2 border-white/30 shadow-md flex items-center justify-center transition-transform hover:scale-110"
                          style={{ backgroundColor: color.id }}
                        >
                          {isSelected && <Check className="w-5 h-5 text-white drop-shadow" />}
                        </div>
                        <span className="text-xs font-semibold text-slate-200 text-center">
                          {color.name}
                        </span>
                        <div className="text-[10px] font-mono text-slate-400">
                          {isUnlocked ? (
                            <span className="text-emerald-400 font-bold">Ochilgan</span>
                          ) : (
                            <span className="text-amber-400 font-bold flex items-center gap-0.5">
                              <Coins className="w-3 h-3" /> {color.price}
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* TAB 3: Soch Turmagi */}
              {activeTab === 'hair_styles' && (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {HAIR_STYLES_CATALOG.map((style) => {
                    const isUnlocked = unlockedItems.includes(style.id) || style.price === 0;
                    const isSelected = hairStyle === style.id;
                    return (
                      <div
                        key={style.id}
                        onClick={() => handleBuyOrEquip(style.id, style.price, 'hair_styles')}
                        className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                          isSelected
                            ? 'bg-amber-500/15 border-amber-500 ring-2 ring-amber-500/40'
                            : 'bg-slate-800/60 border-slate-700/60 hover:bg-slate-800'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xl">{style.icon}</span>
                            {isSelected && <Check className="w-4 h-4 text-amber-400" />}
                          </div>
                          <h4 className="text-xs font-bold text-slate-100">{style.name}</h4>
                          <p className="text-[11px] text-slate-400 mt-0.5">{style.desc}</p>
                        </div>
                        <div className="mt-3 pt-2 border-t border-slate-700/50 flex items-center justify-between text-xs">
                          {isUnlocked ? (
                            <span className="text-emerald-400 font-semibold text-[11px]">Ochilgan</span>
                          ) : (
                            <span className="text-amber-400 font-mono font-bold flex items-center gap-1 text-[11px]">
                              <Coins className="w-3 h-3" /> {style.price}
                            </span>
                          )}
                          <span className="text-[10px] text-slate-400">
                            {isSelected ? 'Faol' : 'Tanlash'}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* TAB 4: Yuz, Og'iz, Quloqlar & Zargarlik */}
              {activeTab === 'face' && (
                <div className="space-y-4">
                  <div className="bg-slate-950/60 p-3 rounded-2xl border border-slate-800 text-xs text-slate-300">
                    💡 3D Personajning og'zi jonli harakatlanadi, quloqlari ikki tomonda joylashgan va sirg'alar taqish imkoniyati mavjud.
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {FACE_FEATURES_CATALOG.map((feat) => {
                      const isUnlocked = unlockedItems.includes(feat.id) || feat.price === 0;
                      let isSelected = false;
                      if (feat.category === 'facial') isSelected = facialHair === feat.value;
                      else if (feat.category === 'earring') isSelected = earring === feat.value;
                      else if (feat.category === 'skin') isSelected = skinColor === feat.value;

                      return (
                        <div
                          key={feat.id}
                          onClick={() => handleBuyOrEquip(feat.id, feat.price, 'face')}
                          className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                            isSelected
                              ? 'bg-amber-500/15 border-amber-500 ring-2 ring-amber-500/40'
                              : 'bg-slate-800/60 border-slate-700/60 hover:bg-slate-800'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-slate-200">{feat.name}</span>
                            {isSelected && <Check className="w-4 h-4 text-amber-400" />}
                          </div>

                          <div className="mt-3 pt-2 border-t border-slate-700/50 flex items-center justify-between text-xs">
                            {isUnlocked ? (
                              <span className="text-emerald-400 font-semibold text-[11px]">Ochilgan</span>
                            ) : (
                              <span className="text-amber-400 font-mono font-bold flex items-center gap-1 text-[11px]">
                                <Coins className="w-3 h-3" /> {feat.price}
                              </span>
                            )}
                            <span className="text-[10px] text-slate-400">
                              {isSelected ? 'Tanlangan' : 'Kiyish'}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB 5: Libos Ranglari (45 ta Rang) */}
              {activeTab === 'suit_colors' && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {SUIT_COLORS_CATALOG.map((color) => {
                    const isUnlocked = unlockedItems.includes(color.id) || color.price === 0;
                    const isSelected = suitColor === color.id;
                    return (
                      <div
                        key={color.id}
                        onClick={() => handleBuyOrEquip(color.id, color.price, 'suit_colors')}
                        className={`p-2.5 rounded-2xl border cursor-pointer transition-all flex flex-col items-center gap-2 ${
                          isSelected
                            ? 'bg-amber-500/15 border-amber-500 ring-2 ring-amber-500/40'
                            : 'bg-slate-800/60 border-slate-700/60 hover:bg-slate-800'
                        }`}
                      >
                        <div
                          className="w-10 h-10 rounded-xl border-2 border-white/30 shadow-md flex items-center justify-center transition-transform hover:scale-110"
                          style={{ backgroundColor: color.id }}
                        >
                          {isSelected && <Check className="w-5 h-5 text-white drop-shadow" />}
                        </div>
                        <span className="text-xs font-semibold text-slate-200 text-center">
                          {color.name}
                        </span>
                        <div className="text-[10px] font-mono text-slate-400">
                          {isUnlocked ? (
                            <span className="text-emerald-400 font-bold">Ochilgan</span>
                          ) : (
                            <span className="text-amber-400 font-bold flex items-center gap-0.5">
                              <Coins className="w-3 h-3" /> {color.price}
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* TAB 6: Libos Stillari */}
              {activeTab === 'suit_styles' && (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {SUIT_STYLES_CATALOG.map((style) => {
                    const isUnlocked = unlockedItems.includes(style.id) || style.price === 0;
                    const isSelected = suitStyle === style.id;
                    return (
                      <div
                        key={style.id}
                        onClick={() => handleBuyOrEquip(style.id, style.price, 'suit_styles')}
                        className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                          isSelected
                            ? 'bg-amber-500/15 border-amber-500 ring-2 ring-amber-500/40'
                            : 'bg-slate-800/60 border-slate-700/60 hover:bg-slate-800'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xl">{style.icon}</span>
                            {isSelected && <Check className="w-4 h-4 text-amber-400" />}
                          </div>
                          <h4 className="text-xs font-bold text-slate-100">{style.name}</h4>
                          <p className="text-[11px] text-slate-400 mt-0.5">{style.desc}</p>
                        </div>
                        <div className="mt-3 pt-2 border-t border-slate-700/50 flex items-center justify-between text-xs">
                          {isUnlocked ? (
                            <span className="text-emerald-400 font-semibold text-[11px]">Ochilgan</span>
                          ) : (
                            <span className="text-amber-400 font-mono font-bold flex items-center gap-1 text-[11px]">
                              <Coins className="w-3 h-3" /> {style.price}
                            </span>
                          )}
                          <span className="text-[10px] text-slate-400">
                            {isSelected ? 'Faol' : 'Tanlash'}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* TAB 7: Aksessuarlar (Toj, Ko'zoynak, Zanjir, Maska, Monokl...) */}
              {activeTab === 'accessories' && (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {ACCESSORIES_CATALOG.map((acc) => {
                    const isUnlocked = unlockedItems.includes(acc.id) || acc.price === 0;
                    const isSelected = accessory === acc.id;
                    return (
                      <div
                        key={acc.id}
                        onClick={() => handleBuyOrEquip(acc.id, acc.price, 'accessories')}
                        className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                          isSelected
                            ? 'bg-amber-500/15 border-amber-500 ring-2 ring-amber-500/40'
                            : 'bg-slate-800/60 border-slate-700/60 hover:bg-slate-800'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-2xl">{acc.icon}</span>
                            {isSelected && <Check className="w-4 h-4 text-amber-400" />}
                          </div>
                          <h4 className="text-xs font-bold text-slate-100">{acc.name}</h4>
                          <p className="text-[11px] text-slate-400 mt-0.5">{acc.desc}</p>
                        </div>
                        <div className="mt-3 pt-2 border-t border-slate-700/50 flex items-center justify-between text-xs">
                          {isUnlocked ? (
                            <span className="text-emerald-400 font-semibold text-[11px]">Ochilgan</span>
                          ) : (
                            <span className="text-amber-400 font-mono font-bold flex items-center gap-1 text-[11px]">
                              <Coins className="w-3 h-3" /> {acc.price}
                            </span>
                          )}
                          <span className="text-[10px] text-slate-400">
                            {isSelected ? 'Taqilgan' : 'Taqish'}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* TAB 8: 3D Animatsiyalar */}
              {activeTab === 'animations' && (
                <div className="space-y-4">
                  {/* PER-ANIMATION WON COUNTDOWN BANNER ("smaylik animatsiya yutib olsa sanaydi vaqt") */}
                  <div className="p-3.5 sm:p-4 rounded-2xl bg-gradient-to-r from-amber-950/60 via-slate-900 to-purple-950/60 border border-amber-500/50 shadow-lg">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                          <Clock className="w-5 h-5 animate-spin" style={{ animationDuration: '6s' }} />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-xs font-bold text-slate-100 font-serif">
                              3D ANIMATSIYA YUTUQ TIZIMI
                            </h4>
                            <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-500 text-slate-950">
                              YUTSA 7 KUN SANAYDI
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400">
                            Omad G'ildiragidan yutib olingan har bir animatsiya 7 kun davomida faol bo'lib vaqt sanaydi!
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs font-mono self-start sm:self-auto">
                        <span className="text-slate-400">Faol yutuqlar:</span>
                        <span className="text-emerald-400 font-black">
                          {CHARACTER_ANIMATIONS.filter(a => getAnimationTimeRemaining(a.id).isActive && !getAnimationTimeRemaining(a.id).isPermanent).length} ta
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Grid of 16 3D animations */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {CHARACTER_ANIMATIONS.map((anim) => {
                      const status = getAnimationTimeRemaining(anim.id);
                      const isCurrentlyActive = status.isActive;
                      const isSelected = previewEmoji === anim.actionKey;

                      return (
                        <div
                          key={anim.id}
                          onClick={() => handleBuyOrEquip(anim.id, anim.price, 'animations')}
                          className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                            isSelected
                              ? 'bg-amber-500/15 border-amber-400 ring-2 ring-amber-500/40 shadow-lg'
                              : status.isPermanent
                              ? 'bg-slate-800/60 border-emerald-500/40 hover:bg-slate-800'
                              : isCurrentlyActive
                              ? 'bg-slate-800/60 border-purple-500/50 hover:border-amber-400 ring-1 ring-purple-500/30'
                              : 'bg-slate-950/70 border-slate-800/80 hover:border-amber-500/40 opacity-90'
                          }`}
                        >
                          <div>
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-2xl">{anim.icon}</span>
                              <div className="flex items-center gap-1">
                                {status.isPermanent ? (
                                  <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold border border-emerald-500/40">
                                    ✓
                                  </span>
                                ) : isCurrentlyActive ? (
                                  <span className="px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[9px] font-bold border border-emerald-500/30 animate-pulse">
                                    Faol
                                  </span>
                                ) : (
                                  <Lock className="w-3.5 h-3.5 text-amber-400" />
                                )}
                                {isSelected && <Check className="w-4 h-4 text-amber-400" />}
                              </div>
                            </div>
                            <h4 className="text-xs font-bold text-slate-100">{anim.name}</h4>
                            <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">{anim.desc}</p>
                          </div>

                          <div className="mt-3 pt-2 border-t border-slate-700/50 flex flex-col gap-1 text-xs">
                            {status.isPermanent ? (
                              <span className="text-emerald-400 font-semibold text-[11px] flex items-center gap-1">
                                <Check className="w-3.5 h-3.5" /> Doimiy ochiq
                              </span>
                            ) : isCurrentlyActive ? (
                              <div className="flex items-center justify-between text-[10px] font-mono font-bold text-amber-300 bg-slate-950 px-1.5 py-0.5 rounded">
                                <span className="flex items-center gap-1">
                                  <Clock className="w-3 h-3 text-amber-400" />
                                  <span>{status.days}k {String(status.hours).padStart(2, '0')}:{String(status.minutes).padStart(2, '0')}:{String(status.seconds).padStart(2, '0')}</span>
                                </span>
                              </div>
                            ) : (
                              <div className="flex items-center justify-between text-[10px] font-mono font-bold text-amber-400">
                                <span>7k: 500 🪙</span>
                                <span className="text-slate-400 font-sans">Ochish</span>
                              </div>
                            )}

                            <span className={`text-[10px] font-bold text-center ${
                              isCurrentlyActive ? 'text-amber-300' : 'text-slate-400'
                            }`}>
                              {isCurrentlyActive ? 'Jonli Sinash ▶' : 'Qulflangan'}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Modal Bottom Action Bar */}
            <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
              <div className="text-xs text-slate-400 flex items-center gap-2">
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>O'zgartirishlar darhol 3D personajda saqlanadi</span>
              </div>

              <div className="flex items-center gap-2.5">
                <button
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:bg-slate-800 transition-colors"
                >
                  Bekor qilish
                </button>
                <button
                  onClick={handleSaveAll}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 flex items-center gap-1.5 transition-all transform active:scale-95"
                >
                  <Check className="w-4 h-4" />
                  Saqlash & Boshlash
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
