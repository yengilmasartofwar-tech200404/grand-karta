import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { sounds } from '../utils/audio';

export type CharacterMood = 'idle' | 'thinking' | 'playing' | 'win' | 'lose' | 'laugh' | 'clap' | 'cool' | 'cry' | 'angry' | 'wave';

export interface CharacterCustomization {
  modelId?: string;
  hairColor?: string;
  hairStyle?: 'classic' | 'short' | 'curly' | 'long' | 'spiky' | 'bald' | 'turban';
  skinColor?: string;
  suitColor?: string;
  suitStyle?: 'classic' | 'tuxedo' | 'chapan' | 'hoodie' | 'vest' | 'gold_armor';
  accessory?: 'none' | 'crown' | 'sunglasses' | 'cap' | 'gold_chain' | 'headset' | 'top_hat' | 'monocle' | 'mask';
  facialHair?: 'none' | 'mustache' | 'goatee' | 'full_beard';
  earring?: 'none' | 'gold_ring' | 'diamond';
}

interface ThreeDCharacterProps {
  name: string;
  variant?: string;
  customization?: CharacterCustomization;
  mood?: CharacterMood;
  isThinking?: boolean;
  isSpeaking?: boolean;
  cardsCount?: number;
  className?: string;
  activeEmoji?: string | null;
  triggerKey?: number;
  nameplatePosition?: 'top' | 'bottom' | 'none';
  onEmojiSelect?: (emoji: string) => void;
  showSelfView?: boolean;
}

export const EMOJI_LIST_150: { category: string; emojis: string[] }[] = [
  {
    category: "Yuzlar & Tabassum",
    emojis: ["😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "🥲", "🥹", "😊", "😇", "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙", "😚", "😋", "😛", "😝", "😜"]
  },
  {
    category: "Qiziq & Salbiy",
    emojis: ["🤪", "🤨", "🧐", "🤓", "😎", "🥸", "🤩", "🥳", "😏", "😒", "😞", "😔", "😟", "😕", "🙁", "☹️", "😣", "😖", "😫", "😩", "🥺", "😢", "😭", "😮‍💨", "😤", "😡"]
  },
  {
    category: "Hayrat & Qo'rquv",
    emojis: ["😠", "🤬", "🤯", "😳", "🥵", "🥶", "😱", "😨", "😰", "😥", "😓", "🫣", "🤗", "🫡", "🤔", "🫢", "🤫", "🤥", "😶", "😐", "😑", "😬", "🫨", "🫠", "🥱", "😴"]
  },
  {
    category: "Qo'llar & Harakatlar",
    emojis: ["👋", "🤚", "🖐️", "✋", "🖖", "🫱", "🫲", "🫸", "🫷", "🫵", "🤌", "🤏", "👌", "🫰", "✌️", "🤞", "🫶", "🤟", "🤘", "🤙", "👈", "👉", "👆", "🖕", "👇", "☝️", "👍", "👎", "✊", "👊", "🤛", "🤜", "👏", "🙌", "👐", "🤲", "🤝", "🙏"]
  },
  {
    category: "Karta & Qimor & Boylik",
    emojis: ["♠️", "♥️", "♦️", "♣️", "🃏", "👑", "💎", "💰", "💵", "💸", "🪙", "🏆", "🥇", "🥈", "🥉", "🎖️", "🔥", "⚡", "✨", "⭐", "🌟", "💫", "🎯", "🎲", "🎰", "🎩"]
  },
  {
    category: "Sovg'alar & Taassurot",
    emojis: ["☕", "🍵", "🥤", "🍺", "🥂", "🍕", "🍔", "💐", "🌹", "🎁", "🎈", "🎉", "🎊", "🦁", "🐯", "🐺", "🦅", "🐉", "💣", "🛡️", "⚔️", "🪄", "👀", "🧠", "❤️", "💯"]
  }
];

export const ThreeDCharacter: React.FC<ThreeDCharacterProps> = ({
  name,
  variant = 'alisher',
  customization,
  mood = 'idle',
  isThinking = false,
  isSpeaking = false,
  cardsCount = 6,
  className = '',
  activeEmoji = null,
  triggerKey = 0,
  nameplatePosition = 'top',
  onEmojiSelect,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);

  // Active reaction state inside 3D character (tracks the current action to animate physically)
  const currentActionRef = useRef<string | null>(null);
  const actionEndTimeRef = useRef<number>(0);

  // Listen to activeEmoji prop changes
  useEffect(() => {
    if (activeEmoji) {
      currentActionRef.current = activeEmoji;
      actionEndTimeRef.current = Date.now() + 3800; // 3.8s rich physical animation

      // Play corresponding sound effect for maximum sensory immersion
      if (['👏', '🙌', '🤝', '👐', '🤲'].some(e => activeEmoji.includes(e))) {
        sounds.playClap();
      } else if (['😂', '🤣', '😆', '😄', '😁', '🤪'].some(e => activeEmoji.includes(e))) {
        sounds.playLaugh();
      } else if (['🏆', '👑', '🎉', '🎊', '🥇', '🔥', '⚡', '💯'].some(e => activeEmoji.includes(e))) {
        sounds.playCheer();
      } else {
        sounds.playChip();
      }
    }
  }, [activeEmoji, triggerKey]);

  // Direct click on the 3D character triggers an animated physical reaction
  const handleDirectClick = () => {
    const randomEmojis = ['👋', '👏', '😂', '👍', '🏆', '😎', '🤔'];
    const chosen = randomEmojis[Math.floor(Math.random() * randomEmojis.length)];
    currentActionRef.current = chosen;
    actionEndTimeRef.current = Date.now() + 3800;

    if (['👏', '🙌'].includes(chosen)) sounds.playClap();
    else if (['😂'].includes(chosen)) sounds.playLaugh();
    else if (['🏆'].includes(chosen)) sounds.playCheer();
    else sounds.playChip();

    if (onEmojiSelect) onEmojiSelect(chosen);
  };

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 160;
    const height = container.clientHeight || 180;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    camera.position.set(0, 0.82, 3.15);
    camera.lookAt(0, 0.48, 0);

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    container.appendChild(renderer.domElement);

    // Warm Studio Lighting
    const ambientLight = new THREE.AmbientLight(0xfff8ee, 1.4);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xfffae6, 2.3);
    keyLight.position.set(2, 4, 3);
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x38bdf8, 1.3);
    rimLight.position.set(-2.5, 2.5, -2);
    scene.add(rimLight);

    const fillLight = new THREE.DirectionalLight(0xf59e0b, 0.85);
    fillLight.position.set(0, -1, 2);
    scene.add(fillLight);

    // Main Root Group
    const characterGroup = new THREE.Group();
    scene.add(characterGroup);

    // Resolve Materials
    const skinHex = customization?.skinColor
      ? parseInt(customization.skinColor.replace('#', '0x'), 16)
      : variant === 'malika' || variant === 'lola' || variant === 'kamola'
      ? 0xffded0
      : variant === 'jasur' || variant === 'sarvar'
      ? 0xeac096
      : 0xf2ceb5;

    const skinMat = new THREE.MeshStandardMaterial({
      color: skinHex,
      roughness: 0.55,
      metalness: 0.05,
    });

    const suitHex = customization?.suitColor
      ? parseInt(customization.suitColor.replace('#', '0x'), 16)
      : variant === 'dealer'
      ? 0x09090b
      : variant === 'sheyx'
      ? 0xffffff
      : variant === 'sherzod'
      ? 0x7c2d12
      : variant === 'malika'
      ? 0x831843
      : variant === 'jasur'
      ? 0x065f46
      : 0x1e3a8a;

    const suitMat = new THREE.MeshStandardMaterial({
      color: suitHex,
      roughness: 0.45,
      metalness: 0.12,
    });

    const shirtMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.35 });
    const hairHex = customization?.hairColor
      ? parseInt(customization.hairColor.replace('#', '0x'), 16)
      : variant === 'malika'
      ? 0x2b1d12
      : variant === 'jasur'
      ? 0x18181b
      : 0x3f2e21;

    const hairMat = new THREE.MeshStandardMaterial({ color: hairHex, roughness: 0.75 });
    const goldMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.85, roughness: 0.2 });

    // 1. Torso Group
    const torsoGroup = new THREE.Group();
    torsoGroup.position.y = 0;
    characterGroup.add(torsoGroup);

    const torsoGeo = new THREE.CylinderGeometry(0.36, 0.46, 0.85, 16);
    const torso = new THREE.Mesh(torsoGeo, suitMat);
    torsoGroup.add(torso);

    // Shirt collar
    const collarGeo = new THREE.ConeGeometry(0.2, 0.35, 4);
    const collar = new THREE.Mesh(collarGeo, shirtMat);
    collar.position.set(0, 0.3, 0.28);
    collar.rotation.x = 0.3;
    torsoGroup.add(collar);

    // Bowtie
    const bowtieGeo = new THREE.BoxGeometry(0.16, 0.08, 0.04);
    const bowtie = new THREE.Mesh(bowtieGeo, new THREE.MeshStandardMaterial({ color: 0xdc2626 }));
    bowtie.position.set(0, 0.35, 0.33);
    torsoGroup.add(bowtie);

    // 2. Neck & Head Pivot
    const neckGeo = new THREE.CylinderGeometry(0.14, 0.16, 0.2, 16);
    const neck = new THREE.Mesh(neckGeo, skinMat);
    neck.position.y = 0.5;
    characterGroup.add(neck);

    const headPivot = new THREE.Group();
    headPivot.position.y = 0.65;
    characterGroup.add(headPivot);

    const headGeo = new THREE.SphereGeometry(0.32, 24, 24);
    const head = new THREE.Mesh(headGeo, skinMat);
    head.position.y = 0.3;
    headPivot.add(head);

    // 3. Hair & Accessories
    const accessory = customization?.accessory || (variant === 'sherzod' ? 'crown' : 'none');
    const hairStyle = customization?.hairStyle || (variant === 'samurai' ? 'spiky' : variant === 'malika' ? 'long' : 'classic');

    if (accessory === 'crown' || variant === 'sherzod' || variant === 'malika') {
      const crownGeo = new THREE.CylinderGeometry(0.24, 0.22, 0.16, 8);
      const crown = new THREE.Mesh(crownGeo, goldMat);
      crown.position.set(0, 0.64, 0);
      headPivot.add(crown);
    } else if (accessory === 'cap') {
      const capGeo = new THREE.SphereGeometry(0.33, 16, 16, 0, Math.PI * 2, 0, Math.PI * 0.5);
      const cap = new THREE.Mesh(capGeo, new THREE.MeshStandardMaterial({ color: 0xef4444 }));
      cap.position.set(0, 0.35, 0);
      headPivot.add(cap);
      const visorGeo = new THREE.BoxGeometry(0.3, 0.03, 0.22);
      const visor = new THREE.Mesh(visorGeo, new THREE.MeshStandardMaterial({ color: 0xef4444 }));
      visor.position.set(0, 0.33, 0.32);
      headPivot.add(visor);
    } else if (accessory === 'top_hat' || variant === 'gentleman') {
      const hatBrimGeo = new THREE.CylinderGeometry(0.36, 0.36, 0.03, 16);
      const hatTopGeo = new THREE.CylinderGeometry(0.26, 0.28, 0.35, 16);
      const hatRibbonGeo = new THREE.CylinderGeometry(0.262, 0.262, 0.06, 16);
      const hatMat = new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.2 });
      const ribbonMat = new THREE.MeshStandardMaterial({ color: 0xdc2626 });
      const brim = new THREE.Mesh(hatBrimGeo, hatMat);
      brim.position.set(0, 0.6, 0);
      headPivot.add(brim);
      const top = new THREE.Mesh(hatTopGeo, hatMat);
      top.position.set(0, 0.77, 0);
      headPivot.add(top);
      const ribbon = new THREE.Mesh(hatRibbonGeo, ribbonMat);
      ribbon.position.set(0, 0.64, 0);
      headPivot.add(ribbon);
    } else if (hairStyle === 'turban' || variant === 'sheyx' || variant === 'timur') {
      const turbanGeo = new THREE.TorusGeometry(0.28, 0.12, 12, 24);
      const turbanMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.5 });
      const turban = new THREE.Mesh(turbanGeo, turbanMat);
      turban.position.set(0, 0.48, 0);
      turban.rotation.x = Math.PI / 2;
      headPivot.add(turban);
      const gemGeo = new THREE.OctahedronGeometry(0.06);
      const gem = new THREE.Mesh(gemGeo, goldMat);
      gem.position.set(0, 0.52, 0.3);
      headPivot.add(gem);
    } else if (hairStyle === 'spiky') {
      const baseHairGeo = new THREE.SphereGeometry(0.33, 16, 16, 0, Math.PI * 2, 0, Math.PI * 0.55);
      const baseHair = new THREE.Mesh(baseHairGeo, hairMat);
      baseHair.position.set(0, 0.34, -0.02);
      headPivot.add(baseHair);
      for (let s = -3; s <= 3; s++) {
        const spikeGeo = new THREE.ConeGeometry(0.04, 0.15, 4);
        const spike = new THREE.Mesh(spikeGeo, hairMat);
        spike.position.set(s * 0.08, 0.62, -0.05 + Math.abs(s) * 0.02);
        spike.rotation.z = -s * 0.15;
        spike.rotation.x = -0.2;
        headPivot.add(spike);
      }
    } else if (hairStyle === 'long' || variant === 'malika' || variant === 'kamola') {
      const hairGeo = new THREE.SphereGeometry(0.34, 16, 16, 0, Math.PI * 2, 0, Math.PI * 0.55);
      const hair = new THREE.Mesh(hairGeo, hairMat);
      hair.position.set(0, 0.34, -0.02);
      hair.scale.set(1.03, 1.05, 1.05);
      headPivot.add(hair);
      const sideHairGeo = new THREE.CylinderGeometry(0.06, 0.04, 0.4, 8);
      const leftSideHair = new THREE.Mesh(sideHairGeo, hairMat);
      leftSideHair.position.set(-0.31, 0.15, 0.05);
      headPivot.add(leftSideHair);
      const rightSideHair = new THREE.Mesh(sideHairGeo, hairMat);
      rightSideHair.position.set(0.31, 0.15, 0.05);
      headPivot.add(rightSideHair);
    } else if (hairStyle !== 'bald') {
      const hairGeo = new THREE.SphereGeometry(0.33, 16, 16, 0, Math.PI * 2, 0, Math.PI * 0.55);
      const hair = new THREE.Mesh(hairGeo, hairMat);
      hair.position.set(0, 0.34, -0.02);
      hair.scale.set(1.02, 1.05, 1.05);
      headPivot.add(hair);
    }

    if (accessory === 'headset' || variant === 'kiber') {
      const bandGeo = new THREE.TorusGeometry(0.35, 0.03, 8, 24, Math.PI);
      const earpadGeo = new THREE.CylinderGeometry(0.09, 0.09, 0.06, 12);
      const headsetMat = new THREE.MeshStandardMaterial({ color: 0x06b6d4, metalness: 0.8, roughness: 0.2 });
      const band = new THREE.Mesh(bandGeo, headsetMat);
      band.position.set(0, 0.35, 0);
      band.rotation.x = Math.PI;
      headPivot.add(band);
      const leftPad = new THREE.Mesh(earpadGeo, headsetMat);
      leftPad.position.set(-0.34, 0.28, 0);
      leftPad.rotation.z = Math.PI / 2;
      headPivot.add(leftPad);
      const rightPad = new THREE.Mesh(earpadGeo, headsetMat);
      rightPad.position.set(0.34, 0.28, 0);
      rightPad.rotation.z = Math.PI / 2;
      headPivot.add(rightPad);
      const micArmGeo = new THREE.CylinderGeometry(0.015, 0.015, 0.2, 8);
      const micArm = new THREE.Mesh(micArmGeo, headsetMat);
      micArm.position.set(-0.25, 0.2, 0.18);
      micArm.rotation.x = 0.8;
      micArm.rotation.z = -0.5;
      headPivot.add(micArm);
    }

    if (accessory === 'sunglasses' || variant === 'karleone') {
      const glassesGeo = new THREE.BoxGeometry(0.32, 0.08, 0.04);
      const glasses = new THREE.Mesh(glassesGeo, new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.1 }));
      glasses.position.set(0, 0.33, 0.31);
      headPivot.add(glasses);
    } else if (accessory === 'monocle') {
      const monocleRingGeo = new THREE.TorusGeometry(0.06, 0.008, 8, 16);
      const monocle = new THREE.Mesh(monocleRingGeo, goldMat);
      monocle.position.set(0.12, 0.32, 0.31);
      headPivot.add(monocle);
    }

    if (accessory === 'gold_chain' || variant === 'olmos' || variant === 'sheyx') {
      const chainGeo = new THREE.TorusGeometry(0.26, 0.025, 8, 24);
      const chain = new THREE.Mesh(chainGeo, goldMat);
      chain.position.set(0, 0.38, 0.12);
      chain.rotation.x = 1.1;
      characterGroup.add(chain);
    }

    if (accessory === 'mask') {
      const maskGeo = new THREE.BoxGeometry(0.28, 0.14, 0.05);
      const maskMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.4 });
      const mask = new THREE.Mesh(maskGeo, maskMat);
      mask.position.set(0, 0.2, 0.3);
      headPivot.add(mask);
    }

    // 4. Eyes with Realistic Sclera, Iris, Pupil and Animated Eyelids
    const eyeScleraGeo = new THREE.SphereGeometry(0.048, 16, 16);
    const scleraMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.2 });

    const pupilGeo = new THREE.SphereGeometry(0.026, 12, 12);
    const pupilMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.1 });

    const highlightGeo = new THREE.SphereGeometry(0.008, 8, 8);
    const highlightMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

    const createEye = (isLeft: boolean) => {
      const eyeGroup = new THREE.Group();
      const sclera = new THREE.Mesh(eyeScleraGeo, scleraMat);
      eyeGroup.add(sclera);

      const pupil = new THREE.Mesh(pupilGeo, pupilMat);
      pupil.position.z = 0.026;
      eyeGroup.add(pupil);

      const highlight = new THREE.Mesh(highlightGeo, highlightMat);
      highlight.position.set(0.01, 0.01, 0.046);
      eyeGroup.add(highlight);

      // Upper Eyelid for natural blinking and squinting
      const lidGeo = new THREE.SphereGeometry(0.052, 16, 16, 0, Math.PI * 2, 0, Math.PI * 0.5);
      const eyelid = new THREE.Mesh(lidGeo, skinMat);
      eyelid.rotation.x = Math.PI / 2;
      eyelid.position.z = 0.002;
      eyeGroup.add(eyelid);

      eyeGroup.position.set(isLeft ? -0.115 : 0.115, 0.32, 0.275);
      return { eyeGroup, pupil, eyelid };
    };

    const leftEyeObj = createEye(true);
    const rightEyeObj = createEye(false);
    headPivot.add(leftEyeObj.eyeGroup);
    headPivot.add(rightEyeObj.eyeGroup);

    // 5. Eyebrows (Dynamic Angle & Height)
    const browGeo = new THREE.BoxGeometry(0.095, 0.028, 0.025);
    const leftBrow = new THREE.Mesh(browGeo, hairMat);
    leftBrow.position.set(-0.115, 0.39, 0.295);
    headPivot.add(leftBrow);

    const rightBrow = new THREE.Mesh(browGeo, hairMat);
    rightBrow.position.set(0.115, 0.39, 0.295);
    headPivot.add(rightBrow);

    // 6. Sculpted 3D Ears with Earring Slots
    const earGeo = new THREE.SphereGeometry(0.075, 12, 12);
    earGeo.scale(0.45, 1, 0.7);
    const leftEar = new THREE.Mesh(earGeo, skinMat);
    leftEar.position.set(-0.31, 0.28, 0.02);
    leftEar.rotation.y = -0.25;
    headPivot.add(leftEar);

    const rightEar = new THREE.Mesh(earGeo, skinMat);
    rightEar.position.set(0.31, 0.28, 0.02);
    rightEar.rotation.y = 0.25;
    headPivot.add(rightEar);

    if (customization?.earring === 'gold_ring' || variant === 'qaroqchi' || variant === 'olmos') {
      const ringGeo = new THREE.TorusGeometry(0.035, 0.008, 8, 16);
      const ringMesh = new THREE.Mesh(ringGeo, goldMat);
      ringMesh.position.set(-0.32, 0.22, 0.02);
      ringMesh.rotation.y = Math.PI / 2;
      headPivot.add(ringMesh);
    } else if (customization?.earring === 'diamond' || variant === 'malika' || variant === 'kamola') {
      const diamondGeo = new THREE.OctahedronGeometry(0.035);
      const diamondMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, metalness: 0.9, roughness: 0.1 });
      const leftDiamond = new THREE.Mesh(diamondGeo, diamondMat);
      leftDiamond.position.set(-0.32, 0.22, 0.02);
      headPivot.add(leftDiamond);
      const rightDiamond = new THREE.Mesh(diamondGeo, diamondMat);
      rightDiamond.position.set(0.32, 0.22, 0.02);
      headPivot.add(rightDiamond);
    }

    // 7. Sculpted 3D Nose
    const noseGeo = new THREE.ConeGeometry(0.04, 0.09, 6);
    const nose = new THREE.Mesh(noseGeo, skinMat);
    nose.position.set(0, 0.27, 0.325);
    nose.rotation.x = -0.22;
    headPivot.add(nose);

    // 8. Expressive 3D Mouth Cavity, Lips & Teeth
    const mouthGroup = new THREE.Group();
    mouthGroup.position.set(0, 0.18, 0.295);
    headPivot.add(mouthGroup);

    const lipMat = new THREE.MeshStandardMaterial({ color: 0x9f1239, roughness: 0.5 });
    const lipGeo = new THREE.CapsuleGeometry(0.022, 0.07, 4, 8);
    lipGeo.rotateZ(Math.PI / 2);
    const lips = new THREE.Mesh(lipGeo, lipMat);
    mouthGroup.add(lips);

    const innerMouthGeo = new THREE.PlaneGeometry(0.08, 0.03);
    const innerMouthMat = new THREE.MeshBasicMaterial({ color: 0x3f0514, side: THREE.DoubleSide });
    const innerMouth = new THREE.Mesh(innerMouthGeo, innerMouthMat);
    innerMouth.position.z = 0.005;
    mouthGroup.add(innerMouth);

    const teethGeo = new THREE.BoxGeometry(0.058, 0.015, 0.012);
    const teethMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.2 });
    const upperTeeth = new THREE.Mesh(teethGeo, teethMat);
    upperTeeth.position.set(0, 0.008, 0.008);
    mouthGroup.add(upperTeeth);

    // Facial Hair
    const facialHair = customization?.facialHair || (variant === 'karleone' ? 'mustache' : variant === 'viking' ? 'full_beard' : variant === 'samurai' ? 'goatee' : 'none');
    if (facialHair === 'mustache') {
      const mustacheGeo = new THREE.BoxGeometry(0.14, 0.03, 0.03);
      const mustache = new THREE.Mesh(mustacheGeo, hairMat);
      mustache.position.set(0, 0.22, 0.315);
      headPivot.add(mustache);
    } else if (facialHair === 'full_beard') {
      const beardGeo = new THREE.ConeGeometry(0.2, 0.32, 8);
      const beard = new THREE.Mesh(beardGeo, hairMat);
      beard.position.set(0, 0.1, 0.26);
      beard.rotation.x = 0.45;
      headPivot.add(beard);
    } else if (facialHair === 'goatee') {
      const goateeGeo = new THREE.BoxGeometry(0.06, 0.07, 0.03);
      const goatee = new THREE.Mesh(goateeGeo, hairMat);
      goatee.position.set(0, 0.13, 0.285);
      headPivot.add(goatee);
    }

    // 9. Fully Articulated Arms (Shoulder Pivot -> Upper Arm -> Elbow Joint -> Forearm -> Hand with Fingers)
    const upperArmGeo = new THREE.CylinderGeometry(0.08, 0.07, 0.26, 12);
    const forearmGeo = new THREE.CylinderGeometry(0.07, 0.06, 0.24, 12);
    const handGeo = new THREE.SphereGeometry(0.065, 12, 12);
    handGeo.scale(0.8, 1, 0.6);
    const thumbGeo = new THREE.BoxGeometry(0.025, 0.055, 0.025);

    const createArm = (isLeft: boolean) => {
      // Shoulder pivot
      const shoulderPivot = new THREE.Group();
      shoulderPivot.position.set(isLeft ? -0.42 : 0.42, 0.34, 0);

      const upperArmMesh = new THREE.Mesh(upperArmGeo, suitMat);
      upperArmMesh.position.y = -0.13;
      shoulderPivot.add(upperArmMesh);

      // Elbow joint
      const elbowPivot = new THREE.Group();
      elbowPivot.position.y = -0.26;
      shoulderPivot.add(elbowPivot);

      const forearmMesh = new THREE.Mesh(forearmGeo, suitMat);
      forearmMesh.position.y = -0.12;
      elbowPivot.add(forearmMesh);

      // Hand
      const handPivot = new THREE.Group();
      handPivot.position.y = -0.24;
      elbowPivot.add(handPivot);

      const handMesh = new THREE.Mesh(handGeo, skinMat);
      handPivot.add(handMesh);

      const thumbMesh = new THREE.Mesh(thumbGeo, skinMat);
      thumbMesh.position.set(isLeft ? 0.04 : -0.04, 0.02, 0.03);
      handPivot.add(thumbMesh);

      characterGroup.add(shoulderPivot);
      return { shoulderPivot, elbowPivot, handPivot, thumbMesh };
    };

    const leftArm = createArm(true);
    const rightArm = createArm(false);

    // 10. Fan of 3D Cards held in Hands
    const cardsFanGroup = new THREE.Group();
    cardsFanGroup.position.set(0, 0.06, 0.45);
    characterGroup.add(cardsFanGroup);

    const cardMiniGeo = new THREE.BoxGeometry(0.18, 0.26, 0.008);
    const cardMiniBackMat = new THREE.MeshStandardMaterial({ color: 0x1e3a8a, roughness: 0.3 });
    const cardMiniFrontMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.3 });

    const displayCount = Math.min(Math.max(cardsCount, 1), 6);
    for (let c = 0; c < displayCount; c++) {
      const angle = (c - displayCount / 2 + 0.5) * 0.15;
      const cardMini = new THREE.Mesh(cardMiniGeo, [
        cardMiniBackMat,
        cardMiniBackMat,
        cardMiniBackMat,
        cardMiniBackMat,
        cardMiniBackMat,
        cardMiniFrontMat,
      ]);
      cardMini.position.set(Math.sin(angle) * 0.15, 0, Math.cos(angle) * 0.05 + c * 0.005);
      cardMini.rotation.z = -angle * 0.8;
      cardMini.rotation.x = -0.3;
      cardsFanGroup.add(cardMini);
    }

    // Animation Loop with Smooth Physics Damping
    let animationFrameId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();
      const nowMs = Date.now();

      // Natural Breathing & Subtle Torso Physics
      torso.scale.x = 1 + Math.sin(elapsed * 2.2) * 0.02;
      torso.scale.z = 1 + Math.sin(elapsed * 2.2) * 0.02;
      characterGroup.position.y = Math.sin(elapsed * 2.2) * 0.01;

      // Natural Eye Blinking cycle every 3.5s (0.12s duration blink)
      const blinkCycle = elapsed % 3.5;
      const isBlinking = blinkCycle > 3.35;
      const blinkScale = isBlinking ? 0.05 : 1.0;
      leftEyeObj.eyelid.scale.y = blinkScale;
      rightEyeObj.eyelid.scale.y = blinkScale;

      // Determine active action: check if emoji action is currently running
      const isActionActive = currentActionRef.current && nowMs < actionEndTimeRef.current;
      const activeAction = isActionActive ? currentActionRef.current : null;

      // Target pose variables
      let targetHeadRotX = Math.cos(elapsed * 0.8) * 0.04;
      let targetHeadRotY = Math.sin(elapsed * 0.9) * 0.06;
      let targetHeadRotZ = 0;

      let targetLeftShoulderRotX = 0.35;
      let targetLeftShoulderRotY = 0.2;
      let targetLeftShoulderRotZ = -0.2;
      let targetLeftElbowRotX = -0.7;

      let targetRightShoulderRotX = 0.35;
      let targetRightShoulderRotY = -0.2;
      let targetRightShoulderRotZ = 0.2;
      let targetRightElbowRotX = -0.7;

      let targetMouthScaleY = 1.0;
      let targetMouthScaleX = 1.0;
      let targetLeftBrowY = 0.39;
      let targetRightBrowY = 0.39;
      let targetLeftBrowRotZ = 0;
      let targetRightBrowRotZ = 0;

      let targetCardsFanVisible = true;
      let targetCardsFanY = 0.06;

      // Check Emoji Category & Mood & Specific Action Keys
      const emoji = activeAction;

      const isWaving = emoji && ['👋', '🤚', '🖐️', '✋', '🙋', 'anim_salom'].some(e => emoji.includes(e));
      const isClapping = mood === 'clap' || (emoji && ['👏', '🤝', '👐', '🤲', 'anim_qarsak'].some(e => emoji.includes(e)));
      const isLaughing = mood === 'laugh' || (emoji && ['😂', '🤣', '😆', '😄', '😁', '🤪', '😜', '😝', '😋', '😅', 'anim_qahqaha'].some(e => emoji.includes(e)));
      const isVictory = mood === 'win' || (emoji && ['🏆', '👑', '🎉', '🎊', '🥇', '🥈', '🥉', '🎖️', '🔥', '⚡', '🌟', '⭐', '💫', '💯', 'anim_galaba_sakrash'].some(e => emoji.includes(e)));
      const isThumbsUp = emoji && ['👍', '👌', '✌️', '🤙', '🫰', '☝️', '🤌', 'anim_zor'].some(e => emoji.includes(e));
      const isThinkingAction = isThinking || mood === 'thinking' || (emoji && ['🤔', '🧐', '🤨', '🤫', '🫡', '👀', '🧠', '🤥', '😶', '😐', '😑', '😬', '🥱', 'anim_oylash'].some(e => emoji.includes(e)));
      const isCoolSwagger = mood === 'cool' || (emoji && ['😎', '🎩', '💎', '💰', '💵', '🪙', '🎰', '🃏', '♠️', '♥️', '♦️', '♣️', '😏', 'anim_salobat'].some(e => emoji.includes(e)));
      const isCryingSad = mood === 'lose' || mood === 'cry' || (emoji && ['😭', '😢', '🥺', '😞', '😔', '😟', '🙁', '☹️', '😩', '😫', '💔', '😿', 'anim_yiglash'].some(e => emoji.includes(e)));
      const isAngryRage = mood === 'angry' || (emoji && ['😡', '😠', '🤬', '😤', '👿', '💣', '🖕', '👎', '👊', '✊', 'anim_gazab'].some(e => emoji.includes(e)));
      const isShockGasp = emoji && ['😱', '🤯', '😳', '🥵', '🥶', '🫣', '🫨', '😮‍💨', '🫢', 'anim_hayrat'].some(e => emoji.includes(e));
      const isLoveHearts = emoji && ['❤️', '😍', '🥰', '😘', '😗', '😙', '😚', '🫶', '🌹', '💐', 'anim_mehr'].some(e => emoji.includes(e));
      const isDrinkingFood = emoji && ['☕', '🍵', '🥤', '🍺', '🥂', '🍕', '🍔', '🎁', '🎈', '🪄', 'anim_kofe'].some(e => emoji.includes(e));
      const isStrongFlex = emoji && ['💪', '🦁', '🐯', '🐺', '🦅', '🐉', 'anim_musht'].some(e => emoji.includes(e));
      const isDance = emoji && ['🕺', '💃', 'anim_raqs'].some(e => emoji.includes(e));
      const isBow = emoji && ['🙏', 'anim_tazim'].some(e => emoji.includes(e));
      const isMoneyRain = emoji && ['💸', 'anim_tanga_yomgiri'].some(e => emoji.includes(e));

      // 1. WAVING (👋) - Right hand high, waving enthusiastically
      if (isWaving) {
        targetHeadRotY = 0.12;
        targetHeadRotZ = -0.08;
        targetHeadRotX = Math.sin(elapsed * 6) * 0.05;

        // Right arm up and waving
        targetRightShoulderRotX = -1.35;
        targetRightShoulderRotZ = 0.55;
        targetRightElbowRotX = -0.7 + Math.sin(elapsed * 12) * 0.45;
        rightArm.handPivot.rotation.z = Math.sin(elapsed * 12) * 0.5;

        // Warm smile
        targetMouthScaleX = 1.35;
        targetMouthScaleY = 1.6;
        targetLeftBrowY = 0.41;
        targetRightBrowY = 0.41;
      }
      // 2. CLAPPING (👏) - Both hands come together in front of chest & clap rhythmically
      else if (isClapping) {
        const clapCycle = Math.sin(elapsed * 16);
        targetHeadRotX = Math.sin(elapsed * 8) * 0.08;
        characterGroup.position.y = Math.abs(Math.sin(elapsed * 8)) * 0.04;

        targetLeftShoulderRotX = -0.55;
        targetLeftShoulderRotY = 0.75 + clapCycle * 0.22;
        targetLeftShoulderRotZ = -0.15;
        targetLeftElbowRotX = -1.15;

        targetRightShoulderRotX = -0.55;
        targetRightShoulderRotY = -0.75 - clapCycle * 0.22;
        targetRightShoulderRotZ = 0.15;
        targetRightElbowRotX = -1.15;

        targetMouthScaleX = 1.3;
        targetMouthScaleY = 1.7;
        targetCardsFanY = -0.2;
      }
      // 3. LAUGHING (😂, 🤣) - Head thrown back, chest shaking, belly laughing
      else if (isLaughing) {
        const laughShake = Math.sin(elapsed * 14);
        targetHeadRotX = -0.25 + laughShake * 0.12;
        targetHeadRotZ = Math.sin(elapsed * 10) * 0.08;
        characterGroup.position.y = Math.abs(laughShake) * 0.07;

        // Left arm holding stomach, right arm bouncing
        targetLeftShoulderRotX = 0.4;
        targetLeftShoulderRotY = 0.5;
        targetLeftElbowRotX = -1.1;

        targetRightShoulderRotX = -0.15 + laughShake * 0.15;
        targetRightElbowRotX = -0.8;

        // Wide open mouth with white teeth showing
        targetMouthScaleX = 1.5;
        targetMouthScaleY = 2.4;
        targetLeftBrowY = 0.42;
        targetRightBrowY = 0.42;

        // Squinting eyes in laughter
        leftEyeObj.eyelid.scale.y = 0.4;
        rightEyeObj.eyelid.scale.y = 0.4;
      }
      // 4. VICTORY / CHEER (🏆, 👑, 🔥) - Double arms in the air, jumping triumphantly
      else if (isVictory) {
        const jumpY = Math.abs(Math.sin(elapsed * 8)) * 0.12;
        characterGroup.position.y = jumpY;
        targetHeadRotX = -0.18 + Math.sin(elapsed * 8) * 0.09;
        targetHeadRotZ = Math.sin(elapsed * 6) * 0.12;

        // Both arms raised high V-shape
        targetLeftShoulderRotX = -1.6;
        targetLeftShoulderRotZ = -0.7;
        targetLeftElbowRotX = -0.4 + Math.sin(elapsed * 8) * 0.25;

        targetRightShoulderRotX = -1.6;
        targetRightShoulderRotZ = 0.7;
        targetRightElbowRotX = -0.4 + Math.sin(elapsed * 8) * 0.25;

        targetMouthScaleX = 1.4;
        targetMouthScaleY = 2.2;
        targetCardsFanVisible = false;
      }
      // 5. THUMBS UP (👍, 👌) - Direct forward thumb pointing, proud nod
      else if (isThumbsUp) {
        targetHeadRotX = Math.sin(elapsed * 6) * 0.12;
        targetHeadRotY = -0.1;

        // Right arm extends forward with thumb up
        targetRightShoulderRotX = -0.9;
        targetRightShoulderRotY = -0.15;
        targetRightShoulderRotZ = 0.1;
        targetRightElbowRotX = -0.6;
        rightArm.thumbMesh.scale.set(1.4, 1.8, 1.4);

        targetMouthScaleX = 1.25;
        targetMouthScaleY = 1.4;
        targetRightBrowY = 0.43; // wink / brow arch
      }
      // 6. THINKING (🤔) - Hand on chin, head tilted, eyes glancing up
      else if (isThinkingAction) {
        targetHeadRotZ = 0.15;
        targetHeadRotX = 0.08;
        targetHeadRotY = 0.2 + Math.sin(elapsed * 2) * 0.08;

        // Right hand touching chin
        targetRightShoulderRotX = -0.6;
        targetRightShoulderRotY = -0.4;
        targetRightShoulderRotZ = 0.1;
        targetRightElbowRotX = -1.6;

        // One brow raised in skepticism
        targetRightBrowY = 0.44;
        targetRightBrowRotZ = 0.12;
        targetLeftBrowY = 0.38;

        targetMouthScaleX = 0.85;
        targetMouthScaleY = 0.9;
      }
      // 7. COOL SWAGGER (😎, 🎩) - Slow swagger, adjusting glasses
      else if (isCoolSwagger) {
        targetHeadRotY = Math.sin(elapsed * 2) * 0.2 + 0.1;
        targetHeadRotX = -0.12;
        targetHeadRotZ = 0.06;

        // Hand touches glasses or collar
        targetRightShoulderRotX = -0.75;
        targetRightShoulderRotY = -0.3;
        targetRightElbowRotX = -1.3;

        // Asymmetric smirk
        mouthGroup.position.x = 0.02;
        mouthGroup.rotation.z = 0.12;
        targetMouthScaleX = 1.2;
        targetMouthScaleY = 1.2;
      }
      // 8. CRYING / SAD (😭, 😢) - Head down, hands wiping eyes, sobs
      else if (isCryingSad) {
        const sobShake = Math.sin(elapsed * 12) * 0.03;
        targetHeadRotX = 0.38 + sobShake;
        characterGroup.position.y = -0.06 + sobShake;

        // Both hands up near eyes
        targetLeftShoulderRotX = -0.85;
        targetLeftShoulderRotY = 0.45;
        targetLeftElbowRotX = -1.5;

        targetRightShoulderRotX = -0.85;
        targetRightShoulderRotY = -0.45;
        targetRightElbowRotX = -1.5;

        // Sad angled eyebrows
        targetLeftBrowY = 0.41;
        targetLeftBrowRotZ = -0.15;
        targetRightBrowY = 0.41;
        targetRightBrowRotZ = 0.15;

        // Downward quivering mouth
        mouthGroup.rotation.z = Math.PI;
        targetMouthScaleX = 0.9;
        targetMouthScaleY = 1.5;
      }
      // 9. ANGRY (😡, 🤬) - Clenched shaking fists, furious scowl
      else if (isAngryRage) {
        const rageShake = Math.sin(elapsed * 26) * 0.05;
        targetHeadRotX = 0.16 + rageShake;
        targetHeadRotY = Math.cos(elapsed * 22) * 0.06;

        // Tense elbows back, fists clenched
        targetLeftShoulderRotX = 0.3;
        targetLeftShoulderRotZ = -0.45 + rageShake;
        targetLeftElbowRotX = -1.3;

        targetRightShoulderRotX = 0.3;
        targetRightShoulderRotZ = 0.45 - rageShake;
        targetRightElbowRotX = -1.3;

        // Fierce V-shaped eyebrows
        targetLeftBrowY = 0.37;
        targetLeftBrowRotZ = 0.22;
        targetRightBrowY = 0.37;
        targetRightBrowRotZ = -0.22;

        targetMouthScaleX = 1.35;
        targetMouthScaleY = 0.7; // bared teeth grimace
      }
      // 10. SHOCK / MIND BLOWN (😱, 🤯) - Hands to face, jaw dropped
      else if (isShockGasp) {
        characterGroup.position.z = -0.18;
        targetHeadRotX = -0.22;

        targetLeftShoulderRotX = -0.8;
        targetLeftShoulderRotY = 0.4;
        targetLeftElbowRotX = -1.45;

        targetRightShoulderRotX = -0.8;
        targetRightShoulderRotY = -0.4;
        targetRightElbowRotX = -1.45;

        // Both brows raised high
        targetLeftBrowY = 0.44;
        targetRightBrowY = 0.44;

        // Tall open 'O' mouth
        targetMouthScaleX = 0.8;
        targetMouthScaleY = 2.6;
      }
      // 11. LOVE (❤️, 😍) - Hands over heart, gentle sweet swaying
      else if (isLoveHearts) {
        targetHeadRotZ = Math.sin(elapsed * 2) * 0.15;
        targetHeadRotX = 0.05;
        characterGroup.position.y = Math.sin(elapsed * 2.5) * 0.02;

        // Hands over heart
        targetLeftShoulderRotX = -0.45;
        targetLeftShoulderRotY = 0.55;
        targetLeftElbowRotX = -1.2;

        targetRightShoulderRotX = -0.35;
        targetRightShoulderRotY = -0.4;
        targetRightElbowRotX = -1.0;

        targetMouthScaleX = 1.25;
        targetMouthScaleY = 1.5;
      }
      // 12. DRINKING / COFFEE / FOOD (☕)
      else if (isDrinkingFood) {
        targetHeadRotX = -0.15 + Math.sin(elapsed * 3) * 0.08;

        targetRightShoulderRotX = -0.7;
        targetRightShoulderRotY = -0.25;
        targetRightElbowRotX = -1.5;

        targetMouthScaleX = 0.9;
        targetMouthScaleY = 1.2;
      }
      // 13. STRONG FLEX (💪, 🦁) - Double bicep flex
      else if (isStrongFlex) {
        characterGroup.position.y = 0.04;
        targetHeadRotX = -0.1;

        targetLeftShoulderRotX = -0.85;
        targetLeftShoulderRotZ = -0.7;
        targetLeftElbowRotX = -1.6;

        targetRightShoulderRotX = -0.85;
        targetRightShoulderRotZ = 0.7;
        targetRightElbowRotX = -1.6;

        targetMouthScaleX = 1.35;
        targetMouthScaleY = 1.6;
      }
      // 14. VICTORY DANCE (🕺, 💃, anim_raqs) - Groovy dance
      else if (isDance) {
        const danceBeat = Math.sin(elapsed * 10);
        characterGroup.position.y = Math.abs(danceBeat) * 0.08;
        characterGroup.position.x = Math.sin(elapsed * 5) * 0.06;
        targetHeadRotZ = Math.sin(elapsed * 10) * 0.18;
        targetHeadRotY = Math.cos(elapsed * 5) * 0.15;

        targetLeftShoulderRotX = -0.8 + danceBeat * 0.35;
        targetLeftShoulderRotZ = -0.5;
        targetLeftElbowRotX = -0.9 + danceBeat * 0.4;

        targetRightShoulderRotX = -0.8 - danceBeat * 0.35;
        targetRightShoulderRotZ = 0.5;
        targetRightElbowRotX = -0.9 - danceBeat * 0.4;

        targetMouthScaleX = 1.4;
        targetMouthScaleY = 1.7;
      }
      // 15. ARISTOCRAT / EASTERN BOW (🙏, anim_tazim) - Polite bow
      else if (isBow) {
        targetHeadRotX = 0.32;
        characterGroup.position.y = -0.04;

        targetLeftShoulderRotX = -0.5;
        targetLeftShoulderRotY = 0.7;
        targetLeftElbowRotX = -1.2;

        targetRightShoulderRotX = -0.5;
        targetRightShoulderRotY = -0.7;
        targetRightElbowRotX = -1.2;

        targetMouthScaleX = 1.15;
        targetMouthScaleY = 1.2;
      }
      // 16. MONEY RAIN / TANGALARNI SANASH (💸, anim_tanga_yomgiri) - Rubbing hands
      else if (isMoneyRain) {
        const rubCycle = Math.sin(elapsed * 18);
        targetHeadRotX = 0.1;
        targetHeadRotZ = rubCycle * 0.05;

        targetLeftShoulderRotX = -0.6;
        targetLeftShoulderRotY = 0.5 + rubCycle * 0.15;
        targetLeftElbowRotX = -1.3;

        targetRightShoulderRotX = -0.6;
        targetRightShoulderRotY = -0.5 - rubCycle * 0.15;
        targetRightElbowRotX = -1.3;

        targetMouthScaleX = 1.35;
        targetMouthScaleY = 1.8;
      }
      // 14. SPEAKING / VOICE MIC
      else if (isSpeaking) {
        targetHeadRotX = Math.sin(elapsed * 12) * 0.06;
        targetHeadRotY = Math.cos(elapsed * 6) * 0.05;

        // Dynamic talking mouth
        targetMouthScaleY = 1.0 + Math.abs(Math.sin(elapsed * 16)) * 2.2;
        targetMouthScaleX = 1.1 - Math.abs(Math.sin(elapsed * 16)) * 0.15;
      }
      // 15. DEFAULT ACTIVE ACTION (Any other emoji) - Lively head nod & waving hands
      else if (emoji) {
        targetHeadRotX = Math.sin(elapsed * 8) * 0.14;
        targetHeadRotY = Math.sin(elapsed * 4) * 0.16;

        targetRightShoulderRotX = -0.6 + Math.sin(elapsed * 8) * 0.25;
        targetRightElbowRotX = -0.8;

        targetMouthScaleX = 1.25;
        targetMouthScaleY = 1.5;
      }

      // Smoothly interpolate (damp) all transform targets using exponential damping
      const dampFactor = 0.14;
      headPivot.rotation.x += (targetHeadRotX - headPivot.rotation.x) * dampFactor;
      headPivot.rotation.y += (targetHeadRotY - headPivot.rotation.y) * dampFactor;
      headPivot.rotation.z += (targetHeadRotZ - headPivot.rotation.z) * dampFactor;

      leftArm.shoulderPivot.rotation.x += (targetLeftShoulderRotX - leftArm.shoulderPivot.rotation.x) * dampFactor;
      leftArm.shoulderPivot.rotation.y += (targetLeftShoulderRotY - leftArm.shoulderPivot.rotation.y) * dampFactor;
      leftArm.shoulderPivot.rotation.z += (targetLeftShoulderRotZ - leftArm.shoulderPivot.rotation.z) * dampFactor;
      leftArm.elbowPivot.rotation.x += (targetLeftElbowRotX - leftArm.elbowPivot.rotation.x) * dampFactor;

      rightArm.shoulderPivot.rotation.x += (targetRightShoulderRotX - rightArm.shoulderPivot.rotation.x) * dampFactor;
      rightArm.shoulderPivot.rotation.y += (targetRightShoulderRotY - rightArm.shoulderPivot.rotation.y) * dampFactor;
      rightArm.shoulderPivot.rotation.z += (targetRightShoulderRotZ - rightArm.shoulderPivot.rotation.z) * dampFactor;
      rightArm.elbowPivot.rotation.x += (targetRightElbowRotX - rightArm.elbowPivot.rotation.x) * dampFactor;

      mouthGroup.scale.x += (targetMouthScaleX - mouthGroup.scale.x) * dampFactor;
      mouthGroup.scale.y += (targetMouthScaleY - mouthGroup.scale.y) * dampFactor;

      leftBrow.position.y += (targetLeftBrowY - leftBrow.position.y) * dampFactor;
      rightBrow.position.y += (targetRightBrowY - rightBrow.position.y) * dampFactor;
      leftBrow.rotation.z += (targetLeftBrowRotZ - leftBrow.rotation.z) * dampFactor;
      rightBrow.rotation.z += (targetRightBrowRotZ - rightBrow.rotation.z) * dampFactor;

      cardsFanGroup.visible = targetCardsFanVisible;
      cardsFanGroup.position.y += (targetCardsFanY - cardsFanGroup.position.y) * dampFactor;

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      if (renderer.domElement && container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
      torsoGeo.dispose();
      headGeo.dispose();
      skinMat.dispose();
      suitMat.dispose();
      hairMat.dispose();
    };
  }, [variant, customization, mood, isThinking, isSpeaking, cardsCount]);

  const nameplateJSX = nameplatePosition !== 'none' && (
    <div className={`flex flex-col items-center ${nameplatePosition === 'top' ? 'mb-1' : 'mt-1'}`}>
      <div className="flex items-center gap-1.5 bg-slate-950/80 px-2.5 py-0.5 rounded-full border border-emerald-700/40 shadow">
        <span className="text-xs sm:text-sm font-bold text-slate-100 font-serif drop-shadow">
          {name}
        </span>
        {isThinking && (
          <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
        )}
      </div>

      <div className="flex items-center gap-1 text-[10px] font-mono text-emerald-300/80 mt-0.5">
        <span>{cardsCount} ta karta</span>
        {isThinking && <span>· O'ylamoqda...</span>}
      </div>
    </div>
  );

  return (
    <div className={`relative flex flex-col items-center select-none ${className}`}>
      {/* Top Nameplate if requested */}
      {nameplatePosition === 'top' && nameplateJSX}

      {/* Speaking voice sound wave indicator */}
      {isSpeaking && (
        <div className="absolute -top-3 z-30 flex items-center gap-1 bg-emerald-500/90 text-white px-2 py-0.5 rounded-full text-[10px] font-bold shadow-md shadow-emerald-500/30 animate-pulse">
          <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
          <span>Gapirmoqda...</span>
        </div>
      )}

      {/* 3D WebGL Canvas - clicking character directly triggers lively random reaction */}
      <div
        ref={mountRef}
        className="w-32 h-36 sm:w-40 sm:h-44 rounded-2xl overflow-hidden cursor-pointer flex items-center justify-center transition-transform hover:scale-105 active:scale-95"
        onClick={handleDirectClick}
        title="3D personajga bosing va jonli harakat qiling!"
      />

      {/* Bottom Nameplate if requested */}
      {nameplatePosition === 'bottom' && nameplateJSX}
    </div>
  );
};
