import React from 'react';
import { Card, Suit } from '../types/cards';
import { getSuitInfo } from '../utils/cardUtils';

interface PlayingCardProps {
  card: Card;
  faceUp?: boolean;
  isPlayable?: boolean;
  isSelected?: boolean;
  isTrump?: boolean;
  trumpSuit?: Suit;
  onClick?: () => void;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  rotation?: number;
  cardBackTheme?: string;
}

export const PlayingCard: React.FC<PlayingCardProps> = ({
  card,
  faceUp = true,
  isPlayable = false,
  isSelected = false,
  isTrump = false,
  trumpSuit,
  onClick,
  size = 'md',
  className = '',
  rotation = 0,
  cardBackTheme = 'royal_blue',
}) => {
  const suitInfo = getSuitInfo(card.suit);
  const isCardTrump = isTrump || (trumpSuit && card.suit === trumpSuit);

  const sizeClasses = {
    sm: 'w-12 h-18 sm:w-14 sm:h-20 text-xs',
    md: 'w-16 h-24 sm:w-20 sm:h-28 text-sm',
    lg: 'w-20 h-30 sm:w-24 sm:h-36 text-base',
  }[size];

  const cardBackBg =
    cardBackTheme === 'ruby_red'
      ? 'from-red-900 via-rose-950 to-slate-900'
      : cardBackTheme === 'golden_gold'
      ? 'from-amber-700 via-yellow-950 to-slate-900'
      : 'from-blue-900 via-indigo-950 to-slate-900';

  // Face down design: Royal geometric luxury card back
  if (!faceUp) {
    return (
      <div
        onClick={onClick}
        style={{ transform: `rotate(${rotation}deg)` }}
        className={`relative ${sizeClasses} rounded-lg select-none transition-all duration-200 shadow-md ${
          onClick ? 'cursor-pointer hover:-translate-y-1' : ''
        } ${className}`}
      >
        <div className={`w-full h-full rounded-lg border-2 border-amber-300/40 bg-gradient-to-br ${cardBackBg} p-1 flex items-center justify-center overflow-hidden`}>
          {/* Inner ornamental border */}
          <div className="w-full h-full rounded border border-amber-400/30 bg-black/40 flex flex-col items-center justify-center relative p-1">
            <div className="absolute inset-1 border border-dashed border-amber-300/20 rounded-xs pointer-events-none" />
            <div className="text-amber-400/70 text-lg sm:text-2xl font-serif">✦</div>
            <div className="text-[9px] font-mono tracking-widest text-amber-200/50 uppercase">KARTA</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      onClick={isPlayable || onClick ? onClick : undefined}
      style={{
        transform: `${isSelected ? 'translateY(-14px)' : ''} rotate(${rotation}deg)`,
      }}
      className={`relative ${sizeClasses} rounded-lg bg-white border select-none transition-all duration-200 ${
        isPlayable
          ? 'cursor-pointer border-emerald-400 ring-2 ring-emerald-400/50 hover:-translate-y-2.5 shadow-lg'
          : isSelected
          ? 'border-amber-400 ring-2 ring-amber-400 shadow-xl'
          : 'border-slate-300/80 shadow-md'
      } ${!isPlayable && onClick ? 'cursor-pointer hover:-translate-y-1' : ''} ${className}`}
      aria-label={`${suitInfo.nameUz} ${card.rank}`}
    >
      {/* Trump badge indicator */}
      {isCardTrump && (
        <div
          title="Kozir karta"
          className="absolute -top-1.5 -right-1.5 z-10 w-4 h-4 sm:w-5 sm:h-5 rounded-full bg-amber-500 border border-amber-200 text-white flex items-center justify-center text-[10px] font-bold shadow-sm"
        >
          ★
        </div>
      )}

      {/* Top Left Rank and Suit */}
      <div className={`absolute top-1 left-1.5 flex flex-col items-center leading-none ${suitInfo.isRed ? 'text-red-600' : 'text-slate-900'}`}>
        <span className="font-bold text-xs sm:text-sm tracking-tight font-sans">{card.rank}</span>
        <span className="text-xs sm:text-sm">{suitInfo.symbol}</span>
      </div>

      {/* Center artwork / Suit */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        {['J', 'Q', 'K', 'A'].includes(card.rank) ? (
          <div className="flex flex-col items-center justify-center">
            <span
              className={`text-2xl sm:text-3xl font-serif font-black ${
                suitInfo.isRed ? 'text-red-600/90' : 'text-slate-800'
              }`}
            >
              {card.rank === 'A' ? suitInfo.symbol : card.rank}
            </span>
            <span className={`text-[10px] sm:text-xs font-semibold uppercase ${suitInfo.isRed ? 'text-red-500/70' : 'text-slate-500'}`}>
              {card.rank === 'J' ? 'Valet' : card.rank === 'Q' ? 'Dama' : card.rank === 'K' ? 'Qirol' : 'Tuz'}
            </span>
          </div>
        ) : (
          <span className={`text-2xl sm:text-3xl ${suitInfo.isRed ? 'text-red-600' : 'text-slate-800'}`}>
            {suitInfo.symbol}
          </span>
        )}
      </div>

      {/* Bottom Right Inverted Rank and Suit */}
      <div
        className={`absolute bottom-1 right-1.5 flex flex-col items-center leading-none rotate-180 ${
          suitInfo.isRed ? 'text-red-600' : 'text-slate-900'
        }`}
      >
        <span className="font-bold text-xs sm:text-sm tracking-tight font-sans">{card.rank}</span>
        <span className="text-xs sm:text-sm">{suitInfo.symbol}</span>
      </div>
    </div>
  );
};
