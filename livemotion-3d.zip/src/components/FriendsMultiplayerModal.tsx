import React, { useState } from 'react';
import { UserProfileData, MultiplayerRoom, createRoom, joinRoomByCode } from '../lib/firebase';
import { sounds } from '../utils/audio';
import { 
  X, 
  Users, 
  PlusCircle, 
  LogIn, 
  Share2, 
  Copy, 
  Check, 
  Swords, 
  Smartphone,
  Play
} from 'lucide-react';

interface FriendsMultiplayerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfileData;
  onStartRoomGame: (room: MultiplayerRoom) => void;
  onStartPassAndPlay: (game: 'durak' | 'ochko') => void;
}

export const FriendsMultiplayerModal: React.FC<FriendsMultiplayerModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onStartRoomGame,
  onStartPassAndPlay,
}) => {
  const [activeTab, setActiveTab] = useState<'online' | 'pass_play'>('online');
  const [roomCodeInput, setRoomCodeInput] = useState('');
  const [activeRoom, setActiveRoom] = useState<MultiplayerRoom | null>(null);
  const [gameSelection, setGameSelection] = useState<'durak' | 'ochko'>('durak');
  const [loading, setLoading] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleCreateRoom = async () => {
    setLoading(true);
    setErrorMsg('');
    sounds.playChip();
    try {
      const room = await createRoom(currentUser, gameSelection);
      setActiveRoom(room);
    } catch {
      setErrorMsg("Xona yaratishda xatolik yuz berdi.");
    } finally {
      setLoading(false);
    }
  };

  const handleJoinRoom = async () => {
    if (!roomCodeInput.trim()) {
      setErrorMsg("Iltimos, 6 xonali xona kodini kiriting.");
      return;
    }
    setLoading(true);
    setErrorMsg('');
    sounds.playChip();
    try {
      const room = await joinRoomByCode(roomCodeInput.trim(), currentUser);
      if (room) {
        sounds.playWin();
        onStartRoomGame(room);
        onClose();
      } else {
        setErrorMsg("Bunday kodli xona topilmadi yoki u to'la.");
      }
    } catch {
      setErrorMsg("Xonaga ulanishda xatolik yuz berdi.");
    } finally {
      setLoading(false);
    }
  };

  const handleCopyCodeOrLink = () => {
    if (!activeRoom) return;
    const inviteLink = `${window.location.origin}${window.location.pathname}?room=${activeRoom.code}`;
    navigator.clipboard.writeText(inviteLink);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/70">
          <div className="flex items-center gap-2.5">
            <Users className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="text-base font-bold text-slate-100 font-serif">Do'stlar Bilan O'ynash</h2>
              <p className="text-xs text-slate-400">Onlayn xona yarating yoki bitta qurilmada bellashing</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg transition-colors hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex items-center gap-2 px-6 pt-3 border-b border-slate-800 bg-slate-950/40">
          <button
            onClick={() => setActiveTab('online')}
            className={`pb-3 px-3 text-xs sm:text-sm font-semibold transition-colors border-b-2 ${
              activeTab === 'online'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Onlayn Xona (Kod orqali)
          </button>
          <button
            onClick={() => setActiveTab('pass_play')}
            className={`pb-3 px-3 text-xs sm:text-sm font-semibold transition-colors border-b-2 ${
              activeTab === 'pass_play'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Bitta Qurilmada (2 O'yinchi)
          </button>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4 text-sm text-slate-300">
          {activeTab === 'online' ? (
            !activeRoom ? (
              <div className="space-y-4">
                {/* Create Room Box */}
                <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-3">
                  <div className="flex items-center gap-2 text-slate-100 font-bold text-sm">
                    <PlusCircle className="w-4 h-4 text-amber-400" />
                    Yangi Xona Yaratish
                  </div>
                  <p className="text-xs text-slate-400">
                    O'yinni tanlang va do'stingizga xona kodini yuboring.
                  </p>

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={() => setGameSelection('durak')}
                      className={`flex-1 py-2 rounded-lg text-xs font-semibold border transition-all ${
                        gameSelection === 'durak'
                          ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                          : 'bg-slate-900 border-slate-800 text-slate-400'
                      }`}
                    >
                      Durak (Podkidnoy)
                    </button>
                    <button
                      onClick={() => setGameSelection('ochko')}
                      className={`flex-1 py-2 rounded-lg text-xs font-semibold border transition-all ${
                        gameSelection === 'ochko'
                          ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                          : 'bg-slate-900 border-slate-800 text-slate-400'
                      }`}
                    >
                      21 Ochko (Blackjack)
                    </button>
                  </div>

                  <button
                    onClick={handleCreateRoom}
                    disabled={loading}
                    className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-colors shadow-md shadow-amber-500/20"
                  >
                    {loading ? 'Yaratilmoqda...' : 'Xona Yaratish va Kod Olish'}
                  </button>
                </div>

                {/* Join Room Box */}
                <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-3">
                  <div className="flex items-center gap-2 text-slate-100 font-bold text-sm">
                    <LogIn className="w-4 h-4 text-emerald-400" />
                    Mavjud Xonaga Kirish
                  </div>
                  <p className="text-xs text-slate-400">
                    Do'stingiz yuborgan 6 xonali xona kodini kiriting.
                  </p>

                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      maxLength={6}
                      value={roomCodeInput}
                      onChange={(e) => setRoomCodeInput(e.target.value.toUpperCase())}
                      placeholder="Masalan: AB12CD"
                      className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-slate-100 font-mono tracking-widest text-center uppercase focus:outline-none focus:border-emerald-400"
                    />
                    <button
                      onClick={handleJoinRoom}
                      disabled={loading || !roomCodeInput}
                      className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-colors shadow-md shadow-emerald-500/20"
                    >
                      Ulanish
                    </button>
                  </div>
                </div>

                {errorMsg && (
                  <p className="text-xs text-red-400 text-center font-medium">{errorMsg}</p>
                )}
              </div>
            ) : (
              /* Created room waiting screen */
              <div className="bg-slate-950/60 p-5 rounded-xl border border-amber-500/40 space-y-4 text-center">
                <div className="w-12 h-12 mx-auto rounded-full bg-amber-500/20 border border-amber-500 flex items-center justify-center text-xl">
                  {currentUser.avatar}
                </div>

                <div>
                  <h3 className="text-base font-bold text-slate-100">Xona Tayyor!</h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    O'yin: <strong className="text-amber-400 uppercase">{activeRoom.gameType}</strong>
                  </p>
                </div>

                {/* Big Code display */}
                <div className="bg-slate-900 border-2 border-dashed border-amber-400/60 p-4 rounded-xl">
                  <span className="text-xs text-slate-400 block mb-1">XONA KODI:</span>
                  <span className="text-3xl font-black font-mono tracking-widest text-amber-300">
                    {activeRoom.code}
                  </span>
                </div>

                {/* Copy button */}
                <button
                  onClick={handleCopyCodeOrLink}
                  className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all"
                >
                  {copiedCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  {copiedCode ? 'Havola Nusxalandi!' : "Do'stga Havolani Nusxalash"}
                </button>

                <p className="text-xs text-emerald-400 animate-pulse">
                  Do'stingiz ulanishi kutilmoqda...
                </p>

                <div className="pt-2">
                  <button
                    onClick={() => {
                      onStartRoomGame(activeRoom);
                      onClose();
                    }}
                    className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Play className="w-4 h-4" />
                    O'yinni Boshlash (Yoki Bot Qo'shish)
                  </button>
                </div>
              </div>
            )
          ) : (
            /* Pass and Play mode */
            <div className="space-y-4">
              <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center gap-2 text-slate-100 font-bold text-sm">
                  <Smartphone className="w-4 h-4 text-amber-400" />
                  Bitta Telefonda / Kompyuterda 2 Kishi O'ynash
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Internet kerak emas! Birgalikda o'tirib navbatma-navbat kartalarni yurasiz.
                  Navbat almashganda kartalar yopiladi, shunda raqib kartalarni ko'rmaydi.
                </p>

                <div className="grid grid-cols-2 gap-2 pt-2">
                  <button
                    onClick={() => {
                      onStartPassAndPlay('durak');
                      onClose();
                    }}
                    className="p-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex flex-col items-center justify-center gap-1 shadow-md transition-all"
                  >
                    <Swords className="w-5 h-5" />
                    <span>Durak (2 Kishi)</span>
                  </button>

                  <button
                    onClick={() => {
                      onStartPassAndPlay('ochko');
                      onClose();
                    }}
                    className="p-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex flex-col items-center justify-center gap-1 shadow-md transition-all"
                  >
                    <Users className="w-5 h-5" />
                    <span>21 Ochko (Duel)</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/70 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold rounded-xl bg-slate-800 text-slate-200 hover:bg-slate-700 transition-colors"
          >
            Yopish
          </button>
        </div>
      </div>
    </div>
  );
};
