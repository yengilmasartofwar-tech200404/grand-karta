import React, { useState } from 'react';
import { X, Sparkles, LogIn, Check } from 'lucide-react';
import { sounds } from '../utils/audio';

interface SaveProgressBannerProps {
  onOpenLoginOrProfile: () => void;
}

export const SaveProgressBanner: React.FC<SaveProgressBannerProps> = ({
  onOpenLoginOrProfile,
}) => {
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  return (
    <div className="w-full max-w-7xl mx-auto px-2 sm:px-4 mb-3">
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/70 to-slate-900 border border-indigo-500/30 shadow-2xl p-3 sm:p-4 flex items-center justify-between gap-4">
        {/* Glow backdrop */}
        <div className="absolute inset-0 bg-radial from-indigo-500/10 via-transparent to-transparent pointer-events-none" />

        {/* Left: Icon and message matching the screenshot */}
        <div className="relative z-10 flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-2xl shadow-lg shadow-indigo-500/30 shrink-0">
            🎁
          </div>

          <div>
            <h3 className="text-sm sm:text-base font-bold text-slate-100 flex items-center gap-1.5 font-serif">
              <span>O'yinlardagi jarayonni saqlash uchun kiring</span>
              <Sparkles className="w-4 h-4 text-amber-400" />
            </h3>
            <p className="text-xs text-slate-300">
              O'yinni o'sha joydan davom ettirish va tangalarni yo'qotmaslik uchun profildan foydalaning.
            </p>
          </div>
        </div>

        {/* Right: Kirish button and Close */}
        <div className="relative z-10 flex items-center gap-2 shrink-0">
          <button
            onClick={() => {
              sounds.playChip();
              onOpenLoginOrProfile();
            }}
            className="px-5 py-2 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-indigo-500/30 transition-all hover:scale-105 active:scale-95"
          >
            Kirish
          </button>

          <button
            onClick={() => setDismissed(true)}
            className="p-1.5 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-800 transition-colors"
            title="Yopish"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
