import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Card, DurakAttackPair, DurakRole, Suit } from '../../types/cards';
import { createDurakDeck, canBeat, getSuitInfo } from '../../utils/cardUtils';
import { PlayingCard } from '../PlayingCard';
import { sounds } from '../../utils/audio';
import confetti from 'canvas-confetti';
import { RotateCcw, Swords, Shield, Trophy, Sparkles, ArrowRightLeft, Layers } from 'lucide-react';
import { ThreeDCharacter, CharacterMood, CharacterCustomization } from '../ThreeDCharacter';
import { InGameSocialBar } from '../InGameSocialBar';
import { CHARACTER_ANIMATIONS } from '../ProfileModal';
import { isAnimationActive } from '../../utils/animationTrial';

interface DurakGameProps {
  onWin: (reward: number) => void;
  onLose: () => void;
  isPassAndPlay?: boolean;
  variant?: string; // 'podkidnoy' | 'perevodnoy' | 'devyatka'
  tableTheme?: string;
  cardBackTheme?: string;
  characterCustom?: CharacterCustomization;
  onExit?: () => void;
}

export const DurakGame: React.FC<DurakGameProps> = ({
  onWin,
  onLose,
  isPassAndPlay = false,
  variant = 'podkidnoy',
  tableTheme = 'green',
  cardBackTheme = 'royal_blue',
  characterCustom,
  onExit,
}) => {
  const isPerevodnoy = variant === 'perevodnoy';
  const isDevyatka = variant === 'devyatka';

  // Game states
  const [deck, setDeck] = useState<Card[]>([]);
  const [trumpCard, setTrumpCard] = useState<Card | null>(null);
  const [trumpSuit, setTrumpSuit] = useState<Suit>('hearts');
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [botHand, setBotHand] = useState<Card[]>([]);
  const [tablePairs, setTablePairs] = useState<DurakAttackPair[]>([]);
  const [discardPileCount, setDiscardPileCount] = useState<number>(0);
  
  // Devyatka table rows: 4 suits, storing played cards sorted
  const [devyatkaRows, setDevyatkaRows] = useState<{ [key in Suit]: Card[] }>({
    spades: [],
    hearts: [],
    diamonds: [],
    clubs: [],
  });

  const [attacker, setAttacker] = useState<DurakRole>('player');
  const [botIsTaking, setBotIsTaking] = useState<boolean>(false);
  const [botThinking, setBotThinking] = useState<boolean>(false);
  const [gameStatus, setGameStatus] = useState<'PLAYING' | 'PLAYER_WON' | 'BOT_WON' | 'DRAW'>('PLAYING');
  const [statusMessage, setStatusMessage] = useState<string>("O'yin boshlandi! Birinchi yurish sizda.");
  const [difficulty, setDifficulty] = useState<'easy' | 'normal' | 'hard'>('normal');

  // In-Game Social (Mic & 150 Emojis & Chat)
  const [activeEmoji, setActiveEmoji] = useState<string | null>(null);
  const [emojiTriggerKey, setEmojiTriggerKey] = useState<number>(0);
  const [isMicActive, setIsMicActive] = useState<boolean>(false);

  const handlePlayerSendEmoji = useCallback((emoji: string) => {
    const matchedAnim = CHARACTER_ANIMATIONS.find(a => a.emoji === emoji || a.actionKey === emoji);
    if (matchedAnim && !isAnimationActive(matchedAnim.id)) {
      sounds.playCardPlay();
      setStatusMessage(`🔒 "${matchedAnim.name}" animatsiyasi qulflangan! Profilingizdagi Omad G'ildiragida 7 kunga yutib oling.`);
      return;
    }

    setActiveEmoji(emoji);
    setEmojiTriggerKey((prev) => prev + 1);

    // Interactive opponent emoji reply
    if (!isPassAndPlay && Math.random() > 0.3) {
      setTimeout(() => {
        const botReplies: Record<string, string[]> = {
          '😂': ['🤣', '😆', '😜', '😎'],
          '👏': ['🤝', '🙌', '👍', '🙏'],
          '😎': ['🤠', '🔥', '👑', '😏'],
          '😡': ['😱', '🤫', '👀', '😅'],
          '🏆': ['🔥', '💪', '👑', '👏'],
          '❤️': ['🫶', '🌹', '🥰', '😊'],
        };
        const pool = botReplies[emoji] || ['😎', '👍', '🔥', '👀', '🃏', '👋', '☕'];
        const chosen = pool[Math.floor(Math.random() * pool.length)];
        setActiveEmoji(chosen);
        setEmojiTriggerKey((prev) => prev + 1);
      }, 1200);
    }
  }, [isPassAndPlay]);

  const botActionTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Clear pending timeouts on unmount
  useEffect(() => {
    return () => {
      if (botActionTimeoutRef.current) {
        clearTimeout(botActionTimeoutRef.current);
      }
    };
  }, []);

  // Sort hand: non-trumps first (by suit & value), trumps last
  const sortHand = (hand: Card[], trump: Suit): Card[] => {
    return [...hand].sort((a, b) => {
      const aTrump = a.suit === trump;
      const bTrump = b.suit === trump;
      if (aTrump && !bTrump) return 1;
      if (!aTrump && bTrump) return -1;
      if (a.suit !== b.suit) return a.suit.localeCompare(b.suit);
      return a.value - b.value;
    });
  };

  // Initialize a new match
  const startNewGame = useCallback(() => {
    if (botActionTimeoutRef.current) clearTimeout(botActionTimeoutRef.current);
    const fullDeck = createDurakDeck();

    if (isDevyatka) {
      // Devyatka rules: 18 cards each, no trump
      const pHand = [...fullDeck.slice(0, 18)].sort((a, b) => a.value - b.value);
      const bHand = [...fullDeck.slice(18, 36)].sort((a, b) => a.value - b.value);
      setPlayerHand(pHand);
      setBotHand(bHand);
      setDeck([]);
      setTrumpCard(null);
      setDevyatkaRows({ spades: [], hearts: [], diamonds: [], clubs: [] });
      setTablePairs([]);
      setDiscardPileCount(0);
      setBotIsTaking(false);
      setBotThinking(false);
      setGameStatus('PLAYING');

      // First move to whoever has 9 of diamonds, or 9 of hearts, etc.
      const playerHas9Diamonds = pHand.some(c => c.rank === '9' && c.suit === 'diamonds');
      const first: DurakRole = playerHas9Diamonds ? 'player' : 'bot';
      setAttacker(first);
      sounds.playCardDeal();
      setStatusMessage(
        playerHas9Diamonds
          ? "Sizda 9 G'isht bor! Birinchi siz yurasiz."
          : "Bot Alisher birinchi 9 lik bilan boshlaydi."
      );
      if (first === 'bot') setBotThinking(true);
      return;
    }

    const trump = fullDeck[fullDeck.length - 1];
    setTrumpCard(trump);
    setTrumpSuit(trump.suit);

    const pHand = fullDeck.slice(0, 6);
    const bHand = fullDeck.slice(6, 12);
    const remainingDeck = fullDeck.slice(12);

    // Determine who has the lowest trump card
    const playerTrumps = pHand.filter((c) => c.suit === trump.suit).map((c) => c.value);
    const botTrumps = bHand.filter((c) => c.suit === trump.suit).map((c) => c.value);

    let firstAttacker: DurakRole = 'player';
    if (playerTrumps.length > 0 && botTrumps.length > 0) {
      firstAttacker = Math.min(...playerTrumps) <= Math.min(...botTrumps) ? 'player' : 'bot';
    } else if (botTrumps.length > 0 && playerTrumps.length === 0) {
      firstAttacker = 'bot';
    } else {
      firstAttacker = 'player';
    }

    setPlayerHand(sortHand(pHand, trump.suit));
    setBotHand(sortHand(bHand, trump.suit));
    setDeck(remainingDeck);
    setTablePairs([]);
    setDiscardPileCount(0);
    setAttacker(firstAttacker);
    setBotIsTaking(false);
    setBotThinking(false);
    setGameStatus('PLAYING');
    sounds.playCardDeal();

    if (firstAttacker === 'player') {
      setStatusMessage(
        isPerevodnoy
          ? "O'tkazma (Perevodnoy) Durak boshlandi! Siz yurasiz."
          : "Sizda eng kichik kozir! Birinchi siz yurasiz."
      );
    } else {
      setStatusMessage("Bot Alisherda eng kichik kozir! U hujum qiladi.");
      setBotThinking(true);
    }
  }, [isDevyatka, isPerevodnoy]);

  useEffect(() => {
    startNewGame();
  }, [startNewGame]);

  // Refill hands from deck up to 6 cards
  const refillHands = useCallback(
    (currentDeck: Card[], pHand: Card[], bHand: Card[], currentAttacker: DurakRole) => {
      let d = [...currentDeck];
      let p = [...pHand];
      let b = [...bHand];

      const needP = Math.max(0, 6 - p.length);
      const needB = Math.max(0, 6 - b.length);

      if (currentAttacker === 'player') {
        const takeP = d.splice(0, needP);
        p = [...p, ...takeP];
        const takeB = d.splice(0, needB);
        b = [...b, ...takeB];
      } else {
        const takeB = d.splice(0, needB);
        b = [...b, ...takeB];
        const takeP = d.splice(0, needP);
        p = [...p, ...takeP];
      }

      setDeck(d);
      setPlayerHand(sortHand(p, trumpSuit));
      setBotHand(sortHand(b, trumpSuit));
      sounds.playCardDeal();

      // Check victory
      if (d.length === 0) {
        if (p.length === 0 && b.length === 0) {
          setGameStatus('DRAW');
          setStatusMessage("Ajoyib o'yin! Durang natija.");
          return;
        }
        if (p.length === 0) {
          setGameStatus('PLAYER_WON');
          setStatusMessage("Tabriklaymiz! Siz g'alaba qozondingiz!");
          sounds.playWin();
          confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
          onWin(200);
          return;
        }
        if (b.length === 0) {
          setGameStatus('BOT_WON');
          setStatusMessage("Bot Alisher g'olib bo'ldi. Siz Ahmoq (Durak) bo'ldingiz.");
          sounds.playLose();
          onLose();
          return;
        }
      }
    },
    [trumpSuit, onWin, onLose]
  );

  // Check valid ranks on table for podkidnoy
  const getTableRanks = useCallback((): string[] => {
    const ranks = new Set<string>();
    for (const pair of tablePairs) {
      ranks.add(pair.attack.rank);
      if (pair.defense) {
        ranks.add(pair.defense.rank);
      }
    }
    return Array.from(ranks);
  }, [tablePairs]);

  // Devyatka check valid playable card
  const isCardPlayableInDevyatka = (card: Card): boolean => {
    if (card.rank === '9') return true; // Any 9 can be played to open a suit
    const suitCards = devyatkaRows[card.suit];
    if (suitCards.length === 0) return false;
    const values = suitCards.map(c => c.value);
    const minVal = Math.min(...values);
    const maxVal = Math.max(...values);
    return card.value === minVal - 1 || card.value === maxVal + 1;
  };

  // Check if player can transfer in Perevodnoy
  const canPlayerTransfer = (): boolean => {
    if (!isPerevodnoy || attacker !== 'bot' || tablePairs.length === 0) return false;
    // Cannot transfer if any card has already been defended
    if (tablePairs.some(p => p.defense)) return false;
    // Cannot transfer if table cards + 1 > bot hand
    if (tablePairs.length + 1 > botHand.length) return false;
    const targetRank = tablePairs[0].attack.rank;
    return playerHand.some(c => c.rank === targetRank);
  };

  // Check if player can play a specific card
  const isCardPlayableForPlayer = (card: Card): boolean => {
    if (gameStatus !== 'PLAYING') return false;

    if (isDevyatka) {
      return attacker === 'player' && isCardPlayableInDevyatka(card);
    }

    if (attacker === 'player') {
      if (tablePairs.length === 0) return true;
      if (tablePairs.length >= 6 || tablePairs.length >= botHand.length) return false;
      const validRanks = getTableRanks();
      return validRanks.includes(card.rank);
    } else {
      // Player is defending:
      // In Perevodnoy, player can ALSO play a matching rank card to transfer!
      if (isPerevodnoy && canPlayerTransfer() && card.rank === tablePairs[0].attack.rank) {
        return true;
      }
      const unbeatenIndex = tablePairs.findIndex((p) => !p.defense);
      if (unbeatenIndex === -1) return false;
      return canBeat(card, tablePairs[unbeatenIndex].attack, trumpSuit);
    }
  };

  // Player transfers in Perevodnoy
  const handlePlayerTransfer = (transferCard?: Card) => {
    if (!isPerevodnoy || !canPlayerTransfer()) return;
    const targetRank = tablePairs[0].attack.rank;
    const card = transferCard || playerHand.find(c => c.rank === targetRank);
    if (!card) return;

    sounds.playCardPlay();
    setPlayerHand(prev => prev.filter(c => c.id !== card.id));
    setTablePairs(prev => [...prev, { attack: card }]);
    setStatusMessage(`Siz ${card.rank} ${getSuitInfo(card.suit).symbol} bilan kartalarni o'tkazdingiz (Perevod)! Endi Bot himoyalanadi.`);
    // Player transfers: player becomes attacker, bot becomes defender
    setAttacker('player');
    setBotThinking(true);
  };

  // Player plays a card
  const handlePlayerCardClick = (card: Card) => {
    if (!isCardPlayableForPlayer(card)) return;

    sounds.playCardPlay();

    if (isDevyatka) {
      setPlayerHand(prev => prev.filter(c => c.id !== card.id));
      setDevyatkaRows(prev => {
        const updated = [...prev[card.suit], card].sort((a, b) => a.value - b.value);
        return { ...prev, [card.suit]: updated };
      });
      setStatusMessage(`Siz ${card.rank} ${getSuitInfo(card.suit).symbol} qo'ydingiz.`);

      if (playerHand.length === 1) {
        setGameStatus('PLAYER_WON');
        setStatusMessage("Tabriklaymiz! Siz birinchi bo'lib barcha kartalaringizni tugatdingiz!");
        sounds.playWin();
        confetti({ particleCount: 120, spread: 80 });
        onWin(250);
        return;
      }

      setAttacker('bot');
      setBotThinking(true);
      return;
    }

    if (attacker === 'player') {
      // Add attack
      setPlayerHand((prev) => prev.filter((c) => c.id !== card.id));
      setTablePairs((prev) => [...prev, { attack: card }]);
      setStatusMessage(`Siz ${card.rank} ${getSuitInfo(card.suit).symbol} bilan yurdingiz.`);
      setBotThinking(true);
    } else {
      // In Perevodnoy: check if this is a transfer move
      if (isPerevodnoy && canPlayerTransfer() && card.rank === tablePairs[0].attack.rank) {
        handlePlayerTransfer(card);
        return;
      }

      // Player defends against the first unbeaten card
      const unbeatenIndex = tablePairs.findIndex((p) => !p.defense);
      if (unbeatenIndex !== -1) {
        setPlayerHand((prev) => prev.filter((c) => c.id !== card.id));
        setTablePairs((prev) => {
          const updated = [...prev];
          updated[unbeatenIndex] = {
            ...updated[unbeatenIndex],
            defense: card,
          };
          return updated;
        });
        setStatusMessage(`Siz ${card.rank} ${getSuitInfo(card.suit).symbol} bilan qaytardingiz.`);
        setBotThinking(true);
      }
    }
  };

  // Player action: "Bita" (Finish attack turn)
  const handlePlayerPass = () => {
    if (attacker !== 'player' || tablePairs.length === 0) return;

    const allDefended = tablePairs.every((p) => p.defense);

    if (botIsTaking) {
      // Bot takes all cards
      sounds.playCardCollect();
      const allCardsOnTable: Card[] = [];
      tablePairs.forEach((p) => {
        allCardsOnTable.push(p.attack);
        if (p.defense) allCardsOnTable.push(p.defense);
      });

      setBotHand((prev) => sortHand([...prev, ...allCardsOnTable], trumpSuit));
      setTablePairs([]);
      setBotIsTaking(false);
      setStatusMessage("Bot Alisher kartalarni oldi. Yana sizning navbatingiz!");

      refillHands(deck, playerHand, [...botHand, ...allCardsOnTable], 'player');
    } else if (allDefended) {
      // Bita: cards discarded, attacker becomes bot
      sounds.playBitaSwoosh();
      const count = tablePairs.reduce((acc, p) => acc + (p.defense ? 2 : 1), 0);
      setDiscardPileCount((prev) => prev + count);
      setTablePairs([]);
      setStatusMessage("Bita! Barcha kartalar urildi. Endi Bot Alisher yuradi.");

      refillHands(deck, playerHand, botHand, 'player');
      setAttacker('bot');
      setBotThinking(true);
    }
  };

  // Player action: "Olish" (Take cards when defending)
  const handlePlayerTake = () => {
    if (attacker !== 'bot' || tablePairs.length === 0) return;
    sounds.playCardCollect();
    const allCardsOnTable: Card[] = [];
    tablePairs.forEach((p) => {
      allCardsOnTable.push(p.attack);
      if (p.defense) allCardsOnTable.push(p.defense);
    });

    const newPlayerHand = sortHand([...playerHand, ...allCardsOnTable], trumpSuit);
    setPlayerHand(newPlayerHand);
    setTablePairs([]);
    setStatusMessage("Siz kartalarni oldingiz. Bot yana yuradi.");
    refillHands(deck, newPlayerHand, botHand, 'bot');
    setAttacker('bot');
    setBotThinking(true);
  };

  // Player pass in Devyatka
  const handleDevyatkaPass = () => {
    if (!isDevyatka || attacker !== 'player') return;
    sounds.playChip();
    setStatusMessage("Siz yurishni o'tkazib yubordingiz (Pas).");
    setAttacker('bot');
    setBotThinking(true);
  };

  // Bot logic engine
  useEffect(() => {
    if (gameStatus !== 'PLAYING' || !botThinking) return;

    botActionTimeoutRef.current = setTimeout(() => {
      setBotThinking(false);

      if (isDevyatka) {
        // Devyatka bot logic: find any valid card to place
        const validCards = botHand.filter(c => isCardPlayableInDevyatka(c));
        if (validCards.length > 0) {
          // Prefer 9s first, or non-extremes
          const chosen = validCards[0];
          sounds.playCardPlay();
          setBotHand(prev => prev.filter(c => c.id !== chosen.id));
          setDevyatkaRows(prev => {
            const updated = [...prev[chosen.suit], chosen].sort((a, b) => a.value - b.value);
            return { ...prev, [chosen.suit]: updated };
          });
          setStatusMessage(`Bot Alisher ${chosen.rank} ${getSuitInfo(chosen.suit).symbol} qo'ydi.`);

          if (botHand.length === 1) {
            setGameStatus('BOT_WON');
            setStatusMessage("Bot Alisher birinchi bo'lib barcha kartalarini tugatdi!");
            sounds.playLose();
            onLose();
            return;
          }
        } else {
          setStatusMessage("Bot Alisherda yurish yo'q, u o'tkazdi (Pas). Sizning navbatingiz!");
        }
        setAttacker('player');
        return;
      }

      if (attacker === 'player') {
        // Player is attacking, Bot is defending, taking or transferring
        if (botIsTaking) return;

        // Perevodnoy bot check: can bot transfer the attack back to player?
        if (
          isPerevodnoy &&
          tablePairs.length > 0 &&
          tablePairs.every(p => !p.defense) &&
          tablePairs.length + 1 <= playerHand.length
        ) {
          const attackRank = tablePairs[0].attack.rank;
          const transferCandidates = botHand.filter(c => c.rank === attackRank);
          if (transferCandidates.length > 0) {
            const transferCard = transferCandidates[0];
            sounds.playCardPlay();
            setBotHand(prev => prev.filter(c => c.id !== transferCard.id));
            setTablePairs(prev => [...prev, { attack: transferCard }]);
            setStatusMessage(`Bot Alisher ${transferCard.rank} ${getSuitInfo(transferCard.suit).symbol} bilan kartalarni o'tkazdi (Perevod)! Endi siz himoyalanasiz.`);
            setAttacker('bot');
            return;
          }
        }

        const unbeatenIndex = tablePairs.findIndex((p) => !p.defense);
        if (unbeatenIndex === -1) return;

        const targetCard = tablePairs[unbeatenIndex].attack;
        const validDefenses = botHand.filter((c) => canBeat(c, targetCard, trumpSuit));

        if (validDefenses.length > 0) {
          // Bot beats the card: prefer lowest non-trump first
          const nonTrumps = validDefenses.filter((c) => c.suit !== trumpSuit).sort((a, b) => a.value - b.value);
          const trumps = validDefenses.filter((c) => c.suit === trumpSuit).sort((a, b) => a.value - b.value);

          let chosenCard: Card;
          if (nonTrumps.length > 0) {
            chosenCard = nonTrumps[0];
          } else if (difficulty === 'easy' && Math.random() > 0.6) {
            setBotIsTaking(true);
            setStatusMessage("Bot Alisher qaytara olmadi va kartalarni olmoqchi.");
            return;
          } else {
            if (targetCard.value >= 10 || deck.length <= 6 || trumps[0].value <= 10) {
              chosenCard = trumps[0];
            } else {
              setBotIsTaking(true);
              setStatusMessage("Bot Alisher kartalarni olmoqchi. Qo'shimcha tashlaysizmi?");
              return;
            }
          }

          sounds.playCardPlay();
          setBotHand((prev) => prev.filter((c) => c.id !== chosenCard.id));
          setTablePairs((prev) => {
            const next = [...prev];
            next[unbeatenIndex] = { ...next[unbeatenIndex], defense: chosenCard };
            return next;
          });
          setStatusMessage(`Bot Alisher ${chosenCard.rank} ${getSuitInfo(chosenCard.suit).symbol} bilan urdi.`);
        } else {
          setBotIsTaking(true);
          setStatusMessage("Bot Alisher kartalarni olmoqchi. Qo'shimcha tashlaysizmi?");
        }
      } else {
        // Bot is attacking
        if (tablePairs.length === 0) {
          const nonTrumps = botHand.filter((c) => c.suit !== trumpSuit).sort((a, b) => a.value - b.value);
          const chosen = nonTrumps.length > 0 ? nonTrumps[0] : [...botHand].sort((a, b) => a.value - b.value)[0];

          sounds.playCardPlay();
          setBotHand((prev) => prev.filter((c) => c.id !== chosen.id));
          setTablePairs([{ attack: chosen }]);
          setStatusMessage(`Bot Alisher ${chosen.rank} ${getSuitInfo(chosen.suit).symbol} bilan hujum qildi.`);
        } else {
          const allDefended = tablePairs.every((p) => p.defense);

          if (allDefended) {
            const tableRanks = getTableRanks();
            const candidates = botHand
              .filter((c) => tableRanks.includes(c.rank) && c.suit !== trumpSuit)
              .sort((a, b) => a.value - b.value);

            if (candidates.length > 0 && tablePairs.length < 6 && tablePairs.length < playerHand.length) {
              const tossCard = candidates[0];
              sounds.playCardPlay();
              setBotHand((prev) => prev.filter((c) => c.id !== tossCard.id));
              setTablePairs((prev) => [...prev, { attack: tossCard }]);
              setStatusMessage(`Bot Alisher yana ${tossCard.rank} ${getSuitInfo(tossCard.suit).symbol} tashladi!`);
            } else {
              sounds.playBitaSwoosh();
              const count = tablePairs.reduce((acc, p) => acc + (p.defense ? 2 : 1), 0);
              setDiscardPileCount((prev) => prev + count);
              setTablePairs([]);
              setStatusMessage("Bita! Siz barcha kartalarni qaytardingiz. Endi siz hujum qilasiz!");

              refillHands(deck, playerHand, botHand, 'bot');
              setAttacker('player');
            }
          }
        }
      }
    }, 700);

    return () => {
      if (botActionTimeoutRef.current) clearTimeout(botActionTimeoutRef.current);
    };
  }, [
    botThinking,
    gameStatus,
    attacker,
    botIsTaking,
    tablePairs,
    botHand,
    trumpSuit,
    difficulty,
    deck,
    playerHand,
    isDevyatka,
    isPerevodnoy,
    devyatkaRows,
    getTableRanks,
    refillHands,
    onLose,
  ]);

  const trumpInfo = getSuitInfo(trumpSuit);

  // Dynamic table felt gradient
  const tableFeltClass =
    tableTheme === 'navy'
      ? 'from-blue-950 via-indigo-950 to-slate-950 border-indigo-900/40'
      : tableTheme === 'ruby'
      ? 'from-red-950 via-rose-950 to-slate-950 border-rose-900/40'
      : tableTheme === 'black'
      ? 'from-slate-950 via-zinc-900 to-black border-zinc-800'
      : 'from-emerald-950 via-emerald-900 to-slate-950 border-amber-900/40';

  return (
    <div className="w-full flex flex-col items-center select-none py-2 px-2 sm:px-6 max-w-6xl mx-auto animate-fade-in">
      {/* Game arena felt container */}
      <div className={`w-full rounded-2xl bg-gradient-to-b ${tableFeltClass} border-4 shadow-2xl p-3 sm:p-6 relative flex flex-col min-h-[640px] justify-between overflow-hidden`}>
        {/* Subtle felt texture overlay */}
        <div className="absolute inset-0 bg-[radial-gradient(#ffffff0a_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />

        {/* Top Arena: Status Row & Centered 3D Opponent Holding Cards */}
        <div className="relative z-10 flex flex-col items-center border-b border-white/10 pb-2">
          {/* Top Info & Controls Bar */}
          <div className="w-full flex items-center justify-between px-1 sm:px-3 mb-1">
            {/* Left: Game Mode & Role indicator */}
            <div className="flex items-center gap-2">
              <span className="text-xs font-black font-serif px-2.5 py-0.5 rounded-full bg-slate-900/90 text-amber-300 border border-slate-700 shadow">
                {isPerevodnoy ? "O'tkazma Durak" : isDevyatka ? "To'qqizlik (9)" : "Podkidnoy Durak"}
              </span>
              {attacker === 'bot' ? (
                <span className="flex items-center gap-1.5 text-xs font-semibold text-amber-300 bg-amber-950/80 px-3 py-1 rounded-full border border-amber-700/60 shadow">
                  <Swords className="w-3.5 h-3.5 text-amber-400" /> Raqib navbati
                </span>
              ) : (
                <span className="flex items-center gap-1.5 text-xs font-semibold text-emerald-300 bg-emerald-950/80 px-3 py-1 rounded-full border border-emerald-700/60 shadow">
                  <Shield className="w-3.5 h-3.5 text-emerald-400" /> Sizning navbatingiz
                </span>
              )}
            </div>

            {/* Right: Controls (Difficulty, Restart, Exit) */}
            <div className="flex items-center gap-2">
              {!isPassAndPlay && !isDevyatka && (
                <select
                  value={difficulty}
                  onChange={(e) => setDifficulty(e.target.value as 'easy' | 'normal' | 'hard')}
                  className="bg-slate-900/90 border border-slate-700 rounded-xl px-2.5 py-1 text-xs text-slate-200 shadow focus:outline-none focus:border-amber-400"
                >
                  <option value="easy">Oson</option>
                  <option value="normal">O'rtacha</option>
                  <option value="hard">Qiyin</option>
                </select>
              )}
              <button
                onClick={startNewGame}
                className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 transition-colors border border-slate-700 shadow"
                title="Qaytadan boshlash"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              {onExit && (
                <button
                  onClick={onExit}
                  className="px-3 py-1 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-xs font-semibold text-slate-200 border border-slate-700 transition-colors shadow"
                >
                  Chiqish
                </button>
              )}
            </div>
          </div>

          {/* Centered 3D Opponent Station */}
          <div className="flex flex-col items-center relative my-0.5">
            <ThreeDCharacter
              name={isPassAndPlay ? "2-O'yinchi" : "Alisher (3D Bot)"}
              variant={difficulty === 'hard' ? 'sherzod' : difficulty === 'easy' ? 'jasur' : 'alisher'}
              customization={isPassAndPlay ? characterCustom : undefined}
              isThinking={botThinking}
              isSpeaking={isMicActive}
              activeEmoji={activeEmoji}
              triggerKey={emojiTriggerKey}
              nameplatePosition="top"
              mood={
                gameStatus === 'BOT_WON'
                  ? 'win'
                  : gameStatus === 'PLAYER_WON'
                  ? 'lose'
                  : botThinking
                  ? 'thinking'
                  : 'idle'
              }
              cardsCount={botHand.length}
            />

            {/* Opponent's Cards Held in Hands */}
            <div className="flex items-center justify-center -space-x-3 sm:-space-x-5 -mt-8 sm:-mt-10 relative z-20 hover:scale-105 transition-transform duration-200">
              {botHand.map((card, idx) => {
                const mid = (botHand.length - 1) / 2;
                const offset = idx - mid;
                const rotation = offset * 3.5;
                const yOffset = Math.abs(offset) * 2;

                return (
                  <div
                    key={card.id || idx}
                    style={{
                      transform: `rotate(${rotation}deg) translateY(${yOffset}px)`,
                    }}
                    className="transition-transform duration-200 shadow-xl"
                  >
                    <PlayingCard
                      card={card}
                      faceUp={false}
                      size="sm"
                      cardBackTheme={cardBackTheme}
                    />
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Center Table Battle Area */}
        <div className="relative z-10 flex-1 my-4 flex items-center justify-center">
          {isDevyatka ? (
            /* Devyatka (To'qqizlik) 4 Suit Rows Layout */
            <div className="w-full bg-slate-950/60 p-3 sm:p-5 rounded-2xl border border-white/10 flex flex-col gap-2.5">
              <div className="flex items-center justify-between text-xs text-amber-300 font-bold border-b border-slate-800 pb-1">
                <span>To'qqizlik Stoli (9 lar markazda):</span>
                <span className="font-mono text-slate-400">Navbat: {attacker === 'player' ? 'Siz' : 'Bot Alisher'}</span>
              </div>
              {(['spades', 'hearts', 'diamonds', 'clubs'] as Suit[]).map((suit) => {
                const row = devyatkaRows[suit];
                const sInfo = getSuitInfo(suit);
                return (
                  <div key={suit} className="flex items-center gap-1.5 min-h-[56px] bg-slate-900/40 p-1.5 rounded-xl border border-slate-800/80 overflow-x-auto">
                    <span className={`w-7 text-center font-bold text-base shrink-0 ${sInfo.isRed ? 'text-red-500' : 'text-slate-200'}`}>
                      {sInfo.symbol}
                    </span>
                    {row.length === 0 ? (
                      <span className="text-xs text-slate-500 italic">9 ochilmagan</span>
                    ) : (
                      row.map((c) => (
                        <PlayingCard
                          key={c.id}
                          card={c}
                          faceUp={true}
                          size="sm"
                          className="shrink-0 scale-90"
                        />
                      ))
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            /* Durak / Perevodnoy Classic Battle Layout */
            <div className="w-full flex flex-col md:flex-row items-center justify-between gap-4">
              {/* Left: Deck & Trump Pile */}
              <div className="flex items-center gap-3">
                <div className="relative w-20 h-28 sm:w-24 sm:h-32 flex items-center justify-center">
                  {deck.length > 0 ? (
                    <>
                      {trumpCard && (
                        <div className="absolute top-1/2 left-0 -translate-y-1/2 rotate-90 shadow-lg">
                          <PlayingCard card={trumpCard} faceUp={true} size="sm" isTrump={true} cardBackTheme={cardBackTheme} />
                        </div>
                      )}
                      {deck.length > 1 && (
                        <div className="absolute top-0 left-3 shadow-2xl">
                          <PlayingCard card={deck[0]} faceUp={false} size="sm" cardBackTheme={cardBackTheme} />
                        </div>
                      )}
                      <div className="absolute bottom-1 right-1 bg-slate-950/80 text-amber-300 border border-slate-700 text-[11px] font-mono px-1.5 py-0.5 rounded shadow">
                        {deck.length}
                      </div>
                    </>
                  ) : (
                    <div className="w-16 h-24 rounded-lg border-2 border-dashed border-white/20 flex flex-col items-center justify-center text-xs text-emerald-400/80 text-center p-1">
                      <span>Koloda</span>
                      <span>tugadi</span>
                      <span className="text-amber-400 text-sm font-bold mt-1">{trumpInfo.symbol}</span>
                    </div>
                  )}
                </div>

                {/* Trump Info Banner */}
                <div className="bg-slate-950/70 p-2.5 sm:p-3 rounded-xl border border-white/10 text-xs">
                  <div className="text-slate-400 font-semibold mb-0.5">Kozir (Trump):</div>
                  <div className="flex items-center gap-1.5 text-sm font-bold">
                    <span className={trumpInfo.isRed ? 'text-red-500' : 'text-slate-200'}>
                      {trumpInfo.symbol} {trumpInfo.nameUz}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1">
                    Chiqindi (Bita): <span className="font-mono text-slate-200">{discardPileCount}</span>
                  </div>
                </div>
              </div>

              {/* Center: Active Battle Table Pairs */}
              <div className="flex-1 min-h-[140px] sm:min-h-[170px] bg-black/25 rounded-2xl border border-white/10 p-3 sm:p-4 flex items-center justify-center flex-wrap gap-3 sm:gap-6 shadow-inner">
                {tablePairs.length === 0 ? (
                  <div className="text-center text-emerald-300/60 text-sm italic font-serif">
                    {attacker === 'player'
                      ? "Hujum qilish uchun qo'lingizdagi kartani bosing"
                      : "Bot Alisher yurishini kuting..."}
                  </div>
                ) : (
                  tablePairs.map((pair, idx) => (
                    <div key={idx} className="relative w-16 h-24 sm:w-20 sm:h-28 flex items-center justify-center">
                      <div className="absolute top-0 left-0 transition-transform">
                        <PlayingCard card={pair.attack} faceUp={true} size="md" trumpSuit={trumpSuit} />
                      </div>
                      {pair.defense ? (
                        <div className="absolute top-3 left-3 sm:top-5 sm:left-5 z-10 transition-transform">
                          <PlayingCard card={pair.defense} faceUp={true} size="md" trumpSuit={trumpSuit} />
                        </div>
                      ) : (
                        attacker === 'bot' && (
                          <div className="absolute top-3 left-3 sm:top-5 sm:left-5 z-10 w-16 h-24 sm:w-20 sm:h-28 rounded-lg border-2 border-dashed border-amber-400/70 bg-amber-500/10 flex items-center justify-center text-[11px] font-semibold text-amber-300 animate-pulse text-center p-1">
                            Qaytaring
                          </div>
                        )
                      )}
                    </div>
                  ))
                )}
              </div>

              {/* Right: Round Status */}
              <div className="bg-slate-950/70 p-3 sm:p-4 rounded-xl border border-white/10 max-w-[240px] text-xs">
                <div className="text-amber-400 font-bold flex items-center gap-1.5 mb-1 text-sm">
                  <Sparkles className="w-4 h-4" />
                  <span>Holat</span>
                </div>
                <p className="text-slate-200 leading-snug">{statusMessage}</p>
                {botThinking && (
                  <div className="mt-2 text-emerald-400 text-[11px] flex items-center gap-1">
                    <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    Alisher qaror qabul qilmoqda...
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Bottom Bar: Action buttons and Player Hand */}
        <div className="relative z-10 flex flex-col items-center gap-2.5 pt-2 border-t border-white/10">
          {/* Social Bar */}
          <InGameSocialBar
            playerName="Siz"
            opponentName={isPassAndPlay ? "2-O'yinchi" : "Alisher"}
            onSendEmoji={handlePlayerSendEmoji}
            onMicToggle={(active) => setIsMicActive(active)}
            isMicActive={isMicActive}
          />

          {/* Player controls */}
          <div className="flex items-center gap-2.5 flex-wrap justify-center">
            {isDevyatka ? (
              <button
                onClick={handleDevyatkaPass}
                disabled={attacker !== 'player'}
                className={`px-5 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all shadow-lg ${
                  attacker === 'player'
                    ? 'bg-amber-500 text-slate-950 hover:bg-amber-400 shadow-amber-500/30'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                O'tkazib yuborish (Pas)
              </button>
            ) : attacker === 'player' ? (
              <button
                onClick={handlePlayerPass}
                disabled={tablePairs.length === 0}
                className={`px-5 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all shadow-lg flex items-center gap-2 ${
                  tablePairs.length > 0
                    ? 'bg-amber-500 text-slate-950 hover:bg-amber-400 shadow-amber-500/30'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                {botIsTaking ? "Kartalarni berish (Bo'ldi)" : "Bita (Tugatish)"}
              </button>
            ) : (
              <div className="flex items-center gap-2">
                {/* Perevodnoy Transfer Button */}
                {isPerevodnoy && canPlayerTransfer() && (
                  <button
                    onClick={() => handlePlayerTransfer()}
                    className="px-5 py-2 text-xs sm:text-sm font-bold rounded-xl bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-600/30 transition-all flex items-center gap-1.5 animate-bounce"
                  >
                    <ArrowRightLeft className="w-4 h-4" />
                    <span>O'tkazish (Perevod)</span>
                  </button>
                )}
                <button
                  onClick={handlePlayerTake}
                  disabled={tablePairs.length === 0}
                  className={`px-5 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all shadow-lg flex items-center gap-2 ${
                    tablePairs.length > 0
                      ? 'bg-red-600 text-white hover:bg-red-500 shadow-red-600/30'
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  Kartalarni olish
                </button>
              </div>
            )}
          </div>

          {/* Player Hand Banner */}
          <div className="w-full flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-slate-100">Sizning kartalaringiz:</span>
              <span className="text-xs font-mono text-emerald-300">({playerHand.length} ta)</span>
            </div>
            {isPerevodnoy && canPlayerTransfer() && (
              <span className="text-xs font-bold text-blue-300 animate-pulse flex items-center gap-1">
                <ArrowRightLeft className="w-3.5 h-3.5" /> O'tkazish mumkin! Bir xil raqamli kartani bosing
              </span>
            )}
          </div>

          {/* Cards Fan */}
          <div className="w-full overflow-x-auto pb-2 flex items-center justify-center -space-x-3 sm:-space-x-6 min-h-[110px] sm:min-h-[130px]">
            {playerHand.map((card) => {
              const playable = isCardPlayableForPlayer(card);
              return (
                <PlayingCard
                  key={card.id}
                  card={card}
                  faceUp={true}
                  isPlayable={playable}
                  trumpSuit={isDevyatka ? undefined : trumpSuit}
                  onClick={() => handlePlayerCardClick(card)}
                  size="md"
                  cardBackTheme={cardBackTheme}
                />
              );
            })}
          </div>
        </div>

        {/* Victory / Defeat Modal */}
        {gameStatus !== 'PLAYING' && (
          <div className="absolute inset-0 z-40 bg-slate-950/85 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-slate-900 border-2 border-amber-500/60 rounded-2xl p-6 sm:p-8 max-w-md w-full text-center shadow-2xl space-y-4">
              <div className="w-16 h-16 mx-auto rounded-full bg-amber-500/20 border border-amber-500 flex items-center justify-center text-3xl">
                {gameStatus === 'PLAYER_WON' ? '🏆' : gameStatus === 'BOT_WON' ? '🃏' : '🤝'}
              </div>

              <h2 className="text-2xl font-bold font-serif text-slate-100">
                {gameStatus === 'PLAYER_WON'
                  ? "G'alaba! Tabriklaymiz!"
                  : gameStatus === 'BOT_WON'
                  ? "Siz Durak (Ahmoq) bo'ldingiz!"
                  : "Durang natija!"}
              </h2>

              <p className="text-sm text-slate-300">
                {gameStatus === 'PLAYER_WON'
                  ? "Siz qo'lingizdagi barcha kartalardan qutulib, birinchi bo'lib o'yinni tugatdingiz! +200 tanga mukofot."
                  : gameStatus === 'BOT_WON'
                  ? "Bot Alisher barcha kartalarini tugatdi. Keyingi o'yinda omad kulib boqadi!"
                  : "Ikkala o'yinchi ham bir vaqtda kartalarini tugatdi."}
              </p>

              <button
                onClick={startNewGame}
                className="w-full py-3 rounded-xl bg-amber-500 text-slate-950 font-bold hover:bg-amber-400 transition-colors shadow-lg shadow-amber-500/30 flex items-center justify-center gap-2"
              >
                <Trophy className="w-4 h-4" />
                Yana o'ynash
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
