import React, { useState, useEffect, useCallback } from 'react';
import { Card, Suit } from '../../types/cards';
import { createDurakDeck, createStandardDeck, calculateOchkoScore, getSuitInfo } from '../../utils/cardUtils';
import { PlayingCard } from '../PlayingCard';
import { sounds } from '../../utils/audio';
import confetti from 'canvas-confetti';
import { Coins, RotateCcw, Flame, Trophy, Eye, Check, Swords, Shield, Sparkles } from 'lucide-react';
import { ThreeDCharacter, CharacterCustomization } from '../ThreeDCharacter';
import { InGameSocialBar } from '../InGameSocialBar';
import { CHARACTER_ANIMATIONS } from '../ProfileModal';
import { isAnimationActive } from '../../utils/animationTrial';

interface OchkoGameProps {
  chips: number;
  onUpdateChips: (newChips: number) => void;
  variant?: string; // 'classic' | 'bura' | 'seka'
  tableTheme?: string;
  cardBackTheme?: string;
  characterCustom?: CharacterCustomization;
  onExit?: () => void;
}

export const OchkoGame: React.FC<OchkoGameProps> = ({
  chips,
  onUpdateChips,
  variant = 'classic',
  tableTheme = 'green',
  cardBackTheme = 'royal_blue',
  characterCustom,
  onExit,
}) => {
  const [activeMode, setActiveMode] = useState<'classic' | 'bura' | 'seka'>(
    variant === 'bura' ? 'bura' : variant === 'seka' ? 'seka' : 'classic'
  );

  const [deckType, setDeckType] = useState<'ochko36' | 'blackjack52'>('ochko36');
  const [deck, setDeck] = useState<Card[]>([]);
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [dealerHand, setDealerHand] = useState<Card[]>([]);
  const [dealerRevealed, setDealerRevealed] = useState<boolean>(false);
  const [bet, setBet] = useState<number>(50);
  const [currentBet, setCurrentBet] = useState<number>(0);
  const [pot, setPot] = useState<number>(0);
  
  // Game state
  const [gameState, setGameState] = useState<'BETTING' | 'PLAYING' | 'DEALER_TURN' | 'ROUND_OVER'>('BETTING');
  const [resultMessage, setResultMessage] = useState<string>("Garov tiking va 'Tarqatish' tugmasini bosing.");
  const [winStatus, setWinStatus] = useState<'win' | 'lose' | 'push' | 'golden' | null>(null);

  // Bura mode specific state
  const [trumpSuit, setTrumpSuit] = useState<Suit>('hearts');
  const [playerPoints, setPlayerPoints] = useState<number>(0);
  const [botPoints, setBotPoints] = useState<number>(0);

  // In-Game Social
  const [activeEmoji, setActiveEmoji] = useState<string | null>(null);
  const [emojiTriggerKey, setEmojiTriggerKey] = useState<number>(0);
  const [isMicActive, setIsMicActive] = useState<boolean>(false);

  const isClassicOchko = deckType === 'ochko36';

  // Calculate Seka hand score (3 cards)
  const calculateSekaScore = (cards: Card[]): { score: number; label: string } => {
    if (cards.length < 3) return { score: 0, label: '' };
    // Check Troika (3 of a kind)
    if (cards[0].rank === cards[1].rank && cards[1].rank === cards[2].rank) {
      if (cards[0].rank === 'A') return { score: 33, label: "Oltin Troika (33 ochko)" };
      return { score: 30, label: `Troika ${cards[0].rank} (30 ochko)` };
    }
    // Check same suit sum (Flash)
    const suitGroups: { [key in Suit]?: Card[] } = {};
    cards.forEach(c => {
      if (!suitGroups[c.suit]) suitGroups[c.suit] = [];
      suitGroups[c.suit]!.push(c);
    });

    let bestScore = 0;
    let bestLabel = 'Oddiy ochko';

    // 2 Aces
    const aceCount = cards.filter(c => c.rank === 'A').length;
    if (aceCount === 2 && 22 > bestScore) {
      bestScore = 22;
      bestLabel = "Ikkita Tuz (22 ochko)";
    }

    Object.values(suitGroups).forEach(group => {
      let sum = 0;
      group.forEach(c => {
        if (c.rank === 'A') sum += 11;
        else if (['K', 'Q', 'J', '10'].includes(c.rank)) sum += 10;
        else sum += parseInt(c.rank as string, 10) || 6;
      });
      if (sum > bestScore) {
        bestScore = sum;
        bestLabel = group.length === 3 ? `Flash (${sum} ochko)` : `${sum} ochko`;
      }
    });

    if (bestScore === 0) {
      // highest card
      const highest = Math.max(...cards.map(c => (c.rank === 'A' ? 11 : 10)));
      bestScore = highest;
    }

    return { score: bestScore, label: bestLabel };
  };

  // Calculate Bura points (Ace=11, 10=10, K=4, Q=3, J=2)
  const calculateBuraPoints = (cards: Card[]): number => {
    return cards.reduce((acc, c) => {
      if (c.rank === 'A') return acc + 11;
      if (c.rank === '10') return acc + 10;
      if (c.rank === 'K') return acc + 4;
      if (c.rank === 'Q') return acc + 3;
      if (c.rank === 'J') return acc + 2;
      return acc;
    }, 0);
  };

  // Deal cards according to active mode
  const dealInitialCards = () => {
    if (chips < bet) {
      alert("Tanga yetarli emas! Kichikroq miqdor tanlang.");
      return;
    }

    sounds.playChip();
    onUpdateChips(chips - bet);
    setCurrentBet(bet);
    setPot(bet * 2);
    setWinStatus(null);
    setDealerRevealed(false);

    const newDeck = activeMode === 'classic' && !isClassicOchko ? createStandardDeck() : createDurakDeck();

    if (activeMode === 'seka') {
      // Seka deals 3 cards each
      const pCards = [newDeck.pop()!, newDeck.pop()!, newDeck.pop()!];
      const dCards = [newDeck.pop()!, newDeck.pop()!, newDeck.pop()!];
      setDeck(newDeck);
      setPlayerHand(pCards);
      setDealerHand(dCards);
      setGameState('PLAYING');
      sounds.playCardDeal();
      setResultMessage("Seka kartalaringiz tayyor. Bankni oshiring yoki oching!");
      return;
    }

    if (activeMode === 'bura') {
      // Bura deals 3 cards each and 1 trump
      const pCards = [newDeck.pop()!, newDeck.pop()!, newDeck.pop()!];
      const dCards = [newDeck.pop()!, newDeck.pop()!, newDeck.pop()!];
      const trump = newDeck.pop()!;
      setTrumpSuit(trump.suit);
      setDeck(newDeck);
      setPlayerHand(pCards);
      setDealerHand(dCards);
      setDealerRevealed(true);
      setGameState('PLAYING');
      sounds.playCardDeal();

      // Check instant Bura or Moskva
      const isPlayerBura = pCards.every(c => c.suit === trump.suit);
      const isPlayerMoskva = pCards.every(c => c.rank === 'A');

      if (isPlayerBura || isPlayerMoskva) {
        setGameState('ROUND_OVER');
        setWinStatus('golden');
        sounds.playWin();
        confetti({ particleCount: 120, spread: 80 });
        const reward = bet * 3;
        onUpdateChips(chips - bet + reward);
        setResultMessage(isPlayerBura ? "BURA! 3 ta Kozir karta! 3x Yutuq!" : "MOSKVA! 3 ta Tuz! 3x Yutuq!");
        return;
      }

      setResultMessage(`Bura o'yini: Kozir ${getSuitInfo(trump.suit).symbol}. 31 ochkoga birinchi yetgan yutadi!`);
      return;
    }

    // Classic 21 Ochko
    const p1 = newDeck.pop()!;
    const d1 = newDeck.pop()!;
    const p2 = newDeck.pop()!;
    const d2 = newDeck.pop()!;

    setDeck(newDeck);
    setPlayerHand([p1, p2]);
    setDealerHand([d1, d2]);
    sounds.playCardDeal();

    const playerScore = calculateOchkoScore([p1, p2], isClassicOchko);
    if (playerScore.isGolden || playerScore.score === 21) {
      setDealerRevealed(true);
      setGameState('ROUND_OVER');
      if (playerScore.isGolden) {
        setWinStatus('golden');
        setResultMessage("OLTIN OCHKO! Ikkita Tuz (A + A)! 3x yutuq!");
        sounds.playWin();
        confetti({ particleCount: 120, spread: 80 });
        onUpdateChips(chips - bet + bet * 3);
      } else {
        setWinStatus('win');
        setResultMessage("21 Ochko! Siz yutdingiz!");
        sounds.playWin();
        confetti({ particleCount: 90, spread: 60 });
        onUpdateChips(chips - bet + Math.floor(bet * 2.5));
      }
      return;
    }

    setGameState('PLAYING');
    setResultMessage("Sizning navbatingiz: 'Yana bitta' yoki 'Yetarli'.");
  };

  // Seka: Showdown / Open cards
  const handleSekaShowdown = () => {
    setDealerRevealed(true);
    setGameState('ROUND_OVER');
    sounds.playCardPlay();

    const pSeka = calculateSekaScore(playerHand);
    const dSeka = calculateSekaScore(dealerHand);

    if (pSeka.score > dSeka.score) {
      setWinStatus('win');
      setResultMessage(`G'alaba! Siz: ${pSeka.label}, Diler: ${dSeka.label}. +${pot} tanga!`);
      sounds.playWin();
      confetti({ particleCount: 100, spread: 70 });
      onUpdateChips(chips + pot);
    } else if (pSeka.score < dSeka.score) {
      setWinStatus('lose');
      setResultMessage(`Mag'lubiyat! Diler kuchliroq: ${dSeka.label} (Siz: ${pSeka.label}).`);
      sounds.playLose();
    } else {
      setWinStatus('push');
      setResultMessage(`Durang (Svara)! Ikkalangizda ham ${pSeka.label}. Garov qaytarildi.`);
      onUpdateChips(chips + currentBet);
    }
  };

  // Seka: Raise bet
  const handleSekaRaise = () => {
    if (chips < currentBet) {
      alert("Garovni oshirish uchun hisobingizda tanga yetarli emas!");
      return;
    }
    sounds.playChip();
    onUpdateChips(chips - currentBet);
    setPot(prev => prev + currentBet * 2);
    setCurrentBet(prev => prev * 2);
    setResultMessage("Siz garovni oshirdingiz. Diler qo'shildi!");
  };

  // Bura: Check points and claim 31
  const handleBuraClaim = () => {
    const pPoints = calculateBuraPoints(playerHand);
    const dPoints = calculateBuraPoints(dealerHand);
    setDealerRevealed(true);
    setGameState('ROUND_OVER');

    if (pPoints >= 31 || pPoints > dPoints) {
      setWinStatus('win');
      setResultMessage(`G'alaba! Sizda ${pPoints} ball (Dilerda ${dPoints}). +${pot} tanga!`);
      sounds.playWin();
      confetti({ particleCount: 100, spread: 70 });
      onUpdateChips(chips + pot);
    } else {
      setWinStatus('lose');
      setResultMessage(`Mag'lubiyat! Dilerda ${dPoints} ball (Sizda ${pPoints}).`);
      sounds.playLose();
    }
  };

  // Classic Ochko Hit
  const handleHit = () => {
    if (gameState !== 'PLAYING') return;
    sounds.playCardPlay();

    const newDeck = [...deck];
    const card = newDeck.pop();
    if (!card) return;

    const newHand = [...playerHand, card];
    setDeck(newDeck);
    setPlayerHand(newHand);

    const { score } = calculateOchkoScore(newHand, isClassicOchko);
    if (score > 21) {
      setDealerRevealed(true);
      setGameState('ROUND_OVER');
      setWinStatus('lose');
      setResultMessage(`Bust! Ballingiz: ${score}. 21 dan oshib ketdi.`);
      sounds.playLose();
    } else if (score === 21) {
      handleStand(newHand);
    }
  };

  // Classic Ochko Double
  const handleDouble = () => {
    if (gameState !== 'PLAYING' || playerHand.length !== 2) return;
    if (chips < currentBet) {
      alert("Ikkilantirish uchun tanga yetarli emas!");
      return;
    }
    sounds.playChip();
    onUpdateChips(chips - currentBet);
    const newTotalBet = currentBet * 2;
    setCurrentBet(newTotalBet);

    const newDeck = [...deck];
    const card = newDeck.pop();
    if (!card) return;

    const newHand = [...playerHand, card];
    setDeck(newDeck);
    setPlayerHand(newHand);
    sounds.playCardPlay();
    handleStand(newHand, newTotalBet);
  };

  // Classic Ochko Stand
  const handleStand = (currentPHand = playerHand, activeBet = currentBet) => {
    setGameState('DEALER_TURN');
    setDealerRevealed(true);
    sounds.playCardDeal();

    const pScore = calculateOchkoScore(currentPHand, isClassicOchko).score;
    let dHand = [...dealerHand];
    let dDeck = [...deck];

    const runDealer = () => {
      let dScore = calculateOchkoScore(dHand, isClassicOchko).score;
      while (dScore < 17 && dDeck.length > 0) {
        const nextCard = dDeck.pop()!;
        dHand.push(nextCard);
        dScore = calculateOchkoScore(dHand, isClassicOchko).score;
      }
      setDealerHand(dHand);
      setDeck(dDeck);
      setGameState('ROUND_OVER');

      if (pScore > 21) {
        setWinStatus('lose');
        setResultMessage(`Mag'lubiyat! Siz 21 dan oshdingiz (${pScore}).`);
        sounds.playLose();
      } else if (dScore > 21) {
        setWinStatus('win');
        setResultMessage(`G'alaba! Diler 21 dan oshdi (${dScore})!`);
        sounds.playWin();
        confetti({ particleCount: 80, spread: 70 });
        onUpdateChips(chips - (activeBet - currentBet) + activeBet * 2);
      } else if (pScore > dScore) {
        setWinStatus('win');
        setResultMessage(`G'alaba! Siz: ${pScore}, Diler: ${dScore}.`);
        sounds.playWin();
        confetti({ particleCount: 80, spread: 70 });
        onUpdateChips(chips - (activeBet - currentBet) + activeBet * 2);
      } else if (pScore < dScore) {
        setWinStatus('lose');
        setResultMessage(`Mag'lubiyat! Diler: ${dScore}, Siz: ${pScore}.`);
        sounds.playLose();
      } else {
        setWinStatus('push');
        setResultMessage(`Durang (Push)! Ikkalangizda ham ${pScore} ball.`);
        onUpdateChips(chips - (activeBet - currentBet) + activeBet);
      }
    };
    setTimeout(runDealer, 600);
  };

  const playerScore = calculateOchkoScore(playerHand, isClassicOchko);
  const dealerScore = dealerRevealed
    ? calculateOchkoScore(dealerHand, isClassicOchko)
    : dealerHand.length > 0
    ? calculateOchkoScore([dealerHand[0]], isClassicOchko)
    : { score: 0, isGolden: false };

  const sekaPScore = calculateSekaScore(playerHand);
  const sekaDScore = calculateSekaScore(dealerHand);

  // Dynamic table felt gradient
  const tableFeltClass =
    tableTheme === 'navy'
      ? 'from-blue-950 via-indigo-950 to-slate-950 border-indigo-900/40'
      : tableTheme === 'ruby'
      ? 'from-red-950 via-rose-950 to-slate-950 border-rose-900/40'
      : tableTheme === 'black'
      ? 'from-slate-950 via-zinc-900 to-black border-zinc-800'
      : 'from-emerald-950 via-emerald-900 to-slate-950 border-amber-900/40';

  return (
    <div className="w-full flex flex-col items-center select-none py-2 px-2 sm:px-6 max-w-5xl mx-auto animate-fade-in">
      <div className={`w-full rounded-2xl bg-gradient-to-b ${tableFeltClass} border-4 shadow-2xl p-4 sm:p-6 relative flex flex-col min-h-[580px] justify-between overflow-hidden`}>
        <div className="absolute inset-0 bg-[radial-gradient(#ffffff0a_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />

        {/* Top Controls: Game Mode Switcher & Balance */}
        <div className="relative z-10 flex items-center justify-between border-b border-white/10 pb-3 flex-wrap gap-2">
          {/* Game Modes (21 Ochko, Seka, Bura) */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-950/70 rounded-xl border border-slate-800">
            <button
              onClick={() => {
                setActiveMode('classic');
                setGameState('BETTING');
                sounds.playChip();
              }}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                activeMode === 'classic'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              21 Ochko
            </button>
            <button
              onClick={() => {
                setActiveMode('seka');
                setGameState('BETTING');
                sounds.playChip();
              }}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                activeMode === 'seka'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Seka (3 Karta)
            </button>
            <button
              onClick={() => {
                setActiveMode('bura');
                setGameState('BETTING');
                sounds.playChip();
              }}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                activeMode === 'bura'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Bura / 31
            </button>
          </div>

          {/* Chips & Exit */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 text-amber-300 text-xs font-mono font-bold bg-slate-950/80 px-3 py-1.5 rounded-lg border border-slate-800 shadow">
              <Coins className="w-4 h-4 text-amber-400" />
              <span>Hisob: {chips.toLocaleString()} tanga</span>
            </div>
            {onExit && (
              <button
                onClick={onExit}
                className="px-2.5 py-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-xs font-semibold text-slate-300 border border-slate-700 transition-colors"
              >
                Chiqish
              </button>
            )}
          </div>
        </div>

        {/* Dealer Zone (Top Center with 3D Character) */}
        <div className="relative z-10 flex flex-col items-center my-1">
          <ThreeDCharacter
            name={activeMode === 'seka' ? "Raqib (Seka Ustasi)" : activeMode === 'bura' ? "Bura O'yinchisi" : "Kazino Dileri (3D)"}
            variant={activeMode === 'seka' ? 'karleone' : activeMode === 'bura' ? 'jasur' : 'dealer'}
            customization={characterCustom}
            isThinking={gameState === 'DEALER_TURN'}
            isSpeaking={isMicActive}
            activeEmoji={activeEmoji}
            triggerKey={emojiTriggerKey}
            nameplatePosition="top"
            mood={
              winStatus === 'lose'
                ? 'win'
                : winStatus === 'win'
                ? 'lose'
                : gameState === 'DEALER_TURN'
                ? 'thinking'
                : 'idle'
            }
            cardsCount={dealerHand.length}
            className="-mb-2"
          />

          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              {activeMode === 'seka' ? "Raqib Kartalari" : "Diler Kartalari"}
            </span>
            {dealerHand.length > 0 && (
              <span className="text-xs font-mono font-bold bg-slate-900/80 px-2 py-0.5 rounded text-amber-300 border border-slate-700">
                {activeMode === 'seka'
                  ? dealerRevealed ? `${sekaDScore.score} ochko (${sekaDScore.label})` : "? ochko"
                  : activeMode === 'bura'
                  ? `${calculateBuraPoints(dealerHand)} ball`
                  : dealerRevealed
                  ? `${dealerScore.score} ball`
                  : `${dealerScore.score} + ?`}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 min-h-[110px]">
            {dealerHand.map((card, idx) => (
              <PlayingCard
                key={card.id || idx}
                card={card}
                faceUp={idx === 0 || dealerRevealed || activeMode === 'bura'}
                size="md"
                cardBackTheme={cardBackTheme}
              />
            ))}
            {dealerHand.length === 0 && (
              <div className="w-16 h-24 sm:w-20 sm:h-28 rounded-lg border-2 border-dashed border-white/20 flex items-center justify-center text-xs text-emerald-400/50">
                Diler
              </div>
            )}
          </div>
        </div>

        {/* Center Battle / Result Banner */}
        <div className="relative z-10 flex flex-col items-center justify-center my-2 text-center">
          {winStatus === 'golden' && (
            <div className="mb-2 flex items-center gap-1.5 px-4 py-1.5 bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 font-black rounded-full shadow-lg shadow-amber-500/50 text-sm animate-bounce">
              <Flame className="w-4 h-4" />
              {activeMode === 'bura' ? "BURA! 3x YUTUQ!" : "OLTIN OCHKO (A + A)!"}
            </div>
          )}

          <div className="bg-slate-950/80 px-5 py-2 rounded-2xl border border-white/10 shadow-xl max-w-md">
            <p className="text-sm font-semibold text-slate-100">{resultMessage}</p>
            {currentBet > 0 && (
              <p className="text-xs text-amber-400 font-mono mt-0.5">
                {activeMode === 'seka' ? `Bank: ${pot} tanga | Garov: ${currentBet}` : `Joriy garov: ${currentBet} tanga`}
              </p>
            )}
          </div>
        </div>

        {/* Player Zone (Bottom Center) */}
        <div className="relative z-10 flex flex-col items-center my-1">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">Sizning Kartalaringiz</span>
            {playerHand.length > 0 && (
              <span
                className={`text-xs font-mono font-bold px-2 py-0.5 rounded border ${
                  playerScore.score === 21 || sekaPScore.score >= 30
                    ? 'bg-amber-500 text-slate-950 border-amber-400 font-black'
                    : playerScore.score > 21
                    ? 'bg-red-950 text-red-300 border-red-700'
                    : 'bg-slate-900/80 text-amber-300 border-slate-700'
                }`}
              >
                {activeMode === 'seka'
                  ? `${sekaPScore.label}`
                  : activeMode === 'bura'
                  ? `${calculateBuraPoints(playerHand)} ball`
                  : `Ball: ${playerScore.score} ${playerScore.isGolden ? '(Oltin Ochko)' : ''}`}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 min-h-[110px]">
            {playerHand.map((card) => (
              <PlayingCard key={card.id} card={card} faceUp={true} size="md" cardBackTheme={cardBackTheme} />
            ))}
            {playerHand.length === 0 && (
              <div className="w-16 h-24 sm:w-20 sm:h-28 rounded-lg border-2 border-dashed border-white/20 flex items-center justify-center text-xs text-emerald-400/50">
                O'yinchi
              </div>
            )}
          </div>
        </div>

        {/* Bottom Action Controls & Social Hub */}
        <div className="relative z-10 flex flex-col items-center gap-2.5 pt-2 border-t border-white/10">
          <InGameSocialBar
            playerName="Siz"
            opponentName={activeMode === 'seka' ? "Raqib" : "Diler"}
            onSendEmoji={(emoji) => {
              const matchedAnim = CHARACTER_ANIMATIONS.find(a => a.emoji === emoji || a.actionKey === emoji);
              if (matchedAnim && !isAnimationActive(matchedAnim.id)) {
                sounds.playCardPlay();
                setResultMessage(`🔒 "${matchedAnim.name}" animatsiyasi qulflangan! Profilingizdagi Omad G'ildiragida 7 kunga yutib oling.`);
                return;
              }
              setActiveEmoji(emoji);
              setEmojiTriggerKey((prev) => prev + 1);
            }}
            onMicToggle={(active) => setIsMicActive(active)}
            isMicActive={isMicActive}
          />

          {gameState === 'BETTING' || gameState === 'ROUND_OVER' ? (
            <div className="w-full flex flex-col sm:flex-row items-center justify-between gap-3">
              {/* Bet Chip selector */}
              <div className="flex items-center gap-1.5 sm:gap-2">
                <span className="text-xs text-slate-400 font-semibold mr-1">Garov:</span>
                {[10, 50, 100, 250, 500].map((amount) => (
                  <button
                    key={amount}
                    onClick={() => {
                      setBet(amount);
                      sounds.playChip();
                    }}
                    className={`w-9 h-9 sm:w-11 sm:h-11 rounded-full text-xs font-bold font-mono transition-transform border-2 flex items-center justify-center shadow-md ${
                      bet === amount
                        ? 'bg-amber-500 text-slate-950 border-amber-200 scale-110 shadow-amber-500/40'
                        : 'bg-slate-800/90 text-slate-300 border-slate-600 hover:scale-105'
                    }`}
                  >
                    {amount}
                  </button>
                ))}
              </div>

              {/* Deal button */}
              <button
                onClick={dealInitialCards}
                className="w-full sm:w-auto px-8 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-sm tracking-wide shadow-lg shadow-amber-500/30 transition-all flex items-center justify-center gap-2"
              >
                <Trophy className="w-4 h-4" />
                Tarqatish (Deal)
              </button>
            </div>
          ) : (
            /* Mode-specific actions */
            <div className="flex items-center gap-3">
              {activeMode === 'seka' ? (
                <>
                  <button
                    onClick={handleSekaRaise}
                    className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-blue-600/30 transition-all"
                  >
                    Oshirish (+{currentBet})
                  </button>
                  <button
                    onClick={handleSekaShowdown}
                    className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs sm:text-sm shadow-lg shadow-amber-500/30 transition-all"
                  >
                    Kartalarni Ochish
                  </button>
                </>
              ) : activeMode === 'bura' ? (
                <>
                  <button
                    onClick={handleBuraClaim}
                    className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs sm:text-sm shadow-lg shadow-amber-500/30 transition-all"
                  >
                    Ochkoni Sanash / Ochish
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={handleHit}
                    disabled={gameState !== 'PLAYING'}
                    className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-600/30 transition-all"
                  >
                    Yana bitta (Hit)
                  </button>
                  <button
                    onClick={() => handleStand()}
                    disabled={gameState !== 'PLAYING'}
                    className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs sm:text-sm shadow-lg shadow-amber-500/30 transition-all"
                  >
                    Yetarli (Stand)
                  </button>
                  {playerHand.length === 2 && chips >= currentBet && (
                    <button
                      onClick={handleDouble}
                      disabled={gameState !== 'PLAYING'}
                      className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-indigo-600/30 transition-all"
                    >
                      Ikkilantirish (x2)
                    </button>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
