import React from 'react';
import { Volume2, VolumeX, Coins, Plus, Users, Trophy, LayoutGrid, HelpCircle, RotateCw, Sparkles } from 'lucide-react';
import { UserProfileData } from '../lib/firebase';
import { sounds } from '../utils/audio';

interface HeaderProps {
  profile: UserProfileData;
  activeView: 'catalog' | 'game' | 'friends' | 'leaderboard';
  onNavigate: (view: 'catalog' | 'friends' | 'leaderboard') => void;
  onOpenProfile: () => void;
  onOpenRules: () => void;
  onClaimCoinsBonus: () => void;
  onOpenLevelRoadmap: () => void;
  onOpenLuckyWheel: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  profile,
  activeView,
  onNavigate,
  onOpenProfile,
  onOpenRules,
  onClaimCoinsBonus,
  onOpenLevelRoadmap,
  onOpenLuckyWheel,
  soundEnabled,
  onToggleSound,
}) => {
  const isVip = (profile.vipExpiresAt || 0) > Date.now();
  const tickets = profile.spinTickets ?? 3;

  return (
    <header className="w-full bg-slate-950/95 border-b border-slate-800 backdrop-blur-md sticky top-0 z-40 px-3 sm:px-6 py-2.5">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* TEPADA CHAPDA: Profil Bo'limi */}
        <div className="flex items-center gap-2">
          <div
            onClick={() => {
              sounds.playChip();
              onOpenProfile();
            }}
            className="flex items-center gap-2.5 cursor-pointer p-1.5 rounded-xl hover:bg-slate-900/80 transition-all border border-transparent hover:border-slate-800 group shrink-0"
            title="Profilni ochish"
          >
            {/* Avatar */}
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500/20 to-amber-700/30 border-2 border-amber-500/70 flex items-center justify-center text-xl shadow-md group-hover:scale-105 transition-transform relative">
              {profile.avatar || '👑'}
              {isVip && (
                <span className="absolute -top-1 -right-1 text-xs" title="VIP Status Faol">
                  👑
                </span>
              )}
            </div>

            {/* User Details */}
            <div className="hidden sm:block text-left">
              <div className="flex items-center gap-1.5 leading-none">
                <span className="text-sm font-bold text-slate-100 group-hover:text-amber-300 transition-colors">
                  {profile.displayName || "O'yinchi"}
                </span>
                {isVip && (
                  <span className="text-[9px] bg-gradient-to-r from-purple-600 to-amber-500 text-white font-extrabold px-1.5 py-0.2 rounded shadow">
                    VIP
                  </span>
                )}
              </div>
              <span className="text-[11px] text-slate-400 font-mono mt-0.5 block">
                Profil & Statistika →
              </span>
            </div>
          </div>

          {/* 100 LVL Roadmap Quick Button */}
          <button
            onClick={() => {
              sounds.playChip();
              onOpenLevelRoadmap();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/20 to-amber-600/10 border border-amber-500/40 hover:border-amber-400 text-amber-300 hover:text-amber-200 transition-all shadow-sm group"
            title="100 ta LVL Chempionlik Yo'li"
          >
            <div className="w-5 h-5 rounded-md bg-amber-500 text-slate-950 font-black text-[10px] flex items-center justify-center font-mono">
              ★
            </div>
            <div className="text-left font-mono">
              <span className="text-xs font-bold leading-none block">
                LVL {profile.level || 1}
              </span>
              <span className="text-[9px] text-slate-400 hidden md:block">
                100 LVL Yo'li
              </span>
            </div>
          </button>
        </div>

        {/* ORTADA: O'ynash va Asosiy Bo'limlar */}
        <nav className="flex items-center gap-1 sm:gap-2">
          <button
            onClick={() => {
              sounds.playChip();
              onNavigate('catalog');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition-all whitespace-nowrap ${
              activeView === 'catalog'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-300 hover:text-white hover:bg-slate-900'
            }`}
          >
            <LayoutGrid className="w-4 h-4" />
            <span>O'ynash</span>
          </button>

          <button
            onClick={() => {
              sounds.playChip();
              onNavigate('friends');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition-all whitespace-nowrap ${
              activeView === 'friends'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-300 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Users className="w-4 h-4" />
            <span className="hidden xs:inline">Do'stlar bilan</span>
          </button>

          <button
            onClick={() => {
              sounds.playChip();
              onNavigate('leaderboard');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition-all whitespace-nowrap ${
              activeView === 'leaderboard'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-300 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Trophy className="w-4 h-4" />
            <span className="hidden xs:inline">Reyting</span>
          </button>
        </nav>

        {/* TEPADA O'NG BURCHAKDA: Tangalar Balansi, G'ildirak va Qo'shimcha */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Omad G'ildiragi Button */}
          <button
            onClick={() => {
              sounds.playChip();
              onOpenLuckyWheel();
            }}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-900/60 via-indigo-950 to-slate-900 border border-purple-500/50 hover:border-purple-400 text-purple-200 hover:text-white transition-all shadow-md group relative"
            title="Omad G'ildiragini aylantirish"
          >
            <RotateCw className="w-4 h-4 text-amber-400 group-hover:rotate-180 transition-transform duration-500" />
            <span className="text-xs font-bold hidden sm:inline">G'ildirak</span>
            {tickets > 0 ? (
              <span className="px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 text-[10px] font-mono font-black animate-pulse">
                {tickets}
              </span>
            ) : (
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            )}
          </button>

          {/* Tangalar Ko'rsatkichi */}
          <div className="flex items-center gap-1.5 bg-gradient-to-r from-slate-900 via-amber-950/40 to-slate-900 border border-amber-500/40 px-2.5 sm:px-3 py-1.5 rounded-xl shadow-inner">
            <Coins className="w-4 h-4 text-amber-400 animate-pulse" />
            <span className="text-xs sm:text-sm font-bold font-mono text-amber-300 tabular-nums">
              {profile.chips.toLocaleString()}
            </span>

            {/* Quick Coin Plus Bonus */}
            <button
              onClick={onClaimCoinsBonus}
              title="+500 Tanga olish"
              className="ml-1 w-5 h-5 rounded-md bg-amber-500 hover:bg-amber-400 text-slate-950 flex items-center justify-center font-bold text-xs shadow transition-transform hover:scale-110 active:scale-95"
            >
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
            </button>
          </div>

          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            title={soundEnabled ? "Ovozni o'chirish" : 'Ovozni yoqish'}
            className="p-2 text-slate-400 hover:text-slate-100 hover:bg-slate-900 rounded-xl transition-colors"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Qoidalar */}
          <button
            onClick={onOpenRules}
            title="Qoidalar"
            className="hidden md:flex p-2 text-slate-400 hover:text-slate-100 hover:bg-slate-900 rounded-xl transition-colors"
          >
            <HelpCircle className="w-4 h-4 text-amber-400" />
          </button>
        </div>
      </div>
    </header>
  );
};
