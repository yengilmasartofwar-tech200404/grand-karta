import React, { useEffect, useState } from 'react';
import { UserProfileData, getLeaderboard } from '../lib/firebase';
import { X, Trophy, Medal, Crown, Coins } from 'lucide-react';

interface LeaderboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfileData;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({
  isOpen,
  onClose,
  currentUser,
}) => {
  const [leaders, setLeaders] = useState<UserProfileData[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    if (!isOpen) return;
    setLoading(true);
    getLeaderboard().then((data) => {
      // Ensure current user is included or placed
      let list = [...data];
      if (!list.some((u) => u.uid === currentUser.uid)) {
        list.push(currentUser);
      }
      list.sort((a, b) => b.chips - a.chips);
      setLeaders(list);
      setLoading(false);
    });
  }, [isOpen, currentUser]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/70">
          <div className="flex items-center gap-2.5">
            <Trophy className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="text-base font-bold text-slate-100 font-serif">Klub Reytingi</h2>
              <p className="text-xs text-slate-400">Eng kuchli va badavlat karta ustalari</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg transition-colors hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-3">
          {loading ? (
            <div className="py-12 text-center text-xs text-slate-400">
              Reyting yuklanmoqda...
            </div>
          ) : (
            leaders.map((player, idx) => {
              const isMe = player.uid === currentUser.uid;
              return (
                <div
                  key={player.uid || idx}
                  className={`flex items-center justify-between p-3 rounded-xl border transition-all ${
                    isMe
                      ? 'bg-amber-500/15 border-amber-500/50 shadow-md shadow-amber-500/10'
                      : idx === 0
                      ? 'bg-gradient-to-r from-amber-950/40 to-slate-900 border-amber-500/40'
                      : 'bg-slate-950/50 border-slate-800/80'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {/* Rank position */}
                    <div className="w-7 text-center font-bold font-mono text-sm">
                      {idx === 0 ? (
                        <Crown className="w-5 h-5 text-amber-400 mx-auto" />
                      ) : idx === 1 ? (
                        <Medal className="w-5 h-5 text-slate-300 mx-auto" />
                      ) : idx === 2 ? (
                        <Medal className="w-5 h-5 text-amber-600 mx-auto" />
                      ) : (
                        <span className="text-slate-500">#{idx + 1}</span>
                      )}
                    </div>

                    {/* Avatar */}
                    <span className="text-2xl">{player.avatar || '👑'}</span>

                    {/* Name & Title */}
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-sm font-bold text-slate-100">
                          {player.displayName}
                        </span>
                        {isMe && (
                          <span className="text-[10px] bg-amber-500 text-slate-950 font-black px-1.5 py-0.2 rounded font-sans">
                            SIZ
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400 font-mono">
                        {player.durakWins} g'alaba · {player.level || 1}-daraja
                      </span>
                    </div>
                  </div>

                  {/* Chips count */}
                  <div className="flex items-center gap-1.5 text-amber-300 font-bold font-mono text-xs sm:text-sm">
                    <Coins className="w-3.5 h-3.5 text-amber-400" />
                    <span>{player.chips.toLocaleString()}</span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/70 flex justify-between items-center text-xs text-slate-400">
          <span>Har hafta eng yaxshi 3 nafar o'yinchiga kubok va mukofot beriladi!</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 font-semibold"
          >
            Yopish
          </button>
        </div>
      </div>
    </div>
  );
};
