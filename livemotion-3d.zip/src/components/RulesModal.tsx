import React, { useState } from 'react';
import { X, BookOpen, Swords, Trophy, Layers, Flame } from 'lucide-react';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultMode?: string;
}

export const RulesModal: React.FC<RulesModalProps> = ({
  isOpen,
  onClose,
  defaultMode = 'durak',
}) => {
  const [activeTab, setActiveTab] = useState<string>(defaultMode);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-xs animate-fade-in">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center gap-2.5">
            <BookOpen className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-bold text-slate-100 font-serif">O'yin Qoidalari va Yo'riqnoma</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg transition-colors hover:bg-slate-800"
            aria-label="Yopish"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-1.5 px-4 pt-3 border-b border-slate-800 bg-slate-950/40 overflow-x-auto scrollbar-none">
          {[
            { id: 'ming', label: '1000 (Ming)' },
            { id: 'durak', label: 'Durak' },
            { id: 'ochko', label: '21 Ochko' },
            { id: 'seka', label: 'Seka (3 Karta)' },
            { id: 'bura', label: 'Bura / 31' },
            { id: 'solitaire', label: 'Klondike' },
            { id: 'spider', label: 'Pauk (Spider)' },
            { id: 'devyatka', label: 'To\'qqizlik (9)' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`pb-2.5 px-3 text-xs sm:text-sm font-bold whitespace-nowrap transition-colors border-b-2 ${
                activeTab === tab.id
                  ? 'border-amber-400 text-amber-300'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4 text-sm text-slate-300 leading-relaxed">
          {activeTab === 'ming' && (
            <div className="space-y-4">
              <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
                <h3 className="font-bold text-amber-300 mb-1 text-base">🎯 1. O‘yinning Maqsadi</h3>
                <p>
                  O‘yinda 2, 3 yoki 4 kishi qatnashadi (Klassik: 3 kishi). Asosiy maqsad — savdolarda yutib, kartalar va marjlar (kozirlar) yordamida birinchi bo‘lib <span className="text-amber-400 font-bold">1000 ochko</span> to‘plash.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">🃏 2. Kartalar va Ochkolar (Jami 120 ochko)</h4>
                <p className="mb-2">
                  O‘yinda faqat 24 ta karta qatnashadi (To‘qqizdan Tuzgacha). Barcha kartalarning ochkolar yig‘indisi aynan 120 ochkoga teng:
                </p>
                <div className="border border-slate-700 rounded-lg overflow-hidden text-xs">
                  <table className="w-full text-left font-mono">
                    <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                      <tr>
                        <th className="p-2">Karta</th>
                        <th className="p-2">Nomi</th>
                        <th className="p-2">1 tasining ochkosi</th>
                        <th className="p-2">4 ta mast yig‘indisi</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 text-slate-200">
                      <tr>
                        <td className="p-2 font-bold text-amber-400">A</td>
                        <td className="p-2">Tuz</td>
                        <td className="p-2 font-bold">11</td>
                        <td className="p-2">44</td>
                      </tr>
                      <tr>
                        <td className="p-2 font-bold text-amber-400">10</td>
                        <td className="p-2">O‘nlik</td>
                        <td className="p-2 font-bold">10</td>
                        <td className="p-2">40</td>
                      </tr>
                      <tr>
                        <td className="p-2 font-bold text-amber-400">K</td>
                        <td className="p-2">Karol</td>
                        <td className="p-2 font-bold">4</td>
                        <td className="p-2">16</td>
                      </tr>
                      <tr>
                        <td className="p-2 font-bold text-amber-400">Q</td>
                        <td className="p-2">Dama</td>
                        <td className="p-2 font-bold">3</td>
                        <td className="p-2">12</td>
                      </tr>
                      <tr>
                        <td className="p-2 font-bold text-amber-400">J</td>
                        <td className="p-2">Valet</td>
                        <td className="p-2 font-bold">2</td>
                        <td className="p-2">8</td>
                      </tr>
                      <tr>
                        <td className="p-2 font-bold text-slate-400">9</td>
                        <td className="p-2">To‘qqiz</td>
                        <td className="p-2 font-bold">0</td>
                        <td className="p-2">0</td>
                      </tr>
                      <tr className="bg-slate-950/80 font-bold text-amber-300">
                        <td className="p-2" colSpan={2}>JAMI</td>
                        <td className="p-2">—</td>
                        <td className="p-2">120 ochko</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <p className="text-xs text-amber-300 mt-2 font-mono">
                  ⚠️ Eslatma: Kartalar kuchi bo‘yicha tartib: 9 &lt; J &lt; Q &lt; K &lt; 10 &lt; A (10 karoldan va damadan kuchli!).
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">👑 3. Marjlar (Kozirlar) va Ularning Qiymati</h4>
                <p className="mb-2">
                  Marj — bu bitta mastdagi Karol (K) va Dama (Q) juftligi. Marj ochilganda o‘sha mast avtomatik tarzda KOZIRga aylanadi:
                </p>
                <ul className="list-disc list-inside space-y-1 text-slate-300 text-xs sm:text-sm">
                  <li>♠ <strong>Pika (Qora qarg‘a):</strong> K♠ + Q♠ = <span className="text-amber-400 font-bold">+40 ochko</span></li>
                  <li>♣ <strong>Tref (Chillak / G‘isht):</strong> K♣ + Q♣ = <span className="text-amber-400 font-bold">+60 ochko</span></li>
                  <li>♦ <strong>Bubna (Qizil g‘isht):</strong> K♦ + Q♦ = <span className="text-amber-400 font-bold">+80 ochko</span></li>
                  <li>♥ <strong>Cherva (Yurak):</strong> K♥ + Q♥ = <span className="text-amber-400 font-bold">+100 ochko</span></li>
                </ul>
                <div className="mt-2 p-3 rounded-lg bg-red-950/30 border border-red-800/40 text-xs space-y-1 text-slate-200">
                  <div className="font-bold text-red-300">⚠️ Kozir ochishning qat'iy qoidalari:</div>
                  <div>• <strong>O‘zi olgan bo‘lishi shart:</strong> O‘yinchi avval kamida bitta vzatkani (kartalarni) yutib olgan bo‘lishi kerak. Hali birorta karta yutmagan bo‘lsa, marj ocholmaydi.</div>
                  <div>• <strong>Yurish o‘zida bo‘lishi shart:</strong> Stolga birinchi bo‘lib o‘zi Dama yoki Karol bilan yurishi kerak.</div>
                  <div>• <strong>Boshqa birov birinchi yurgan bo‘lsa:</strong> Unga javoban Dama yoki Karol tashlansa — kozir ochilmaydi, faqat Dama 3, Karol 4 ochko hisoblanadi.</div>
                </div>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-1">🔄 4. Qayta Tarqatish (Pererazdacha)</h4>
                <p className="text-xs">
                  Kartalar tarqatilganda har qanday o‘yinchining qo‘lida quyidagilardan biri to‘plansa, o‘yin bekor qilinib, kartalar qaytadan tarqatiladi:
                  <strong className="text-amber-300 block mt-1">4 ta Tuz (A), 4 ta Karol (K) yoki 4 ta Dama (Q).</strong>
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-1">🗣️ 5. Savdo (Bidding) Jarayoni</h4>
                <p className="text-xs space-y-1">
                  Kartalar tarqatiladi, stol o‘rtasiga 3 ta karta yopiq talon qo‘yiladi. Savdo 100 ochkodan boshlanadi va 5 tadan oshirib boriladi (105, 110, 115, 120...).
                  <br />
                  <strong className="text-red-400 block mt-1">
                    ⚠️ 120 ochkodan yuqori savdo qilish uchun o‘yinchining qo‘lida albatta qizil marj (♥ yoki ♦ ning K+Q juftligi) bo‘lishi shart!
                  </strong>
                  Kim eng yuqori ochkoni aytsa va boshqalar «pas» desa, savdoni yutadi.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-1">🎁 6. Talonni Ochish va 2 ta Kartani Berish</h4>
                <p className="text-xs">
                  Savdoni yutgan o‘yinchi o‘rtadagi 3 ta talon kartasini oladi va barchaga ko‘rsatadi. Endi uning qo‘lidagi ortiqcha 2 ta kartani raqiblarga 1 tadan beradi. Shundan so‘ng o‘yinchi o‘zi to‘playdigan yakuniy ochkoni e'lon qiladi (savdoda yutgan ochkosidan kam bo‘lmasligi kerak).
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-1">🃏 7. O‘yin Jarayoni (Yurish Tartibi)</h4>
                <p className="text-xs">
                  Stolga birinchi tashlangan kartaning mastiga mos karta tashlanishi shart. Agar qo‘lda u mastdan bo‘lmasa — kozir tashlanadi. Agar kozir ham bo‘lmasa — istalgan boshqa karta tashlanadi. Eng katta karta yoki eng katta kozirni tashlagan o‘yinchi vzatkani oladi va keyingi yurishni boshlaydi.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-1">🛢️ 8. 800 Ochkoga Yetgandagi Qoidalar (Bo‘chka: 800 dan 1000 gacha)</h4>
                <ul className="text-xs list-disc list-inside space-y-1 text-slate-300">
                  <li><strong>Savdoga kira olmaslik:</strong> 800 ochkoga yetgan o‘yinchi savdoda qatnasha olmaydi (unga avtomatik pas beriladi). U faqat qo‘liga tarqatilgan kartalar bilan o‘ynaydi.</li>
                  <li><strong>Kozir ochish, lekin marj ochkosi berilmasligi:</strong> 800 ga to‘lgan o‘yinchi marj ochsa, mast kozir bo‘ladi, lekin unga marj uchun beriladigan bonus (+40, +60, +80, +100) yozilmaydi (0 ochko). O‘yinchi faqat qo‘lga kiritgan kartalarining ochkosini to‘playdi.</li>
                  <li><strong>Barcha o‘yinchilar 800 ga to‘lsa:</strong> Stol o‘rtasidagi 3 ta yopiq talon kartasi o‘yinchilarga 1 tadan teng taqsimlanadi. Hech qanday savdo bo‘lmaydi — dilerdan keyingi o‘yinchi to‘g‘ridan-to‘g‘ri o‘yinni boshlaydi.</li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-1">➖ 9. Minus (–) Qoidasi</h4>
                <ul className="text-xs list-disc list-inside space-y-1 text-slate-300">
                  <li>Savdodan chiqqan (pas degan) o‘yinchi birorta ham karta yutib ololmasa (0 ochko olsa), unga daftarda «–» (minus) belgisi yoziladi.</li>
                  <li>Savdoni yutgan o‘yinchi karta ololmasa ham unga «–» yozilmaydi (chunki unga aytgan ochkosi minus bo‘lib yoziladi).</li>
                  <li><strong>3 ta «–» yig‘ilsa:</strong> o‘yinchining umumiy hisobidan –120 ochko jarima sifatida ayiriladi va minuslar o‘chiriladi.</li>
                  <li><strong>-240 ochko bo‘lsa:</strong> o‘yinchi savdoga kira olmaydi.</li>
                </ul>
              </div>

              <div className="p-3 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-200 text-xs font-bold">
                🏆 10. G‘alaba: Birinchi bo‘lib 1000 ochko to‘plagan o‘yinchi mutlaq g‘olib deb e'lon qilinadi!
              </div>
            </div>
          )}

          {activeTab === 'durak' && (
            <div className="space-y-4">
              <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
                <h3 className="font-bold text-amber-300 mb-1 text-base">Asosiy Maqsad</h3>
                <p>
                  Koloda tugagandan so'ng qo'lingizdagi barcha kartalardan birinchi bo'lib qutulish.
                  O'yinda durang bo'lmaydi: qo'lida karta qolgan oxirgi o'yinchi yutqazadi ("Durak" yoki "Ahmoq").
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">1. Kozir (Trump) va Koloda</h4>
                <p>
                  36 ta karta (6 dan Tuzgacha). Boshida bitta karta ochiladi va uning masti <span className="text-amber-300 font-semibold">Kozir</span> bo'ladi.
                  Kozir har qanday oddiy mastdagi kartani uradi. Kozirni faqat kattaroq kozir bilan urish mumkin.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">2. Hujum va Himoya</h4>
                <ul className="list-disc list-inside space-y-1.5 text-slate-300">
                  <li><strong className="text-slate-100">Yurish (Hujum):</strong> Hujumchi stoldagi raqibga bitta yoki bir necha bir xil qiymatdagi kartani tashlaydi.</li>
                  <li><strong className="text-slate-100">Qaytarish (Himoya):</strong> Himoyachi har bir kartani o'sha mastdagi kattaroq karta yoki kozir bilan urishi kerak.</li>
                  <li><strong className="text-slate-100">Tashlash (Podkidnoy):</strong> Agar stolda mavjud qiymatdagi karta bo'lsa, hujumchi yana qo'shimcha kartalar tashlashi mumkin.</li>
                  <li><strong className="text-blue-400 font-bold">O'tkazma (Perevodnoy):</strong> Agar himoyachi hali hech qaysi kartani urmagan bo'lsa va qo'lida hujum qilingan karta bilan bir xil raqamli karta bo'lsa, u kartani qo'yib hujumni keyingi o'yinchiga o'tkazishi (Perevod qilishi) mumkin!</li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">3. Bita yoki Olish</h4>
                <p>
                  Agar himoyachi barcha kartalarni ursa va hujumchida boshqa tashlash bo'lmasa, <strong className="text-emerald-400">"Bita"</strong> bo'ladi (kartalar chetga chiqadi) va navbat himoyachiga o'tadi.
                  Agar himoyachi kartalarni ura olmasa, <strong className="text-red-400">"Kartalarni olish"</strong> tugmasini bosib barcha kartalarni o'ziga oladi.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'ochko' && (
            <div className="space-y-4">
              <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
                <h3 className="font-bold text-amber-300 mb-1 text-base">Asosiy Maqsad</h3>
                <p>
                  Dilerga (botga) qarshi o'ynab, kartalar umumiy yig'indisini 21 ga yaqinlashtirish.
                  21 dan oshib ketish (bust) mag'lubiyat hisoblanadi.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">Kartalar Qiymati (O'zbekcha 21 Ochko)</h4>
                <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <div>Tuz (A) = 11 yoki 1 ochko</div>
                  <div>Qirol (K) = 4 ochko</div>
                  <div>Dama (Q) = 3 ochko</div>
                  <div>Valet (J) = 2 ochko</div>
                  <div>10, 9, 8, 7, 6 = o'z qiymati</div>
                  <div className="col-span-2 text-amber-300 font-sans font-bold pt-1">
                    🔥 A + A (Ikkita Tuz) = "Oltin Ochko" (Instant Win! 3x Yutuq)
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">Amallar</h4>
                <ul className="list-disc list-inside space-y-1.5">
                  <li><strong className="text-slate-100">Yana bitta (Hit):</strong> Qo'shimcha karta olish.</li>
                  <li><strong className="text-slate-100">Yetarli (Stand):</strong> O'z ballingiz bilan to'xtash va navbatni dilerga berish.</li>
                  <li><strong className="text-slate-100">Ikkilantirish (Double):</strong> Tikilgan tangani 2 barobar oshirib, oxirgi bitta karta olish.</li>
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'seka' && (
            <div className="space-y-4">
              <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
                <h3 className="font-bold text-amber-300 mb-1 text-base">Seka (3 Karta) Qoidalari</h3>
                <p>
                  Har bir o'yinchiga 3 tadan karta beriladi. Maqsad eng kuchli kombinatsiyani yig'ish yoki dilerga qarshi garovni oshirib uni yengish.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">Kombinatsiyalar (Yuqoridan Pastga):</h4>
                <ul className="list-disc list-inside space-y-2 text-slate-300 text-xs font-mono bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <li><strong className="text-amber-400">Oltin Troika (A + A + A):</strong> 33 ochko — eng kuchli kombinatsiya!</li>
                  <li><strong className="text-amber-300">Troika (Uchta bir xil karta):</strong> 3 ta Qirol (30 ochko), 3 ta Dama (30 ochko) va h.k.</li>
                  <li><strong className="text-emerald-400">Flash (Bir xil mastdagi 3 ta karta):</strong> Kartalar ochkosi qo'shiladi (Tuz=11, K/Q/J/10=10).</li>
                  <li><strong className="text-slate-200">Ikkita Tuz (A + A):</strong> 22 ochko.</li>
                  <li><strong className="text-slate-300">Bir xil mastdagi 2 ta karta:</strong> Ochkolari qo'shiladi.</li>
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'bura' && (
            <div className="space-y-4">
              <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
                <h3 className="font-bold text-amber-300 mb-1 text-base">Bura / 31 Qoidalari</h3>
                <p>
                  O'yinchilarga 3 tadan karta beriladi va bitta Kozir ochiladi. Maqsad birinchi bo'lib 31 ball to'plash yoki maxsus kombinatsiyalarni ochish.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">Maxsus Instant Yutuqlar:</h4>
                <ul className="list-disc list-inside space-y-1.5 text-xs bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <li><strong className="text-amber-300">BURA:</strong> Qo'lingizdagi 3 ta karta ham Kozir bo'lsa — avtomatik 3x g'alaba!</li>
                  <li><strong className="text-amber-300">MOSKVA:</strong> Qo'lingizda 3 ta Tuz (A + A + A) bo'lsa — avtomatik 3x g'alaba!</li>
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'solitaire' && (
            <div className="space-y-4">
              <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
                <h3 className="font-bold text-amber-300 mb-1 text-base">Klondike Pas'yans Maqsadi</h3>
                <p>
                  Barcha 52 ta kartani 4 ta yuqori poydevor katagiga (Mastlar bo'yicha Tuzdan Qirolgacha: A, 2, 3... K) tartib bilan terib chiqish.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">Ustunlar Qoidasi</h4>
                <p>
                  Pastki 7 ta ustunda kartalarni <strong className="text-amber-300">kamayish tartibida</strong> va <strong className="text-amber-300">almashuvchi ranglar</strong> (qizil ustiga qora, qora ustiga qizil) bo'yicha taxlash mumkin.
                  Bo'shab qolgan ustunga faqat <strong className="text-slate-100">Qirol (K)</strong> qo'yilishi mumkin.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'spider' && (
            <div className="space-y-4">
              <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
                <h3 className="font-bold text-amber-300 mb-1 text-base">Pauk (Spider) Pas'yansi</h3>
                <p>
                  10 ta ustunda 104 ta karta joylashtiriladi. Maqsad bir xil mastdagi barcha 8 ta to'liq zanjirni (Qirol K dan Tuz A gacha: K, Q, J, 10... A) yig'ish.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">Qoidalar:</h4>
                <ul className="list-disc list-inside space-y-1 text-slate-300">
                  <li>Kartalarni kamayish tartibida har qanday ustunga qo'yish mumkin (masalan 7 ustiga 6).</li>
                  <li>Lekin zanjir bo'lib ko'chirish uchun kartalar bir xil mastda bo'lishi shart!</li>
                  <li>To'liq K dan A gacha yig'ilgan zanjir stoldan avtomatik olib tashlanadi.</li>
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'devyatka' && (
            <div className="space-y-4">
              <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60">
                <h3 className="font-bold text-amber-300 mb-1 text-base">To'qqizlik (Devyatka 9) Qoidalari</h3>
                <p>
                  Karta stoli 4 ta mast satridan iborat bo'lib, o'yin har bir mastning 9 raqami bilan boshlanadi.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">Yurishlar:</h4>
                <ul className="list-disc list-inside space-y-1.5 text-slate-300">
                  <li>Stolda 9 raqami ochilgach, uning yoniga o'sha mastdagi 10 (yuqoriga: 10, J, Q, K, A) yoki 8 (pastga: 8, 7, 6) qo'yish mumkin.</li>
                  <li>Yoki boshqa mastdagi yangi 9 raqamini qo'yib yangi satr ochish mumkin.</li>
                  <li>Agar o'yinchida yurish uchun mos karta bo'lmasa, "Pas" bosadi.</li>
                  <li>Qo'lidagi barcha 18 ta kartadan birinchi bo'lib qutulgan o'yinchi g'alaba qozonadi!</li>
                </ul>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/80 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-sm font-semibold rounded-lg bg-amber-500 text-slate-950 hover:bg-amber-400 transition-colors shadow-md"
          >
            Tushundim
          </button>
        </div>
      </div>
    </div>
  );
};
