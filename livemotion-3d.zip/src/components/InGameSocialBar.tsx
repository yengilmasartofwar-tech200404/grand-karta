import React, { useState, useEffect, useRef } from 'react';
import { EMOJI_LIST_150 } from './ThreeDCharacter';
import { sounds } from '../utils/audio';
import { 
  Mic, 
  MicOff, 
  MessageSquare, 
  Smile, 
  Send, 
  X, 
  Coffee, 
  Gift, 
  Sparkles, 
  Volume2, 
  VolumeX 
} from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: string;
  text: string;
  time: string;
  isSelf: boolean;
  emoji?: string;
}

interface InGameSocialBarProps {
  playerName: string;
  opponentName: string;
  onSendEmoji: (emoji: string) => void;
  onMicToggle: (isActive: boolean) => void;
  isMicActive: boolean;
}

const QUICK_PHRASES = [
  "Salom hammaga! 👋",
  "Yaxshi yurish! 👍",
  "Koziring bormi? 🤔",
  "Bita bo'ldi! 🔥",
  "Yutqazding, do'stim! 😎",
  "Yana bitta o'yin? 🔄",
  "Omad tilayman! ✨",
  "Rahmat! 🤝",
];

const GIFTS = [
  { icon: '☕', name: 'Qaynoq Kofe', cost: 50 },
  { icon: '💐', name: 'Chiroyli Gul', cost: 100 },
  { icon: '💎', name: 'Olmos', cost: 250 },
  { icon: '🍕', name: 'Pitsa', cost: 80 },
  { icon: '💣', name: 'Bomba', cost: 120 },
];

export const InGameSocialBar: React.FC<InGameSocialBarProps> = ({
  playerName,
  opponentName,
  onSendEmoji,
  onMicToggle,
  isMicActive,
}) => {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isEmojiPickerOpen, setIsEmojiPickerOpen] = useState(false);
  const [isGiftPickerOpen, setIsGiftPickerOpen] = useState(false);

  const [inputMessage, setInputMessage] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: opponentName,
      text: `Salom! Karta o'yiniga xush kelibsiz.`,
      time: '12:00',
      isSelf: false,
    },
  ]);

  const [activeCategory, setActiveCategory] = useState(0);
  const [voiceVolume, setVoiceVolume] = useState(0);
  const audioContextRef = useRef<AudioContext | null>(null);

  // Microphone Audio Capture Simulation & Waveform
  useEffect(() => {
    let animId: number;

    if (isMicActive) {
      // Simulate speech volume oscillations or real microphone
      const loop = () => {
        setVoiceVolume(Math.floor(Math.random() * 85) + 15);
        animId = requestAnimationFrame(loop);
      };
      animId = requestAnimationFrame(loop);
    } else {
      setVoiceVolume(0);
    }

    return () => cancelAnimationFrame(animId);
  }, [isMicActive]);

  const handleToggleMic = () => {
    sounds.playChip();
    const nextState = !isMicActive;
    onMicToggle(nextState);
  };

  const handleSendMessage = (textToSend = inputMessage) => {
    if (!textToSend.trim()) return;

    sounds.playChip();
    const newMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: playerName,
      text: textToSend.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isSelf: true,
    };

    setMessages((prev) => [...prev, newMsg]);
    setInputMessage('');

    // Opponent reply after a delay
    setTimeout(() => {
      const replies = [
        "Ajoyib!",
        "Xo'sh, ko'ramiz...",
        "Qiziq o'yin bo'lyapti!",
        "Navbat menda!",
        "Kozirni qayerga yashirdingiz? 😉",
      ];
      const botMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: opponentName,
        text: replies[Math.floor(Math.random() * replies.length)],
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isSelf: false,
      };
      setMessages((prev) => [...prev, botMsg]);
      sounds.playCardPlay();
    }, 1800);
  };

  const handlePickEmoji = (emoji: string) => {
    sounds.playCardPlay();
    onSendEmoji(emoji);

    const emojiMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: playerName,
      text: emoji,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isSelf: true,
      emoji,
    };
    setMessages((prev) => [...prev, emojiMsg]);
  };

  const handleSendGift = (gift: { icon: string; name: string; cost: number }) => {
    sounds.playWin();
    const giftMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: playerName,
      text: `Raqibga ${gift.name} ${gift.icon} yubordi!`,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isSelf: true,
    };
    setMessages((prev) => [...prev, giftMsg]);
    onSendEmoji(gift.icon);
    setIsGiftPickerOpen(false);
  };

  return (
    <div className="relative w-full z-20 flex items-center justify-between gap-2 px-2 py-1.5 bg-slate-950/80 rounded-2xl border border-slate-800 shadow-lg backdrop-blur-md">
      {/* Left: Microphone Toggle & Live Speaking Waveform */}
      <div className="flex items-center gap-2">
        <button
          onClick={handleToggleMic}
          className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all shadow-md ${
            isMicActive
              ? 'bg-emerald-500 text-slate-950 shadow-emerald-500/30 animate-pulse'
              : 'bg-slate-900 hover:bg-slate-850 text-slate-300 border border-slate-800'
          }`}
          title={isMicActive ? "Mikrofonni o'chirish" : 'Mikrofonni yoqish'}
        >
          {isMicActive ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
          <span>{isMicActive ? 'Mikrofon Yoqiq' : 'Mikrofon'}</span>
        </button>

        {/* Live Audio Visualizer Waves */}
        {isMicActive && (
          <div className="flex items-center gap-0.5 px-2 py-1 bg-slate-900 rounded-lg border border-emerald-500/30">
            {[20, 50, 80, 45, 90].map((h, i) => (
              <span
                key={i}
                style={{ height: `${Math.max(4, (voiceVolume * h) / 100)}px` }}
                className="w-1 bg-emerald-400 rounded-full transition-all duration-75"
              />
            ))}
          </div>
        )}
      </div>

      {/* Center: Quick Action Buttons (150 Emojilar, Chat, Sovg'a) */}
      <div className="flex items-center gap-1.5">
        {/* 150 Emojis Selector Button */}
        <button
          onClick={() => {
            sounds.playChip();
            setIsEmojiPickerOpen(!isEmojiPickerOpen);
            setIsChatOpen(false);
            setIsGiftPickerOpen(false);
          }}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition-all ${
            isEmojiPickerOpen
              ? 'bg-amber-500 text-slate-950 border-amber-400'
              : 'bg-slate-900 hover:bg-slate-850 text-slate-200 border-slate-800'
          }`}
        >
          <Smile className="w-4 h-4 text-amber-400" />
          <span>Smayliklar (150+)</span>
        </button>

        {/* Chat Drawer Button */}
        <button
          onClick={() => {
            sounds.playChip();
            setIsChatOpen(!isChatOpen);
            setIsEmojiPickerOpen(false);
            setIsGiftPickerOpen(false);
          }}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition-all ${
            isChatOpen
              ? 'bg-amber-500 text-slate-950 border-amber-400'
              : 'bg-slate-900 hover:bg-slate-850 text-slate-200 border-slate-800'
          }`}
        >
          <MessageSquare className="w-4 h-4 text-amber-400" />
          <span>Chat</span>
          {messages.length > 1 && (
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
          )}
        </button>

        {/* Send Gift Button */}
        <button
          onClick={() => {
            sounds.playChip();
            setIsGiftPickerOpen(!isGiftPickerOpen);
            setIsChatOpen(false);
            setIsEmojiPickerOpen(false);
          }}
          className={`px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 border transition-all ${
            isGiftPickerOpen
              ? 'bg-amber-500 text-slate-950 border-amber-400'
              : 'bg-slate-900 hover:bg-slate-850 text-slate-200 border-slate-800'
          }`}
          title="Raqibga sovg'a yuborish"
        >
          <Gift className="w-4 h-4 text-amber-400" />
          <span className="hidden sm:inline">Sovg'a</span>
        </button>
      </div>

      {/* POPUP 1: 150 EMOJIS PICKER (CATEGORIZED) */}
      {isEmojiPickerOpen && (
        <div className="absolute bottom-12 right-0 w-80 sm:w-96 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-3 z-30 flex flex-col space-y-2">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5 font-serif">
              <Smile className="w-4 h-4 text-amber-400" />
              150 ta Smaylik (3D Personaj Harakati)
            </span>
            <button onClick={() => setIsEmojiPickerOpen(false)} className="text-slate-400 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none">
            {EMOJI_LIST_150.map((cat, idx) => (
              <button
                key={idx}
                onClick={() => setActiveCategory(idx)}
                className={`px-2 py-1 text-[11px] font-semibold rounded-lg whitespace-nowrap transition-colors ${
                  activeCategory === idx
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {cat.category}
              </button>
            ))}
          </div>

          {/* Emoji Grid */}
          <div className="grid grid-cols-6 sm:grid-cols-7 gap-1.5 max-h-48 overflow-y-auto p-1 bg-slate-950/60 rounded-xl border border-slate-800">
            {EMOJI_LIST_150[activeCategory].emojis.map((emoji, i) => (
              <button
                key={i}
                onClick={() => handlePickEmoji(emoji)}
                className="w-10 h-10 rounded-xl text-xl flex items-center justify-center hover:bg-slate-800 hover:scale-125 active:scale-95 transition-transform"
              >
                {emoji}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* POPUP 2: CHAT DRAWER */}
      {isChatOpen && (
        <div className="absolute bottom-12 right-0 w-80 sm:w-96 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-3 z-30 flex flex-col space-y-2.5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5 font-serif">
              <MessageSquare className="w-4 h-4 text-amber-400" />
              Jonli O'yin Chati
            </span>
            <button onClick={() => setIsChatOpen(false)} className="text-slate-400 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Chat Messages */}
          <div className="h-44 overflow-y-auto space-y-1.5 p-2 bg-slate-950/60 rounded-xl border border-slate-800 text-xs">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex flex-col ${m.isSelf ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[80%] px-3 py-1.5 rounded-xl ${
                    m.isSelf
                      ? 'bg-amber-500 text-slate-950 font-medium rounded-br-none'
                      : 'bg-slate-800 text-slate-200 rounded-bl-none border border-slate-700'
                  }`}
                >
                  {m.emoji ? (
                    <span className="text-2xl">{m.emoji}</span>
                  ) : (
                    <span>{m.text}</span>
                  )}
                </div>
                <span className="text-[9px] text-slate-500 mt-0.5 font-mono">{m.sender} · {m.time}</span>
              </div>
            ))}
          </div>

          {/* Quick Phrases */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none">
            {QUICK_PHRASES.map((phrase, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(phrase)}
                className="px-2 py-1 text-[10px] font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg whitespace-nowrap border border-slate-700 shrink-0"
              >
                {phrase}
              </button>
            ))}
          </div>

          {/* Input Box */}
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Xabar yozing..."
              className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
            />
            <button
              onClick={() => handleSendMessage()}
              className="p-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition-colors shrink-0"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* POPUP 3: SEND GIFT PICKER */}
      {isGiftPickerOpen && (
        <div className="absolute bottom-12 right-0 w-72 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-3 z-30 flex flex-col space-y-2">
          <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
            <span className="text-xs font-bold text-slate-200 flex items-center gap-1 font-serif">
              <Gift className="w-4 h-4 text-amber-400" />
              Raqibga Sovg'a Yuborish
            </span>
            <button onClick={() => setIsGiftPickerOpen(false)} className="text-slate-400 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {GIFTS.map((g, i) => (
              <button
                key={i}
                onClick={() => handleSendGift(g)}
                className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 hover:border-amber-400 flex flex-col items-center gap-1 transition-all hover:scale-105"
              >
                <span className="text-2xl">{g.icon}</span>
                <span className="text-[11px] font-bold text-slate-200">{g.name}</span>
                <span className="text-[10px] font-mono text-amber-400 font-semibold">{g.cost} tanga</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
