import React, { useState } from 'react';
import { GameMode } from '../types/cards';
import { Sparkles, Users, Play, Star, Flame, Trophy } from 'lucide-react';
import { sounds } from '../utils/audio';

export interface CatalogGameItem {
  id: string;
  mode: GameMode;
  variant?: string;
  title: string;
  subtitle: string;
  rating: number;
  playersOnline: number;
  category: 'popular' | 'solitaire' | 'duel';
  badgeAge: string;
  gradient: string;
  cardSymbols: string[];
  isHot?: boolean;
}

const CATALOG_GAMES: CatalogGameItem[] = [
  {
    id: 'ming_1000',
    mode: 'ming',
    variant: 'classic',
    title: '1000 (Тысяча / Ming)',
    subtitle: 'Marjlar (+100) · 120 ochko · Savdo va Bo‘chka',
    rating: 96,
    playersOnline: 3450,
    category: 'popular',
    badgeAge: '16+',
    gradient: 'from-amber-900 via-rose-950 to-slate-900',
    cardSymbols: ['♥', 'A', 'K'],
    isHot: true,
  },
  {
    id: 'durak_podkidnoy',
    mode: 'durak',
    variant: 'podkidnoy',
    title: 'Дурак Подкидной',
    subtitle: 'Klassik Ahmoq · 36 karta va Kozir',
    rating: 86,
    playersOnline: 1420,
    category: 'popular',
    badgeAge: '16+',
    gradient: 'from-emerald-900 via-teal-950 to-slate-900',
    cardSymbols: ['♠', '♥', '♦'],
    isHot: true,
  },
  {
    id: 'ochko_21',
    mode: 'ochko',
    variant: 'classic',
    title: '21 Очко / Блек Джек',
    subtitle: 'Oltin Ochko 3x · Tangalar garovi',
    rating: 91,
    playersOnline: 2180,
    category: 'popular',
    badgeAge: '18+',
    gradient: 'from-amber-950 via-slate-900 to-emerald-950',
    cardSymbols: ['A', '10', 'J'],
    isHot: true,
  },
  {
    id: 'solitaire_kosynka',
    mode: 'solitaire',
    variant: 'klondike',
    title: 'Пасьянс Косынка',
    subtitle: 'Klondike · 7 ustun va 4 poydevor',
    rating: 88,
    playersOnline: 940,
    category: 'solitaire',
    badgeAge: '12+',
    gradient: 'from-blue-950 via-indigo-950 to-slate-900',
    cardSymbols: ['K', 'Q', 'J'],
  },
  {
    id: 'durak_perevodnoy',
    mode: 'durak',
    variant: 'perevodnoy',
    title: 'Дурак Переводной',
    subtitle: "Kartani keyingi raqibga o'tkazish",
    rating: 83,
    playersOnline: 810,
    category: 'duel',
    badgeAge: '16+',
    gradient: 'from-purple-950 via-slate-900 to-indigo-950',
    cardSymbols: ['♣', '♠', '♥'],
  },
  {
    id: 'pauk_spider',
    mode: 'solitaire',
    variant: 'spider',
    title: 'Пасьянс Паук (Spider)',
    subtitle: "O'rgimchak pas'yansi · 1 va 2 mast",
    rating: 89,
    playersOnline: 620,
    category: 'solitaire',
    badgeAge: '12+',
    gradient: 'from-emerald-950 via-green-900 to-slate-950',
    cardSymbols: ['🕷️', '♠', '♠'],
  },
  {
    id: 'bura_31',
    mode: 'ochko',
    variant: 'bura',
    title: 'Бура / 31 (Ochko)',
    subtitle: '3 ta karta bilan 31 ball olish',
    rating: 79,
    playersOnline: 530,
    category: 'duel',
    badgeAge: '18+',
    gradient: 'from-red-950 via-amber-950 to-slate-900',
    cardSymbols: ['♦', 'A', 'K'],
  },
  {
    id: 'seka_cards',
    mode: 'ochko',
    variant: 'seka',
    title: 'Карты СЕКА',
    subtitle: 'Alovli karta dueli · Katta bank',
    rating: 82,
    playersOnline: 740,
    category: 'popular',
    badgeAge: '18+',
    gradient: 'from-amber-900 via-yellow-950 to-slate-950',
    cardSymbols: ['🔥', 'A', 'A'],
    isHot: true,
  },
  {
    id: 'devyatka_9',
    mode: 'durak',
    variant: 'devyatka',
    title: 'Карты Девятка (9)',
    subtitle: "To'qqizlik strategiya o'yini",
    rating: 76,
    playersOnline: 410,
    category: 'duel',
    badgeAge: '16+',
    gradient: 'from-slate-900 via-teal-950 to-emerald-950',
    cardSymbols: ['9', '9', '9'],
  },
];

interface GameCatalogProps {
  onSelectGame: (mode: GameMode, variant?: string) => void;
  onOpenFriends: () => void;
  onOpenLeaderboard: () => void;
  onOpenLevelRoadmap: () => void;
  onOpenLuckyWheel: () => void;
  level?: number;
  spinTickets?: number;
}

export const GameCatalog: React.FC<GameCatalogProps> = ({
  onSelectGame,
  onOpenFriends,
  onOpenLeaderboard,
  onOpenLevelRoadmap,
  onOpenLuckyWheel,
  level = 1,
  spinTickets = 3,
}) => {
  const [filter, setFilter] = useState<'all' | 'popular' | 'solitaire' | 'duel'>('all');

  const filteredGames = CATALOG_GAMES.filter((g) => {
    if (filter === 'all') return true;
    return g.category === filter;
  });

  return (
    <div className="w-full space-y-6">
      {/* Prominent Center Action Grid: 100 LVL, Omad G'ildiragi, Do'stlar & Reyting */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Omad G'ildiragi Card */}
        <div
          onClick={() => {
            sounds.playChip();
            onOpenLuckyWheel();
          }}
          className="group relative cursor-pointer overflow-hidden rounded-2xl bg-gradient-to-r from-purple-600 via-pink-600 to-amber-500 p-0.5 shadow-xl transition-all duration-300 hover:scale-[1.02] hover:shadow-purple-500/25"
        >
          <div className="flex h-full flex-col justify-between rounded-[14px] bg-slate-950/90 p-4 backdrop-blur-md transition-all group-hover:bg-slate-950/80">
            <div>
              <div className="flex items-center justify-between text-xs font-bold text-amber-400 mb-1">
                <span className="flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  OMAD G'ILDIRAGI
                </span>
                <span className="px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-mono border border-amber-500/40">
                  {spinTickets} Bilet
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-black font-serif text-slate-100 leading-tight">
                Kunlik Lucky Spin
              </h3>
              <p className="text-[11px] text-slate-300 mt-1 line-clamp-2">
                10 ta tanga yutug'i, 3D aksessuarlar va 3 kunlik VIP yutib oling!
              </p>
            </div>
            <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-800/80">
              <span className="text-[11px] text-emerald-400 font-bold font-mono">
                Aylantirish →
              </span>
              <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 font-black flex items-center justify-center shadow group-hover:rotate-45 transition-transform">
                🎡
              </div>
            </div>
          </div>
        </div>

        {/* 100 LVL Chempionlik Yo'li Card */}
        <div
          onClick={() => {
            sounds.playChip();
            onOpenLevelRoadmap();
          }}
          className="group relative cursor-pointer overflow-hidden rounded-2xl bg-gradient-to-r from-amber-600 via-yellow-500 to-emerald-500 p-0.5 shadow-xl transition-all duration-300 hover:scale-[1.02] hover:shadow-amber-500/25"
        >
          <div className="flex h-full flex-col justify-between rounded-[14px] bg-slate-950/90 p-4 backdrop-blur-md transition-all group-hover:bg-slate-950/80">
            <div>
              <div className="flex items-center justify-between text-xs font-bold text-amber-400 mb-1">
                <span className="flex items-center gap-1">
                  <Star className="w-3.5 h-3.5 fill-amber-400" />
                  100 TA LVL
                </span>
                <span className="px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-mono border border-emerald-500/40 font-bold">
                  LVL {level}
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-black font-serif text-slate-100 leading-tight">
                Chempionlik Yo'li
              </h3>
              <p className="text-[11px] text-slate-300 mt-1 line-clamp-2">
                1 dan 100 gacha har bir daraja uchun tangalar, VIP va 3D sovg'alar!
              </p>
            </div>
            <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-800/80">
              <span className="text-[11px] text-amber-300 font-bold font-mono">
                Bosqichlarni Ko'rish →
              </span>
              <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 font-black flex items-center justify-center shadow group-hover:scale-110 transition-transform font-mono">
                ★
              </div>
            </div>
          </div>
        </div>

        {/* Play with Friends card */}
        <div
          onClick={() => {
            sounds.playChip();
            onOpenFriends();
          }}
          className="group relative cursor-pointer overflow-hidden rounded-2xl bg-gradient-to-r from-blue-600 via-indigo-500 to-cyan-500 p-0.5 shadow-xl transition-all duration-300 hover:scale-[1.02] hover:shadow-blue-500/25"
        >
          <div className="flex h-full flex-col justify-between rounded-[14px] bg-slate-950/90 p-4 backdrop-blur-md transition-all group-hover:bg-slate-950/80">
            <div>
              <div className="flex items-center gap-1.5 text-xs font-bold text-blue-400 mb-1">
                <Users className="w-3.5 h-3.5" />
                <span>MULTIPLAYER</span>
              </div>
              <h3 className="text-base sm:text-lg font-black font-serif text-slate-100 leading-tight">
                Do'stlar Bilan
              </h3>
              <p className="text-[11px] text-slate-300 mt-1 line-clamp-2">
                Xona yarating, kod yuboring yoki bitta ekranda duel qiling!
              </p>
            </div>
            <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-800/80">
              <span className="text-[11px] text-cyan-300 font-bold font-mono">
                Xonaga Kirish →
              </span>
              <div className="w-8 h-8 rounded-lg bg-blue-500 text-slate-950 font-black flex items-center justify-center shadow group-hover:scale-110 transition-transform">
                <Play className="w-4 h-4 fill-slate-950 ml-0.5" />
              </div>
            </div>
          </div>
        </div>

        {/* Global Leaderboard card */}
        <div
          onClick={() => {
            sounds.playChip();
            onOpenLeaderboard();
          }}
          className="group relative cursor-pointer overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-500 to-cyan-500 p-0.5 shadow-xl transition-all duration-300 hover:scale-[1.02] hover:shadow-emerald-500/25"
        >
          <div className="flex h-full flex-col justify-between rounded-[14px] bg-slate-950/90 p-4 backdrop-blur-md transition-all group-hover:bg-slate-950/80">
            <div>
              <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 mb-1">
                <Trophy className="w-3.5 h-3.5" />
                <span>TOP REYTING</span>
              </div>
              <h3 className="text-base sm:text-lg font-black font-serif text-slate-100 leading-tight">
                Klub Ligasi
              </h3>
              <p className="text-[11px] text-slate-300 mt-1 line-clamp-2">
                Eng boy ustalar, yutuqlar va haftalik mukofotlar jadvali.
              </p>
            </div>
            <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-800/80">
              <span className="text-[11px] text-emerald-300 font-bold font-mono">
                Reytingni Ko'rish →
              </span>
              <div className="w-8 h-8 rounded-lg bg-emerald-500 text-slate-950 font-black flex items-center justify-center shadow group-hover:scale-110 transition-transform">
                <Trophy className="w-4 h-4 text-slate-950" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center justify-between flex-wrap gap-2 pt-2 border-b border-slate-900 pb-3">
        <div className="flex items-center gap-1.5 p-1 bg-slate-900/80 rounded-xl border border-slate-800">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              filter === 'all'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Barcha O'yinlar
          </button>
          <button
            onClick={() => setFilter('popular')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              filter === 'popular'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Mashhur
          </button>
          <button
            onClick={() => setFilter('solitaire')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              filter === 'solitaire'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Pas'yanslar
          </button>
          <button
            onClick={() => setFilter('duel')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              filter === 'duel'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Duellar
          </button>
        </div>

        <div className="text-xs text-slate-400 font-mono">
          {filteredGames.length} ta o'yin mavjud
        </div>
      </div>

      {/* Catalog Grid (Matching the screenshots!) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
        {filteredGames.map((game) => (
          <div
            key={game.id}
            onClick={() => {
              sounds.playCardPlay();
              onSelectGame(game.mode, game.variant);
            }}
            className="group relative cursor-pointer rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-500/60 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-amber-500/10 flex flex-col justify-between overflow-hidden"
          >
            {/* Visual Header / 3D Card banner */}
            <div className={`h-32 sm:h-40 w-full bg-gradient-to-br ${game.gradient} p-3 flex flex-col justify-between relative overflow-hidden group-hover:brightness-110 transition-all`}>
              {/* Radial lighting spotlight */}
              <div className="absolute inset-0 bg-radial from-white/10 via-transparent to-transparent pointer-events-none" />

              {/* 3D Realistic Fan of Mini Cards inside banner */}
              <div className="absolute -right-3 -bottom-2 flex items-center pointer-events-none select-none transition-transform duration-300 group-hover:scale-110 group-hover:-translate-y-1">
                {game.cardSymbols.map((sym, i) => (
                  <div
                    key={i}
                    style={{
                      transform: `rotate(${(i - 1) * 16}deg) translateY(${Math.abs(i - 1) * 6}px)`,
                      marginLeft: i > 0 ? '-18px' : '0',
                    }}
                    className="w-11 h-16 sm:w-13 sm:h-18 rounded-md bg-white border border-slate-300 shadow-xl flex flex-col items-center justify-between p-1 text-[11px] font-bold text-slate-900"
                  >
                    <span className={sym === '♥' || sym === '♦' || sym === '🔥' ? 'text-red-600' : 'text-slate-900'}>
                      {sym}
                    </span>
                    <span className="text-sm">{sym}</span>
                    <span className="text-[9px] rotate-180 opacity-50">{sym}</span>
                  </div>
                ))}
              </div>

              {/* Top rating and age badges */}
              <div className="flex items-center justify-between z-10">
                {/* Rating score badge (green badge) */}
                <div className="flex items-center gap-1 bg-emerald-600/95 text-white text-[11px] font-bold px-2 py-0.5 rounded-lg shadow-md border border-emerald-400/30">
                  <Star className="w-3 h-3 fill-white" />
                  <span>{game.rating}</span>
                </div>

                {/* Age tag */}
                <span className="text-[10px] font-mono font-bold bg-black/60 text-slate-200 px-1.5 py-0.5 rounded border border-white/20">
                  {game.badgeAge}
                </span>
              </div>

              {/* Hot tag */}
              {game.isHot && (
                <div className="z-10 self-start inline-flex items-center gap-1 bg-gradient-to-r from-red-600 to-amber-600 text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full shadow-md animate-pulse">
                  <Flame className="w-3 h-3" />
                  3D HIT O'YIN
                </div>
              )}

              {/* Game Title on card */}
              <div className="z-10 mt-auto">
                <h3 className="text-sm sm:text-base font-black font-serif text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] tracking-tight leading-tight">
                  {game.title}
                </h3>
              </div>
            </div>

            {/* Bottom info strip */}
            <div className="p-3 bg-slate-950/70 flex items-center justify-between gap-2 border-t border-slate-800/80">
              <div className="truncate">
                <p className="text-[11px] text-slate-400 truncate">
                  {game.subtitle}
                </p>
                <span className="text-[10px] text-emerald-400 font-mono">
                  {game.playersOnline.toLocaleString()} o'yinchi
                </span>
              </div>

              <div className="w-8 h-8 rounded-lg bg-amber-500 group-hover:bg-amber-400 text-slate-950 flex items-center justify-center shrink-0 shadow-md transition-colors">
                <Play className="w-4 h-4 fill-slate-950 ml-0.5" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
