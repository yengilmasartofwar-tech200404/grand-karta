import React, { useState, useEffect, useCallback } from 'react';
import { Card, Suit } from '../../types/cards';
import { createStandardDeck, getSuitInfo } from '../../utils/cardUtils';
import { PlayingCard } from '../PlayingCard';
import { sounds } from '../../utils/audio';
import confetti from 'canvas-confetti';
import { RotateCcw, Undo2, Lightbulb, Trophy, Sparkles, Layers } from 'lucide-react';

interface SolitaireGameProps {
  onWin: (reward: number) => void;
  variant?: string; // 'klondike' | 'spider'
  tableTheme?: string;
  cardBackTheme?: string;
  onExit?: () => void;
}

interface SolitaireState {
  stock: Card[];
  waste: Card[];
  foundations: { [key in Suit]: Card[] };
  columns: Card[][];
  moves: number;
}

export const SolitaireGame: React.FC<SolitaireGameProps> = ({
  onWin,
  variant = 'klondike',
  tableTheme = 'green',
  cardBackTheme = 'royal_blue',
  onExit,
}) => {
  const [activeGameType, setActiveGameType] = useState<'klondike' | 'spider'>(
    variant === 'spider' ? 'spider' : 'klondike'
  );

  // Klondike state
  const [stock, setStock] = useState<Card[]>([]);
  const [waste, setWaste] = useState<Card[]>([]);
  const [foundations, setFoundations] = useState<{ [key in Suit]: Card[] }>({
    spades: [],
    hearts: [],
    diamonds: [],
    clubs: [],
  });
  const [columns, setColumns] = useState<Card[][]>([[], [], [], [], [], [], []]);
  const [moves, setMoves] = useState<number>(0);
  const [history, setHistory] = useState<SolitaireState[]>([]);
  const [gameWon, setGameWon] = useState<boolean>(false);

  // Spider state
  const [spiderColumns, setSpiderColumns] = useState<Card[][]>(Array.from({ length: 10 }, () => []));
  const [spiderStock, setSpiderStock] = useState<Card[]>([]);
  const [spiderCompletedRuns, setSpiderCompletedRuns] = useState<number>(0);
  const [spiderSuitsMode, setSpiderSuitsMode] = useState<1 | 2 | 4>(1);

  // Initialize Klondike
  const startNewKlondike = useCallback(() => {
    const deck = createStandardDeck();
    const cols: Card[][] = [[], [], [], [], [], [], []];

    let cardIdx = 0;
    for (let c = 0; c < 7; c++) {
      for (let r = 0; r <= c; r++) {
        const card = deck[cardIdx++];
        card.faceUp = r === c;
        cols[c].push(card);
      }
    }

    const remainingStock = deck.slice(cardIdx).map((c) => ({ ...c, faceUp: false }));
    setStock(remainingStock);
    setWaste([]);
    setFoundations({ spades: [], hearts: [], diamonds: [], clubs: [] });
    setColumns(cols);
    setMoves(0);
    setHistory([]);
    setGameWon(false);
    sounds.playCardDeal();
  }, []);

  // Initialize Spider
  const startNewSpider = useCallback((suitCount: 1 | 2 | 4 = spiderSuitsMode) => {
    // Spider uses 104 cards (2 decks)
    const deck1 = createStandardDeck();
    const deck2 = createStandardDeck();
    let full104: Card[] = [];

    if (suitCount === 1) {
      // 8 copies of spades
      for (let s = 0; s < 8; s++) {
        full104.push(...createStandardDeck().filter(c => c.suit === 'spades').map((c, i) => ({ ...c, id: `sp-${s}-${i}` })));
      }
    } else if (suitCount === 2) {
      // 4 copies of spades, 4 copies of hearts
      for (let s = 0; s < 4; s++) {
        full104.push(...createStandardDeck().filter(c => c.suit === 'spades' || c.suit === 'hearts').map((c, i) => ({ ...c, id: `s2-${s}-${i}` })));
      }
    } else {
      full104 = [...deck1, ...deck2.map((c, i) => ({ ...c, id: `${c.id}-2` }))];
    }

    // Shuffle
    for (let i = full104.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [full104[i], full104[j]] = [full104[j], full104[i]];
    }

    // Deal 54 cards into 10 columns (first 4 get 6 cards, last 6 get 5 cards)
    const cols: Card[][] = Array.from({ length: 10 }, () => []);
    let cIdx = 0;
    for (let c = 0; c < 10; c++) {
      const count = c < 4 ? 6 : 5;
      for (let r = 0; r < count; r++) {
        const card = full104[cIdx++];
        card.faceUp = r === count - 1; // only top face up
        cols[c].push(card);
      }
    }

    const remaining = full104.slice(cIdx).map(c => ({ ...c, faceUp: false }));
    setSpiderColumns(cols);
    setSpiderStock(remaining);
    setSpiderCompletedRuns(0);
    setMoves(0);
    setGameWon(false);
    sounds.playCardDeal();
  }, [spiderSuitsMode]);

  useEffect(() => {
    if (activeGameType === 'klondike') {
      startNewKlondike();
    } else {
      startNewSpider();
    }
  }, [activeGameType, startNewKlondike, startNewSpider]);

  // Klondike save for undo
  const saveStateForUndo = () => {
    setHistory((prev) => [
      ...prev.slice(-15),
      {
        stock: JSON.parse(JSON.stringify(stock)),
        waste: JSON.parse(JSON.stringify(waste)),
        foundations: JSON.parse(JSON.stringify(foundations)),
        columns: JSON.parse(JSON.stringify(columns)),
        moves,
      },
    ]);
  };

  const handleUndo = () => {
    if (history.length === 0) return;
    const last = history[history.length - 1];
    setHistory((prev) => prev.slice(0, -1));
    setStock(last.stock);
    setWaste(last.waste);
    setFoundations(last.foundations);
    setColumns(last.columns);
    setMoves(last.moves);
    sounds.playCardPlay();
  };

  // Klondike Stock click
  const handleStockClick = () => {
    saveStateForUndo();
    if (stock.length > 0) {
      sounds.playCardPlay();
      const newStock = [...stock];
      const card = newStock.pop()!;
      card.faceUp = true;
      setStock(newStock);
      setWaste((prev) => [...prev, card]);
      setMoves((m) => m + 1);
    } else if (waste.length > 0) {
      sounds.playCardDeal();
      const newStock = [...waste].reverse().map((c) => ({ ...c, faceUp: false }));
      setStock(newStock);
      setWaste([]);
      setMoves((m) => m + 1);
    }
  };

  // Klondike move validation
  const canMoveToFoundation = (card: Card, foundationCards: Card[]): boolean => {
    if (foundationCards.length === 0) return card.rank === 'A';
    const top = foundationCards[foundationCards.length - 1];
    return card.suit === top.suit && card.value === top.value + 1;
  };

  const canMoveToColumn = (movingCard: Card, targetCol: Card[]): boolean => {
    if (targetCol.length === 0) return movingCard.rank === 'K';
    const top = targetCol[targetCol.length - 1];
    if (!top.faceUp) return false;
    const isMovingRed = getSuitInfo(movingCard.suit).isRed;
    const isTargetRed = getSuitInfo(top.suit).isRed;
    return isMovingRed !== isTargetRed && movingCard.value === top.value - 1;
  };

  // Klondike Win check
  useEffect(() => {
    if (activeGameType !== 'klondike') return;
    const total =
      foundations.spades.length +
      foundations.hearts.length +
      foundations.diamonds.length +
      foundations.clubs.length;
    if (total === 52 && !gameWon) {
      setGameWon(true);
      sounds.playWin();
      confetti({ particleCount: 150, spread: 90 });
      onWin(300);
    }
  }, [foundations, gameWon, onWin, activeGameType]);

  // Klondike Auto Move on Click
  const handleSmartClick = (card: Card, source: 'waste' | 'column', colIdx?: number, cardIdx?: number) => {
    if (!card.faceUp) return;

    // 1. Try to move to foundation
    const suit = card.suit;
    if (canMoveToFoundation(card, foundations[suit])) {
      saveStateForUndo();
      sounds.playCardPlay();
      if (source === 'waste') {
        setWaste((prev) => prev.slice(0, -1));
      } else if (source === 'column' && colIdx !== undefined) {
        setColumns((prev) => {
          const updated = [...prev];
          updated[colIdx] = updated[colIdx].slice(0, -1);
          if (updated[colIdx].length > 0) {
            updated[colIdx][updated[colIdx].length - 1].faceUp = true;
          }
          return updated;
        });
      }
      setFoundations((prev) => ({
        ...prev,
        [suit]: [...prev[suit], card],
      }));
      setMoves((m) => m + 1);
      return;
    }

    // 2. Try to move to another column
    for (let c = 0; c < 7; c++) {
      if (source === 'column' && colIdx === c) continue;
      const targetCol = columns[c];
      if (canMoveToColumn(card, targetCol)) {
        saveStateForUndo();
        sounds.playCardPlay();
        let movingCards: Card[] = [];
        if (source === 'waste') {
          movingCards = [card];
          setWaste((prev) => prev.slice(0, -1));
        } else if (source === 'column' && colIdx !== undefined && cardIdx !== undefined) {
          movingCards = columns[colIdx].slice(cardIdx);
          setColumns((prev) => {
            const updated = [...prev];
            updated[colIdx] = updated[colIdx].slice(0, cardIdx);
            if (updated[colIdx].length > 0) {
              updated[colIdx][updated[colIdx].length - 1].faceUp = true;
            }
            return updated;
          });
        }
        setColumns((prev) => {
          const updated = [...prev];
          updated[c] = [...updated[c], ...movingCards];
          return updated;
        });
        setMoves((m) => m + 1);
        return;
      }
    }
  };

  // Spider Deal 10 cards (1 to each column)
  const handleSpiderDealStock = () => {
    if (spiderStock.length < 10) return;
    sounds.playCardDeal();
    const newStock = [...spiderStock];
    const newCols = spiderColumns.map(col => [...col]);

    for (let c = 0; c < 10; c++) {
      const card = newStock.pop()!;
      card.faceUp = true;
      newCols[c].push(card);
    }

    setSpiderStock(newStock);
    setSpiderColumns(newCols);
    setMoves(m => m + 1);
    checkSpiderFullRuns(newCols);
  };

  // Spider check completed K..A runs
  const checkSpiderFullRuns = (cols: Card[][]) => {
    let completed = 0;
    const updatedCols = cols.map(col => {
      if (col.length < 13) return col;
      // Check last 13 cards for K down to A of same suit
      const last13 = col.slice(-13);
      if (last13.every(c => c.faceUp)) {
        const suit = last13[0].suit;
        const isRun = last13.every((c, idx) => c.suit === suit && c.value === 13 - idx);
        if (isRun) {
          completed += 1;
          sounds.playWin();
          confetti({ particleCount: 70, spread: 60 });
          const remaining = col.slice(0, -13);
          if (remaining.length > 0) remaining[remaining.length - 1].faceUp = true;
          return remaining;
        }
      }
      return col;
    });

    if (completed > 0) {
      setSpiderCompletedRuns(prev => {
        const next = prev + completed;
        if (next >= 8) {
          setGameWon(true);
          sounds.playWin();
          confetti({ particleCount: 180, spread: 100 });
          onWin(500);
        }
        return next;
      });
      setSpiderColumns(updatedCols);
    }
  };

  // Spider move card
  const handleSpiderCardClick = (colIdx: number, cardIdx: number) => {
    const col = spiderColumns[colIdx];
    const card = col[cardIdx];
    if (!card.faceUp) return;

    // Check if moving sequence is valid (must be strictly descending in value)
    const moving = col.slice(cardIdx);
    for (let i = 0; i < moving.length - 1; i++) {
      if (moving[i].value !== moving[i + 1].value + 1) return;
    }

    // Try to find target column (where top card is moving[0].value + 1)
    for (let targetIdx = 0; targetIdx < 10; targetIdx++) {
      if (targetIdx === colIdx) continue;
      const targetCol = spiderColumns[targetIdx];
      const targetTop = targetCol[targetCol.length - 1];

      // Empty column takes any card, or matching descending value
      if (!targetTop || targetTop.value === moving[0].value + 1) {
        sounds.playCardPlay();
        const nextCols = spiderColumns.map(c => [...c]);
        nextCols[colIdx] = nextCols[colIdx].slice(0, cardIdx);
        if (nextCols[colIdx].length > 0) {
          nextCols[colIdx][nextCols[colIdx].length - 1].faceUp = true;
        }
        nextCols[targetIdx] = [...nextCols[targetIdx], ...moving];
        setSpiderColumns(nextCols);
        setMoves(m => m + 1);
        checkSpiderFullRuns(nextCols);
        return;
      }
    }
  };

  // Dynamic table felt gradient
  const tableFeltClass =
    tableTheme === 'navy'
      ? 'from-blue-950 via-indigo-950 to-slate-950 border-indigo-900/40'
      : tableTheme === 'ruby'
      ? 'from-red-950 via-rose-950 to-slate-950 border-rose-900/40'
      : tableTheme === 'black'
      ? 'from-slate-950 via-zinc-900 to-black border-zinc-800'
      : 'from-emerald-950 via-emerald-900 to-slate-950 border-amber-900/40';

  return (
    <div className="w-full flex flex-col items-center select-none py-2 px-2 sm:px-6 max-w-6xl mx-auto animate-fade-in">
      <div className={`w-full rounded-2xl bg-gradient-to-b ${tableFeltClass} border-4 shadow-2xl p-4 sm:p-6 relative flex flex-col min-h-[620px] justify-between overflow-hidden`}>
        <div className="absolute inset-0 bg-[radial-gradient(#ffffff0a_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />

        {/* Top Control Bar: Mode Switcher & Undo */}
        <div className="relative z-10 flex items-center justify-between border-b border-white/10 pb-3 flex-wrap gap-2">
          {/* Switcher: Klondike vs Spider */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-950/70 rounded-xl border border-slate-800">
            <button
              onClick={() => {
                setActiveGameType('klondike');
                sounds.playChip();
              }}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                activeGameType === 'klondike'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Klondike Pas'yans
            </button>
            <button
              onClick={() => {
                setActiveGameType('spider');
                sounds.playChip();
              }}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                activeGameType === 'spider'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Pauk (Spider) Pas'yans
            </button>
          </div>

          {/* Spider Difficulty / Suits */}
          {activeGameType === 'spider' && (
            <div className="flex items-center gap-1 text-xs text-slate-300 bg-slate-950/60 px-2 py-1 rounded-xl border border-slate-800">
              <span className="text-[11px] text-slate-400 mr-1">Mast:</span>
              <button
                onClick={() => {
                  setSpiderSuitsMode(1);
                  startNewSpider(1);
                }}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${spiderSuitsMode === 1 ? 'bg-amber-500 text-slate-950' : 'text-slate-400'}`}
              >
                1 (Oson)
              </button>
              <button
                onClick={() => {
                  setSpiderSuitsMode(2);
                  startNewSpider(2);
                }}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${spiderSuitsMode === 2 ? 'bg-amber-500 text-slate-950' : 'text-slate-400'}`}
              >
                2 (O'rtacha)
              </button>
              <button
                onClick={() => {
                  setSpiderSuitsMode(4);
                  startNewSpider(4);
                }}
                className={`px-2 py-0.5 rounded text-[11px] font-bold ${spiderSuitsMode === 4 ? 'bg-amber-500 text-slate-950' : 'text-slate-400'}`}
              >
                4 (Qiyin)
              </button>
            </div>
          )}

          {/* Action buttons */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-emerald-300">Yurishlar: {moves}</span>
            {activeGameType === 'klondike' && (
              <button
                onClick={handleUndo}
                disabled={history.length === 0}
                className={`p-2 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors ${
                  history.length > 0
                    ? 'bg-slate-900/80 text-amber-300 border border-slate-700 hover:bg-slate-800'
                    : 'bg-slate-900/40 text-slate-600 border border-slate-800 cursor-not-allowed'
                }`}
                title="Ortga qaytarish"
              >
                <Undo2 className="w-4 h-4" />
                <span className="hidden sm:inline">Ortga</span>
              </button>
            )}
            <button
              onClick={() => (activeGameType === 'klondike' ? startNewKlondike() : startNewSpider())}
              className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-200 transition-colors border border-slate-700 flex items-center gap-1 text-xs"
              title="Yangi o'yin"
            >
              <RotateCcw className="w-4 h-4" />
              <span className="hidden sm:inline">Yangi</span>
            </button>
            {onExit && (
              <button
                onClick={onExit}
                className="px-2.5 py-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-xs font-semibold text-slate-300 border border-slate-700 transition-colors"
              >
                Chiqish
              </button>
            )}
          </div>
        </div>

        {/* KLONDIKE ARENA */}
        {activeGameType === 'klondike' ? (
          <>
            {/* Top Field: Stock + Waste (Left) and Foundations (Right) */}
            <div className="relative z-10 flex items-center justify-between my-4 gap-4">
              <div className="flex items-center gap-3">
                <div
                  onClick={handleStockClick}
                  className="w-14 h-20 sm:w-18 sm:h-26 rounded-lg border-2 border-emerald-700/60 bg-emerald-950/60 flex items-center justify-center cursor-pointer hover:border-amber-400 transition-all shadow-md relative"
                >
                  {stock.length > 0 ? (
                    <PlayingCard card={stock[stock.length - 1]} faceUp={false} size="sm" cardBackTheme={cardBackTheme} />
                  ) : (
                    <div className="text-emerald-400/50 text-xs font-serif text-center">
                      <RotateCcw className="w-5 h-5 mx-auto mb-0.5" />
                      Qayta
                    </div>
                  )}
                  {stock.length > 0 && (
                    <div className="absolute -bottom-2 -right-2 bg-slate-950 text-amber-300 text-[10px] font-mono px-1 rounded border border-slate-700">
                      {stock.length}
                    </div>
                  )}
                </div>

                <div className="w-14 h-20 sm:w-18 sm:h-26 rounded-lg border-2 border-dashed border-white/20 flex items-center justify-center relative">
                  {waste.length > 0 && (
                    <PlayingCard
                      card={waste[waste.length - 1]}
                      faceUp={true}
                      size="sm"
                      cardBackTheme={cardBackTheme}
                      onClick={() => handleSmartClick(waste[waste.length - 1], 'waste')}
                    />
                  )}
                </div>
              </div>

              <div className="hidden lg:flex items-center gap-1.5 text-xs text-emerald-300/70 italic">
                <Lightbulb className="w-4 h-4 text-amber-400 shrink-0" />
                Kartani bosing — u avtomatik ravishda mos poydevorga yoki ustunga ko'chadi.
              </div>

              {/* 4 Foundations */}
              <div className="flex items-center gap-2">
                {(['spades', 'hearts', 'diamonds', 'clubs'] as Suit[]).map((suit) => {
                  const pile = foundations[suit];
                  const top = pile.length > 0 ? pile[pile.length - 1] : null;
                  const suitInfo = getSuitInfo(suit);
                  return (
                    <div
                      key={suit}
                      className="w-14 h-20 sm:w-18 sm:h-26 rounded-lg border-2 border-dashed border-white/20 bg-black/20 flex items-center justify-center relative shadow-inner"
                    >
                      {top ? (
                        <PlayingCard card={top} faceUp={true} size="sm" cardBackTheme={cardBackTheme} />
                      ) : (
                        <span
                          className={`text-xl opacity-40 font-serif ${
                            suitInfo.isRed ? 'text-red-400' : 'text-slate-300'
                          }`}
                        >
                          {suitInfo.symbol}
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 7 Tableau Columns */}
            <div className="relative z-10 grid grid-cols-7 gap-1.5 sm:gap-3 flex-1 min-h-[360px] pt-2">
              {columns.map((col, colIdx) => (
                <div
                  key={colIdx}
                  className="flex flex-col items-center relative min-h-[280px] rounded-lg border border-white/5 bg-black/10 p-1"
                >
                  {col.length === 0 ? (
                    <div className="w-full h-24 rounded-lg border-2 border-dashed border-white/10 flex items-center justify-center text-xs text-slate-500 font-serif font-bold">
                      K
                    </div>
                  ) : (
                    col.map((card, cardIdx) => (
                      <div
                        key={card.id || cardIdx}
                        style={{
                          marginTop: cardIdx === 0 ? 0 : -55,
                          zIndex: cardIdx,
                        }}
                        className="relative transition-all"
                      >
                        <PlayingCard
                          card={card}
                          faceUp={card.faceUp}
                          size="sm"
                          cardBackTheme={cardBackTheme}
                          onClick={() => handleSmartClick(card, 'column', colIdx, cardIdx)}
                        />
                      </div>
                    ))
                  )}
                </div>
              ))}
            </div>
          </>
        ) : (
          /* SPIDER (PAUK) PAS'YANS ARENA */
          <div className="relative z-10 flex flex-col flex-1 my-3 gap-3">
            {/* Spider Status & Stock */}
            <div className="flex items-center justify-between bg-slate-950/60 p-3 rounded-xl border border-white/10">
              <div className="flex items-center gap-3">
                <div
                  onClick={handleSpiderDealStock}
                  className={`w-14 h-20 rounded-lg border-2 border-amber-400/60 bg-amber-950/40 flex flex-col items-center justify-center transition-all ${
                    spiderStock.length > 0 ? 'cursor-pointer hover:scale-105 shadow-md' : 'opacity-40 cursor-not-allowed'
                  }`}
                  title="Har bir ustunga 1 tadan karta tarqatish"
                >
                  <Layers className="w-5 h-5 text-amber-400 mb-1" />
                  <span className="text-[10px] font-mono text-amber-300 font-bold">
                    {spiderStock.length / 10} marta
                  </span>
                </div>
                <div>
                  <span className="text-xs font-bold text-slate-200 block">Pauk (Spider) Qoidasi:</span>
                  <span className="text-[11px] text-slate-400">
                    Kartalarni kamayish tartibida (K..A) yiging. Bir xil mastdagi to'liq zanjir avtomatik olib tashlanadi!
                  </span>
                </div>
              </div>

              {/* Completed Runs Foundation */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-amber-400 font-bold">Yig'ilgan zanjirlar:</span>
                <span className="px-3 py-1 rounded-xl bg-amber-500 text-slate-950 font-black font-mono text-sm shadow">
                  {spiderCompletedRuns} / 8
                </span>
              </div>
            </div>

            {/* 10 Spider Tableau Columns */}
            <div className="grid grid-cols-10 gap-1 sm:gap-2 flex-1 min-h-[380px]">
              {spiderColumns.map((col, colIdx) => (
                <div
                  key={colIdx}
                  className="flex flex-col items-center relative min-h-[300px] rounded-lg border border-white/5 bg-black/15 p-0.5"
                >
                  {col.length === 0 ? (
                    <div className="w-full h-20 rounded border border-dashed border-white/10 flex items-center justify-center text-[10px] text-slate-500 font-bold">
                      Bo'sh
                    </div>
                  ) : (
                    col.map((card, cardIdx) => (
                      <div
                        key={card.id || cardIdx}
                        style={{
                          marginTop: cardIdx === 0 ? 0 : -62,
                          zIndex: cardIdx,
                        }}
                        className="relative transition-all"
                      >
                        <PlayingCard
                          card={card}
                          faceUp={card.faceUp}
                          size="sm"
                          cardBackTheme={cardBackTheme}
                          onClick={() => handleSpiderCardClick(colIdx, cardIdx)}
                        />
                      </div>
                    ))
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Victory Modal */}
        {gameWon && (
          <div className="absolute inset-0 z-40 bg-slate-950/85 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-slate-900 border-2 border-amber-500 rounded-2xl p-6 sm:p-8 max-w-md w-full text-center shadow-2xl space-y-4">
              <div className="w-16 h-16 mx-auto rounded-full bg-amber-500/20 border border-amber-500 flex items-center justify-center text-3xl">
                🏆
              </div>

              <h2 className="text-2xl font-bold font-serif text-slate-100">
                G'alaba! Pas'yans yig'ildi!
              </h2>

              <p className="text-sm text-slate-300">
                {activeGameType === 'spider'
                  ? "Siz Pauk pas'yansining barcha 8 ta zanjirini muvaffaqiyatli yig'dingiz! +500 tanga mukofot."
                  : "Siz barcha 52 ta kartani muvaffaqiyatli tartib bilan yig'ib chiqdingiz! +300 tanga mukofot."}
              </p>

              <button
                onClick={() => (activeGameType === 'klondike' ? startNewKlondike() : startNewSpider())}
                className="w-full py-3 rounded-xl bg-amber-500 text-slate-950 font-bold hover:bg-amber-400 transition-colors shadow-lg shadow-amber-500/30 flex items-center justify-center gap-2"
              >
                <Trophy className="w-4 h-4" />
                Yana o'ynash
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
