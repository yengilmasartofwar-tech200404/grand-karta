import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  X, 
  Trophy, 
  Coins, 
  Gift, 
  Crown, 
  Sparkles, 
  Check, 
  Lock, 
  Ticket, 
  Zap, 
  ChevronRight,
  ShieldAlert,
  Flame
} from 'lucide-react';
import { UserProfileData } from '../lib/firebase';
import { sounds } from '../utils/audio';
import confetti from 'canvas-confetti';

export interface LevelConfig {
  level: number;
  rankTitle: string;
  tier: 'havaskor' | 'usta' | 'strateg' | 'grossmeyster' | 'xon' | 'sarkarda' | 'imperator' | 'afsona';
  xpRequired: number;
  rewardType: 'coins' | 'tickets' | 'vip' | 'item' | 'card_back';
  rewardAmount: number;
  rewardLabel: string;
  itemKey?: string;
  isMilestone?: boolean;
}

// Generate the complete 100 Levels with distinct rewards and realistic scaling
export const LEVEL_ROADMAP: LevelConfig[] = Array.from({ length: 100 }, (_, i) => {
  const lvl = i + 1;
  const isMilestone = lvl % 5 === 0 || lvl === 1 || lvl === 100;
  
  let tier: LevelConfig['tier'] = 'havaskor';
  let rankTitle = 'Boshlang\'ich Havaskor';
  if (lvl >= 11 && lvl <= 20) {
    tier = 'usta';
    rankTitle = 'Karta Ustasi';
  } else if (lvl >= 21 && lvl <= 35) {
    tier = 'strateg';
    rankTitle = 'Tajribali Strateg';
  } else if (lvl >= 36 && lvl <= 50) {
    tier = 'grossmeyster';
    rankTitle = 'Grossmeyster';
  } else if (lvl >= 51 && lvl <= 65) {
    tier = 'xon';
    rankTitle = 'Qirollik Xoni';
  } else if (lvl >= 66 && lvl <= 80) {
    tier = 'sarkarda';
    rankTitle = 'Afsonaviy Sarkarda';
  } else if (lvl >= 81 && lvl <= 95) {
    tier = 'imperator';
    rankTitle = 'Yengilmas Imperator';
  } else if (lvl >= 96) {
    tier = 'afsona';
    rankTitle = 'Grand Afsona (Grand God)';
  }

  // XP: scaled smoothly
  const xpRequired = lvl === 1 ? 0 : Math.round(100 * Math.pow(lvl, 1.35));

  // Distinct Rewards
  let rewardType: LevelConfig['rewardType'] = 'coins';
  let rewardAmount = lvl * 250;
  let rewardLabel = `${rewardAmount.toLocaleString()} Tanga`;
  let itemKey: string | undefined = undefined;

  if (lvl === 1) {
    rewardAmount = 1000;
    rewardLabel = '1,000 Tanga + Boshlang\'ich Bilet';
    rewardType = 'coins';
  } else if (lvl === 5) {
    rewardType = 'tickets';
    rewardAmount = 3;
    rewardLabel = '3x Omadli G\'ildirak Bileti';
  } else if (lvl === 10) {
    rewardType = 'vip';
    rewardAmount = 3; // 3 days
    rewardLabel = '3 Kunlik VIP Abuna + 5,000 Tanga';
  } else if (lvl === 15) {
    rewardType = 'item';
    rewardAmount = 1;
    rewardLabel = '3D Oltin Zanjir Aksessuari';
    itemKey = 'item_gold_chain';
  } else if (lvl === 20) {
    rewardType = 'card_back';
    rewardAmount = 10000;
    rewardLabel = 'Eksklyuziv Oltin Karta Orqasi + 10,000 Tanga';
  } else if (lvl === 25) {
    rewardType = 'tickets';
    rewardAmount = 5;
    rewardLabel = '5x Omadli Bilet + 12,000 Tanga';
  } else if (lvl === 30) {
    rewardType = 'item';
    rewardAmount = 1;
    rewardLabel = '3D Qirollik Ko\'zoynagi';
    itemKey = 'item_royal_glasses';
  } else if (lvl === 40) {
    rewardType = 'vip';
    rewardAmount = 7; // 7 days
    rewardLabel = '7 Kunlik VIP Abuna + 20,000 Tanga';
  } else if (lvl === 50) {
    rewardType = 'item';
    rewardAmount = 1;
    rewardLabel = '3D Oltin Toj (King Crown)';
    itemKey = 'item_gold_crown';
  } else if (lvl === 60) {
    rewardType = 'tickets';
    rewardAmount = 10;
    rewardLabel = '10x Omadli Bilet + 30,000 Tanga';
  } else if (lvl === 75) {
    rewardType = 'vip';
    rewardAmount = 14;
    rewardLabel = '14 Kunlik VIP Grand Abuna';
  } else if (lvl === 85) {
    rewardType = 'item';
    rewardAmount = 1;
    rewardLabel = '3D Imperator Xon Libosi';
    itemKey = 'item_emperor_suit';
  } else if (lvl === 100) {
    rewardType = 'coins';
    rewardAmount = 100000;
    rewardLabel = '💎 100,000 Katta Jackpot + Afsona Unvoni + Cheksiz VIP!';
    itemKey = 'item_afsona_god';
  } else if (lvl % 10 === 0) {
    rewardAmount = lvl * 600;
    rewardLabel = `${rewardAmount.toLocaleString()} Katta Bonus Tangalar`;
  } else if (lvl % 4 === 0) {
    rewardType = 'tickets';
    rewardAmount = 2;
    rewardLabel = '2x Omadli G\'ildirak Bileti';
  }

  return {
    level: lvl,
    rankTitle,
    tier,
    xpRequired,
    rewardType,
    rewardAmount,
    rewardLabel,
    itemKey,
    isMilestone,
  };
});

interface LevelRoadmapModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfileData;
  onUpdateProfile: (updated: UserProfileData) => void;
  onOpenLuckyWheel: () => void;
}

export const LevelRoadmapModal: React.FC<LevelRoadmapModalProps> = ({
  isOpen,
  onClose,
  profile,
  onUpdateProfile,
  onOpenLuckyWheel,
}) => {
  const [filter, setFilter] = useState<'all' | 'claimable' | 'milestones'>('all');
  const currentLevel = profile.level || 1;
  const currentXP = profile.xp || 0;
  const claimedList = useMemo(() => new Set(profile.claimedRewards || []), [profile.claimedRewards]);
  const activeLevelRowRef = useRef<HTMLDivElement | null>(null);

  // Next level XP
  const currentLevelConfig = LEVEL_ROADMAP[Math.min(currentLevel - 1, 99)];
  const nextLevelConfig = LEVEL_ROADMAP[Math.min(currentLevel, 99)];
  const prevXP = currentLevelConfig.xpRequired;
  const targetXP = nextLevelConfig.xpRequired;
  const xpInTier = Math.max(0, currentXP - prevXP);
  const xpNeeded = Math.max(1, targetXP - prevXP);
  const progressPercent = Math.min(100, Math.round((xpInTier / xpNeeded) * 100));

  // Number of claimable rewards
  const claimableLevels = useMemo(() => {
    return LEVEL_ROADMAP.filter(l => l.level <= currentLevel && !claimedList.has(l.level));
  }, [currentLevel, claimedList]);

  // Auto-scroll to current level on open
  useEffect(() => {
    if (isOpen && activeLevelRowRef.current) {
      setTimeout(() => {
        activeLevelRowRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 250);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleClaimReward = (lvlConfig: LevelConfig) => {
    sounds.playWin();
    confetti({
      particleCount: 75,
      spread: 60,
      origin: { y: 0.6 }
    });

    const newClaimed = [...(profile.claimedRewards || []), lvlConfig.level];
    let newChips = profile.chips;
    let newTickets = profile.spinTickets ?? 3;
    let newVip = profile.vipExpiresAt ?? 0;
    const newItems = [...(profile.unlockedItems || [])];

    if (lvlConfig.rewardType === 'coins') {
      newChips += lvlConfig.rewardAmount;
    } else if (lvlConfig.rewardType === 'tickets') {
      newTickets += lvlConfig.rewardAmount;
      newChips += 500; // also bonus coins
    } else if (lvlConfig.rewardType === 'vip') {
      const now = Date.now();
      const baseTime = newVip > now ? newVip : now;
      newVip = baseTime + lvlConfig.rewardAmount * 24 * 60 * 60 * 1000;
      newChips += 5000;
    } else if (lvlConfig.rewardType === 'item') {
      if (lvlConfig.itemKey && !newItems.includes(lvlConfig.itemKey)) {
        newItems.push(lvlConfig.itemKey);
      }
      newChips += 2500;
    } else if (lvlConfig.rewardType === 'card_back') {
      newChips += lvlConfig.rewardAmount;
    }

    onUpdateProfile({
      ...profile,
      chips: newChips,
      spinTickets: newTickets,
      vipExpiresAt: newVip,
      unlockedItems: newItems,
      claimedRewards: newClaimed,
    });
  };

  const handleClaimAll = () => {
    if (claimableLevels.length === 0) return;
    sounds.playWin();
    confetti({
      particleCount: 120,
      spread: 80,
      origin: { y: 0.5 }
    });

    let newChips = profile.chips;
    let newTickets = profile.spinTickets ?? 3;
    let newVip = profile.vipExpiresAt ?? 0;
    const newItems = [...(profile.unlockedItems || [])];
    const newClaimed = [...(profile.claimedRewards || [])];

    claimableLevels.forEach(lvl => {
      newClaimed.push(lvl.level);
      if (lvl.rewardType === 'coins') {
        newChips += lvl.rewardAmount;
      } else if (lvl.rewardType === 'tickets') {
        newTickets += lvl.rewardAmount;
      } else if (lvl.rewardType === 'vip') {
        const now = Date.now();
        const base = newVip > now ? newVip : now;
        newVip = base + lvl.rewardAmount * 24 * 60 * 60 * 1000;
      } else if (lvl.rewardType === 'item' && lvl.itemKey) {
        if (!newItems.includes(lvl.itemKey)) newItems.push(lvl.itemKey);
      }
    });

    onUpdateProfile({
      ...profile,
      chips: newChips,
      spinTickets: newTickets,
      vipExpiresAt: newVip,
      unlockedItems: newItems,
      claimedRewards: newClaimed,
    });
  };

  const filteredLevels = LEVEL_ROADMAP.filter(lvl => {
    if (filter === 'claimable') {
      return lvl.level <= currentLevel && !claimedList.has(lvl.level);
    }
    if (filter === 'milestones') {
      return lvl.isMilestone;
    }
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-4xl max-h-[92vh] bg-slate-950 border border-amber-500/40 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-slate-100">
        
        {/* MODAL HEADER */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-950 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-slate-950 shadow-lg shadow-amber-500/20">
              <Trophy className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black font-serif text-amber-300">
                  100 LVL Chempionlik Yo'li
                </h2>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold">
                  BATTLE PASS
                </span>
              </div>
              <p className="text-xs text-slate-400">
                O'yinlarda yutib XP yiging va 100 ta darajadagi barcha sovg'alarni oching!
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sounds.playChip();
              onClose();
            }}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* CURRENT STATUS & PROGRESS STRIP */}
        <div className="p-4 sm:p-5 bg-slate-900/90 border-b border-slate-800 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            {/* Level & Rank */}
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border-2 border-amber-500 flex flex-col items-center justify-center font-mono">
                <span className="text-[10px] text-amber-300 font-bold leading-none">LVL</span>
                <span className="text-2xl font-black text-amber-400 leading-none">{currentLevel}</span>
              </div>
              <div>
                <span className="text-xs text-amber-400 font-bold uppercase tracking-wider block">
                  {currentLevelConfig.rankTitle}
                </span>
                <h3 className="text-base sm:text-lg font-bold text-slate-100 flex items-center gap-2">
                  <span>{currentXP.toLocaleString()} XP</span>
                  <span className="text-xs text-slate-400 font-normal">
                    / {targetXP.toLocaleString()} XP
                  </span>
                </h3>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-2">
              {claimableLevels.length > 0 && (
                <button
                  onClick={handleClaimAll}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 text-xs sm:text-sm font-black shadow-lg shadow-emerald-500/30 hover:scale-105 active:scale-95 transition-all flex items-center gap-2 animate-bounce"
                >
                  <Sparkles className="w-4 h-4 fill-slate-950" />
                  <span>Barchasini Olish ({claimableLevels.length})</span>
                </button>
              )}

              <button
                onClick={() => {
                  sounds.playChip();
                  onClose();
                  onOpenLuckyWheel();
                }}
                className="px-3.5 py-2 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 hover:bg-amber-500 hover:text-slate-950 text-xs font-bold transition-all flex items-center gap-1.5"
              >
                <Ticket className="w-4 h-4" />
                <span>Omad G'ildiragi</span>
              </button>
            </div>
          </div>

          {/* Progress bar */}
          <div className="space-y-1">
            <div className="flex justify-between text-[11px] font-mono text-slate-400">
              <span>Keyingi LVL {Math.min(currentLevel + 1, 100)} gacha:</span>
              <span className="text-amber-300 font-bold">{progressPercent}% ({Math.max(0, targetXP - currentXP)} XP qoldi)</span>
            </div>
            <div className="w-full h-3 bg-slate-950 rounded-full border border-slate-800 overflow-hidden relative">
              <div
                style={{ width: `${progressPercent}%` }}
                className="h-full bg-gradient-to-r from-amber-500 via-yellow-400 to-emerald-400 rounded-full transition-all duration-500 shadow-sm"
              />
            </div>
          </div>
        </div>

        {/* TABS & FILTERS */}
        <div className="px-4 py-2.5 bg-slate-950 border-b border-slate-900 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                filter === 'all'
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-slate-400 hover:text-white bg-slate-900'
              }`}
            >
              Barcha 100 LVL
            </button>
            <button
              onClick={() => setFilter('claimable')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors flex items-center gap-1 ${
                filter === 'claimable'
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-slate-400 hover:text-white bg-slate-900'
              }`}
            >
              <span>Olishga Tayyor</span>
              {claimableLevels.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-emerald-500 text-slate-950 text-[10px] font-mono font-bold">
                  {claimableLevels.length}
                </span>
              )}
            </button>
            <button
              onClick={() => setFilter('milestones')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors flex items-center gap-1 ${
                filter === 'milestones'
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-slate-400 hover:text-white bg-slate-900'
              }`}
            >
              <Crown className="w-3.5 h-3.5" />
              <span>Katta Bosqichlar (Milestones)</span>
            </button>
          </div>

          <div className="text-xs text-slate-400 font-mono">
            Olingan: <span className="text-amber-400 font-bold">{claimedList.size}</span> / 100
          </div>
        </div>

        {/* ROADMAP SCROLLABLE LIST */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-5 space-y-2.5">
          {filteredLevels.map((lvl) => {
            const isCurrent = lvl.level === currentLevel;
            const isUnlocked = lvl.level <= currentLevel;
            const isClaimed = claimedList.has(lvl.level);
            const isReadyToClaim = isUnlocked && !isClaimed;

            return (
              <div
                key={lvl.level}
                ref={isCurrent ? activeLevelRowRef : null}
                className={`group relative p-3 sm:p-4 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                  isCurrent
                    ? 'bg-gradient-to-r from-amber-950/50 via-slate-900 to-amber-950/30 border-amber-500 shadow-lg shadow-amber-500/10'
                    : isReadyToClaim
                    ? 'bg-emerald-950/20 border-emerald-500/60 shadow-md'
                    : isUnlocked
                    ? 'bg-slate-900/60 border-slate-800'
                    : 'bg-slate-950/60 border-slate-900 opacity-60'
                }`}
              >
                {/* Level badge */}
                <div className="flex items-center gap-3">
                  <div
                    className={`w-12 h-12 rounded-xl flex flex-col items-center justify-center font-mono font-black shrink-0 border ${
                      isCurrent
                        ? 'bg-amber-500 text-slate-950 border-amber-400 scale-105'
                        : isReadyToClaim
                        ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                        : isUnlocked
                        ? 'bg-slate-800 text-amber-300 border-slate-700'
                        : 'bg-slate-900 text-slate-500 border-slate-800'
                    }`}
                  >
                    <span className="text-[9px] uppercase leading-none">LVL</span>
                    <span className="text-xl leading-none">{lvl.level}</span>
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-xs font-mono font-bold text-amber-400">
                        {lvl.rankTitle}
                      </span>
                      {lvl.isMilestone && (
                        <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold border border-amber-500/40">
                          ⭐ KATTA BOSQICH
                        </span>
                      )}
                      {isCurrent && (
                        <span className="px-1.5 py-0.2 rounded bg-blue-500/20 text-blue-300 text-[10px] font-bold border border-blue-500/40 animate-pulse">
                          SIZNING DARAJANGIZ
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-sm font-bold text-slate-100">
                        {lvl.rewardLabel}
                      </span>
                    </div>

                    <span className="text-[11px] text-slate-500 font-mono">
                      Talab qilinadi: {lvl.xpRequired.toLocaleString()} XP
                    </span>
                  </div>
                </div>

                {/* Right Side: Action Button or Claim Status */}
                <div className="shrink-0 flex items-center gap-2">
                  {isClaimed ? (
                    <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-emerald-400 text-xs font-bold font-mono">
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>Olingan</span>
                    </div>
                  ) : isReadyToClaim ? (
                    <button
                      onClick={() => handleClaimReward(lvl)}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs sm:text-sm shadow-lg shadow-emerald-500/30 hover:scale-105 active:scale-95 transition-all flex items-center gap-1.5 animate-pulse"
                    >
                      <Gift className="w-4 h-4" />
                      <span>Olish</span>
                    </button>
                  ) : (
                    <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/60 border border-slate-800 text-slate-500 text-xs font-mono">
                      <Lock className="w-3.5 h-3.5" />
                      <span>Qulflangan</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* MODAL FOOTER */}
        <div className="p-3 sm:p-4 bg-slate-950 border-t border-slate-900 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400" />
            <span>Har bir o'yindagi g'alaba sizga +60 dan +100 gacha XP beradi!</span>
          </div>
          <button
            onClick={() => {
              sounds.playChip();
              onClose();
            }}
            className="px-4 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 font-bold border border-slate-800 transition-colors"
          >
            Yopish
          </button>
        </div>

      </div>
    </div>
  );
};
