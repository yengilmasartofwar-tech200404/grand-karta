/**
 * Ming (1000) game rules engine ported from ming-replit
 */

export const SUITS_CHARS = ['♠', '♣', '♦', '♥'] as const;
export const RANKS_CHARS = ['9', 'J', 'Q', 'K', '10', 'A'] as const;
export const POINTS_TABLE = [0, 2, 3, 4, 10, 11];
export const MARRIAGE_POINTS = [40, 60, 80, 100];

export const SU = (c: number): number => Math.floor(c / 6);
export const RA = (c: number): number => c % 6;
export const PC = (c: number): number => POINTS_TABLE[RA(c)] || 0;

export const beats = (a: number, b: number, trump: number): boolean => {
  return SU(a) === SU(b) ? RA(a) > RA(b) : SU(a) === trump;
};

export const win = (tr: { p: number; c: number }[], trump: number): number => {
  let w = 0;
  for (let k = 1; k < tr.length; k++) {
    if (beats(tr[k].c, tr[w].c, trump)) w = k;
  }
  return w;
};

export function legal(h: number[], tr: { p: number; c: number }[], trump: number): number[] {
  if (!tr.length) return h;
  const w = tr[win(tr, trump)].c;
  const L = SU(tr[0].c);
  const sl = h.filter((c) => SU(c) === L);

  if (sl.length) {
    const u = sl.filter((c) => beats(c, w, trump));
    return u.length ? u : sl;
  }
  const tk = h.filter((c) => SU(c) === trump);
  if (tk.length) {
    const u = tk.filter((c) => beats(c, w, trump));
    return u.length ? u : tk;
  }
  return h;
}

export const cn = (c: number): string => RANKS_CHARS[RA(c)] + SUITS_CHARS[SU(c)];

export const hasM = (h: number[]): number[] => {
  return MARRIAGE_POINTS.map((_, s) => (h.includes(s * 6 + 2) && h.includes(s * 6 + 3) ? s : -1)).filter((s) => s >= 0);
};

export interface MingGameState {
  code: string;
  v: number;
  phase: 'lobby' | 'bid' | 'pick' | 'tal' | 'give' | 'final' | 'play' | 'col' | 'end' | 'over';
  dealer: number;
  msg: string;
  players: {
    id: string;
    name: string;
    fn?: string;
    ln?: string;
    av: string;
    bot?: boolean;
    score: number;
    barrel?: boolean;
    bf?: number;
    z?: number;
  }[];
  N?: number;
  act?: number[];
  hands?: { [key: number]: number[] };
  cap?: { [key: number]: number[] };
  mar?: { [key: number]: number };
  dcl?: { [key: number]: number };
  trump?: number;
  trick?: { p: number; c: number }[];
  out?: number[];
  cur?: number;
  who?: number;
  turn?: number;
  gv?: { f: number; to?: number }[];
  dc?: number[];
  dm?: string;
  dd?: number;
  t1?: number[];
  t2?: number[];
  ord?: number[];
  tw?: number;
  hist?: (number | string)[][];
  team?: string;
  max?: number;
}

export function newRound(G: MingGameState): void {
  const N = G.players.length;
  G.N = N;
  G.dealer = (G.dealer + 1) % N;
  G.act = [];
  for (let i = 0; i < N; i++) {
    if (!(N === 4 && i === G.dealer)) G.act.push(i);
  }

  const d = [...Array(24).keys()].sort(() => Math.random() - 0.5);
  G.hands = {};
  G.cap = {};
  G.mar = {};
  G.dcl = {};
  G.trump = -1;
  G.trick = [];
  G.out = [];
  G.cur = 0;
  G.who = -1;
  G.gv = [];
  G.dc = [];
  G.dm = '';
  G.dd = 0;

  for (let i = 0; i < N; i++) {
    G.hands[i] = [];
    G.cap[i] = [];
    G.mar[i] = 0;
  }
  G.act.forEach((i) => (G.hands![i] = d.splice(0, 7)));

  if (G.act.length === 2) {
    G.t1 = d.splice(0, 2);
    G.t2 = d.splice(0, 2);
  } else {
    G.t1 = d.splice(0, 3);
    G.t2 = [];
  }

  G.ord = [];
  for (let k = 1; k <= N; k++) {
    const x = (G.dealer + k) % N;
    if (G.act.includes(x)) G.ord.push(x);
  }
  G.turn = G.ord[0];
  G.phase = 'bid';
  G.msg = 'Savdo boshlandi';
}

export function bidA(G: MingGameState, v: number): void {
  const x = G.turn!;
  if (v) {
    G.cur = v;
    G.who = x;
    G.msg = G.players[x].name + ': ' + v;
    if (v > 120) {
      const m = hasM(G.hands![x] || []);
      G.msg += ' (marj ' + m.map((s) => SUITS_CHARS[s]).join('') + ' ko‘rsatdi)';
    }
  } else {
    G.out!.push(x);
    G.msg = G.players[x].name + ': pas';
  }

  const live = G.ord!.filter((y) => !G.out!.includes(y));
  if (live.length === 1) {
    if (G.who! < 0) {
      G.who = live[0];
      G.cur = 40;
    }
    const w = G.who!;
    G.turn = w;

    if (G.act!.length === 2) {
      G.phase = 'pick';
      G.msg = G.players[w].name + ' savdoni yutdi: ' + G.cur;
    } else {
      if (G.players.length === 4) {
        const D = G.players[G.dealer];
        const rw = (G.t1 || []).reduce((a, c) => a + PC(c), 0) + Math.max(0, ...hasM(G.t1 || []).map((s) => MARRIAGE_POINTS[s]));
        const dp = Math.max(0, Math.floor(rw / 10) * 10);
        if (!D.barrel) D.score += dp;
        G.dd = dp;
        if (dp < 10) {
          D.z = (D.z || 0) + 1;
          if (D.z >= 3) {
            D.score -= 120;
            D.z = 0;
            D.barrel = false;
            D.bf = 0;
          }
        } else {
          D.z = 0;
        }
        G.dm = D.name + ' (dam): ' + rw + ' → +' + dp + (dp < 10 ? ' —' : '');
      }
      G.msg = G.players[w].name + ' (' + G.cur + ') talon ochildi: ' + (G.t1 || []).map(cn).join(' ') + (G.dm ? ' | ' + G.dm : '');
      G.phase = 'tal';
      G.turn = w;
    }
    return;
  }

  let i = G.ord!.indexOf(x);
  do {
    i = (i + 1) % G.ord!.length;
  } while (G.out!.includes(G.ord![i]));
  G.turn = G.ord![i];
}

export function talA(G: MingGameState): void {
  const w = G.who!;
  G.hands![w].push(...(G.t1 || []));
  G.t1 = [];
  G.gv = G.act!.filter((y) => y !== w).map((y) => ({ f: w, to: y }));
  G.phase = 'give';
  G.turn = w;
  G.msg = G.players[w].name + ' talonni oldi — 2 ta kartani bering';
}

export function splitA(G: MingGameState): void {
  const w = G.who!;
  const b0 = G.players.map((p) => p.score);
  const p = G.players[w];

  if (p.barrel) {
    p.bf = (p.bf || 0) + 1;
    if (p.bf >= 3) {
      p.score = 680;
      p.barrel = false;
      p.bf = 0;
    }
  } else {
    p.score -= 120;
  }

  G.act!.filter((y) => y !== w).forEach((y) => {
    const q = G.players[y];
    if (!q.barrel) q.score += 60;
  });

  G.players.forEach((q) => {
    if (!q.barrel && q.score >= 800 && q.score < 1000) {
      q.score = 800;
      q.barrel = true;
      q.bf = 0;
    }
  });

  (G.hist = G.hist || []).push(G.players.map((q, i) => q.score - b0[i] + (i === G.dealer ? G.dd || 0 : 0)));
  const W = G.players.find((q) => q.score >= 1000);
  G.phase = W ? 'over' : 'end';
  G.msg = G.players[w].name + ' bo‘lib yubordi: −120, qolganlarga +60' + (W ? ' | ' + W.name + ' G‘ALABA!' : '');
}

export function pickA(G: MingGameState, k: number): void {
  const w = G.who!;
  const a = k ? G.t2! : G.t1!;
  const b = k ? G.t1! : G.t2!;
  G.hands![w].push(...a);
  G.t1 = [...b];
  G.t2 = [];
  G.gv = [{ f: w }, { f: w }];
  G.phase = 'give';
  G.turn = w;
  G.msg = G.players[w].name + ' talonni oldi — 2 ta ortiqcha kartani tashlang';
}

export function giveA(G: MingGameState, c: number): void {
  const g = G.gv!.shift()!;
  G.hands![g.f] = G.hands![g.f].filter((x) => x !== c);
  if (g.to != null) {
    G.hands![g.to].push(c);
    G.msg = G.players[g.f].name + ' → ' + G.players[g.to].name;
  } else {
    G.t1!.push(c);
    (G.dc = G.dc || []).push(c);
  }

  if (G.gv!.length) {
    G.turn = G.gv![0].f;
  } else {
    G.phase = 'final';
    G.turn = G.who;
    G.msg = G.players[G.who!].name + ' ochko tanlamoqda';
  }
}

export function giveB(G: MingGameState, x: number, y: number): void {
  giveA(G, x);
  giveA(G, y);
}

export function playA(G: MingGameState, c: number): void {
  const p = G.turn!;
  const h = G.hands![p];
  G.hands![p] = h.filter((x) => x !== c);

  if ((RA(c) === 2 || RA(c) === 3) && !G.dcl![SU(c)] && h.includes(SU(c) * 6 + 5 - RA(c)) && G.cap![p].length) {
    const s = SU(c);
    G.dcl![s] = 1;
    const bonus = G.players[p].barrel ? 0 : MARRIAGE_POINTS[s];
    G.mar![p] += bonus;
    G.trump = s;
    G.msg = G.players[p].name + ': MARJ ' + SUITS_CHARS[s] + ' +' + bonus + ' — kozir ' + SUITS_CHARS[s];
  } else {
    G.msg = '';
  }

  G.trick!.push({ p, c });
  if (G.trick!.length === G.act!.length) {
    G.phase = 'col';
    G.tw = G.trick![win(G.trick!, G.trump!)].p;
    G.msg += (G.msg ? ' | ' : '') + G.players[G.tw].name + ' oldi';
  } else {
    const i = G.act!.indexOf(p);
    G.turn = G.act![(i + 1) % G.act!.length];
  }
}

export function colA(G: MingGameState): void {
  G.cap![G.tw!].push(...G.trick!.map((t) => t.c));
  G.trick = [];

  if (G.hands![G.act![0]].length) {
    G.phase = 'play';
    G.turn = G.tw;
    return;
  }

  let m = '';
  const dz: { [key: number]: number } = {};
  const bh: { [key: number]: number } = {};
  const b0 = G.players.map((p) => p.score);

  for (const i of G.act!) {
    const p = G.players[i];
    const tp =
      G.cap![i].reduce((a, c) => a + PC(c), 0) +
      G.mar![i] +
      (i === G.who ? (G.t1 || []).reduce((a, c) => a + PC(c), 0) : 0);

    if (i === G.who) {
      p.z = 0;
      const ok = tp >= G.cur!;
      if (!ok && !p.barrel) {
        const sh = Math.round(G.cur! / (G.players.length - 1) / 5) * 5;
        G.players.forEach((q, j) => {
          if (j !== i && !q.barrel) q.score += sh;
        });
        m += '(har biriga +' + sh + ') ';
      }
      if (p.barrel) {
        if (ok) p.score = 1000;
        else {
          p.bf = (p.bf || 0) + 1;
          if (p.bf >= 3) {
            p.score = 680;
            p.barrel = false;
            p.bf = 0;
          }
        }
      } else {
        p.score += ok ? G.cur! : -G.cur!;
      }
      m += `${p.name}: ${tp}/${G.cur} ${ok ? '✓' : '✗'}  `;
    } else {
      if (tp < 10) {
        dz[i] = 1;
        p.z = (p.z || 0) + 1;
        m += p.name + ': ' + tp + ' (<10) —' + p.z + '  ';
        if (p.z >= 3) {
          p.score -= G.players.length === 2 ? 240 : 120;
          p.z = 0;
          p.barrel = false;
          p.bf = 0;
          m += '(−' + (G.players.length === 2 ? 240 : 120) + ') ';
        }
      } else {
        p.z = 0;
      }
      if (p.barrel) {
        bh[i] = tp < 10 ? 0 : Math.floor(tp / 10) * 10;
      } else {
        p.score += tp < 10 ? 0 : Math.floor(tp / 10) * 10;
      }
    }

    if (!p.barrel && p.score >= 800 && p.score < 1000) {
      p.score = 800;
      p.barrel = true;
      p.bf = 0;
    }
  }

  G.players.forEach((p) => {
    if (!p.barrel && p.score >= 800 && p.score < 1000) {
      p.score = 800;
      p.barrel = true;
      p.bf = 0;
    }
  });

  (G.hist = G.hist || []).push(
    G.players.map((p, i) => {
      const d = p.score - b0[i] + (i === G.dealer ? G.dd || 0 : 0);
      return dz[i] && !d ? '—' : bh[i] != null && !d ? `(${bh[i]})` : d;
    })
  );

  G.msg = m;
  const W = G.players.find((p) => p.score >= 1000);
  G.phase = W ? 'over' : 'end';
  if (W) G.msg = W.name + ' 1000 ochkoga yetdi — G‘ALABA! ' + m;
}

export function finalA(G: MingGameState, c: number): void {
  G.cur = c;
  G.phase = 'play';
  G.turn = G.who;
  G.msg = 'O‘yin boshlandi';
}
