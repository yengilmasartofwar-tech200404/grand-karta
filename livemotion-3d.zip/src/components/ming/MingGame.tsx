import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Card, Suit } from '../../types/cards';
import { PlayingCard } from '../PlayingCard';
import { ThreeDCharacter, CharacterMood, CharacterCustomization } from '../ThreeDCharacter';
import { InGameSocialBar } from '../InGameSocialBar';
import { sounds } from '../../utils/audio';
import confetti from 'canvas-confetti';
import {
  SUITS_CHARS,
  RANKS_CHARS,
  POINTS_TABLE,
  MARRIAGE_POINTS,
  SU,
  RA,
  PC,
  legal,
  win,
  hasM,
  cn,
} from './mingRules';
import {
  ArrowLeft,
  Trophy,
  Sparkles,
  BookOpen,
  FileText,
  Crown,
  Check,
  AlertTriangle,
  RotateCcw,
  Layers,
  ChevronRight,
  Shield,
  HelpCircle,
  X,
} from 'lucide-react';

interface MingGameProps {
  onWin: (reward: number) => void;
  onLose: () => void;
  tableTheme?: string;
  cardBackTheme?: string;
  characterCustom?: CharacterCustomization;
  onExit?: () => void;
}

// Player definitions: 0: Player (You), 1: Alisher, 2: Jasur
interface MingPlayerState {
  id: number;
  name: string;
  avatarVariant: 'player' | 'alisher' | 'karleone';
  score: number;
  minuses: number; // 0..3 (3 minuses = -120 penalty)
  isOnBarrel: boolean; // >= 800 pts
  barrelFails: number;
  bid: number | 'PAS' | null;
  hasPassed: boolean;
  hand: number[];
  capturedCards: number[];
  marriagePointsRound: number;
  tricksWonCount: number;
}

interface TrickCard {
  playerId: number;
  card: number;
}

interface RoundHistoryItem {
  round: number;
  bidderName: string;
  contract: number;
  p0Delta: number;
  p1Delta: number;
  p2Delta: number;
  p0Total: number;
  p1Total: number;
  p2Total: number;
}

const SUITS_MAP: Suit[] = ['spades', 'clubs', 'diamonds', 'hearts'];
const RANKS_MAP = ['9', 'J', 'Q', 'K', '10', 'A'] as const;

const SUIT_NAMES_UZ = [
  "Qarg'a (Pika ♠)",
  "Chillak (Tref ♣)",
  "G'isht (Bubna ♦)",
  "Yurak (Cherva ♥)",
];

function cardFromNum(num: number): Card {
  const s = Math.floor(num / 6);
  const r = num % 6;
  return {
    id: `ming-${num}`,
    suit: SUITS_MAP[s],
    rank: RANKS_MAP[r],
    value: POINTS_TABLE[r],
    faceUp: true,
  };
}

export const MingGame: React.FC<MingGameProps> = ({
  onWin,
  onLose,
  tableTheme = 'green',
  cardBackTheme = 'royal_blue',
  characterCustom,
  onExit,
}) => {
  // Round number
  const [roundNumber, setRoundNumber] = useState<number>(1);
  const [dealerId, setDealerId] = useState<number>(2); // Next dealer starts at 0

  // Players
  const [players, setPlayers] = useState<MingPlayerState[]>([
    {
      id: 0,
      name: "Siz (Bahodir)",
      avatarVariant: 'player',
      score: 0,
      minuses: 0,
      isOnBarrel: false,
      barrelFails: 0,
      bid: null,
      hasPassed: false,
      hand: [],
      capturedCards: [],
      marriagePointsRound: 0,
      tricksWonCount: 0,
    },
    {
      id: 1,
      name: "Alisher",
      avatarVariant: 'alisher',
      score: 0,
      minuses: 0,
      isOnBarrel: false,
      barrelFails: 0,
      bid: null,
      hasPassed: false,
      hand: [],
      capturedCards: [],
      marriagePointsRound: 0,
      tricksWonCount: 0,
    },
    {
      id: 2,
      name: "Jasur",
      avatarVariant: 'karleone',
      score: 0,
      minuses: 0,
      isOnBarrel: false,
      barrelFails: 0,
      bid: null,
      hasPassed: false,
      hand: [],
      capturedCards: [],
      marriagePointsRound: 0,
      tricksWonCount: 0,
    },
  ]);

  // Phase: 'bid' | 'talon_reveal' | 'give_cards' | 'play_trick' | 'round_end' | 'game_over'
  const [phase, setPhase] = useState<'bid' | 'talon_reveal' | 'give_cards' | 'play_trick' | 'round_end' | 'game_over'>('bid');

  // Turn tracking
  const [activeTurn, setActiveTurn] = useState<number>(0);

  // Talon
  const [talonCards, setTalonCards] = useState<number[]>([]);
  const [isTalonRevealed, setIsTalonRevealed] = useState<boolean>(false);

  // Bidding state
  const [currentHighestBid, setCurrentHighestBid] = useState<number>(40);
  const [currentHighestBidder, setCurrentHighestBidder] = useState<number>(0);
  const [playerBidInput, setPlayerBidInput] = useState<number>(50);

  // Give cards phase (winner gives 1 card to each opponent)
  const [selectedForGive, setSelectedForGive] = useState<number[]>([]);
  const [finalContractInput, setFinalContractInput] = useState<number>(40);

  // Trick Play state
  const [currentTrick, setCurrentTrick] = useState<TrickCard[]>([]);
  const [trumpSuit, setTrumpSuit] = useState<number>(-1); // -1: no trump yet, 0..3: active trump suit
  const [declaredMarriages, setDeclaredMarriages] = useState<number[]>([]); // suits where marriage was announced

  // Status and Announcements
  const [statusMessage, setStatusMessage] = useState<string>("Yangi o'yin boshlandi! 1000 ochko to'plang.");
  const [marriageBanner, setMarriageBanner] = useState<{ suit: number; playerName: string; points: number } | null>(null);

  // 3D Moods for characters
  const [bot1Mood, setBot1Mood] = useState<CharacterMood>('idle');
  const [bot2Mood, setBot2Mood] = useState<CharacterMood>('idle');
  const [isMicActive, setIsMicActive] = useState<boolean>(false);
  const [activeEmoji, setActiveEmoji] = useState<string | null>(null);
  const [emojiTriggerKey, setEmojiTriggerKey] = useState<number>(0);

  // Modals
  const [isLedgerOpen, setIsLedgerOpen] = useState<boolean>(false);
  const [isRulesOpen, setIsRulesOpen] = useState<boolean>(false);
  const [roundHistory, setRoundHistory] = useState<RoundHistoryItem[]>([]);
  const [winnerPlayer, setWinnerPlayer] = useState<MingPlayerState | null>(null);

  // Round summary data
  const [roundSummaryData, setRoundSummaryData] = useState<{
    bidder: MingPlayerState;
    contract: number;
    results: {
      player: MingPlayerState;
      cardPoints: number;
      marriagePoints: number;
      totalPoints: number;
      scoreDelta: number;
      newScore: number;
      gotMinus: boolean;
    }[];
  } | null>(null);

  const botActionTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Clear timeout on unmount
  useEffect(() => {
    return () => {
      if (botActionTimeoutRef.current) clearTimeout(botActionTimeoutRef.current);
    };
  }, []);

  // Shuffle 24 cards
  const dealNewRound = useCallback((currentDealer: number) => {
    sounds.playCardDeal();
    const deck = Array.from({ length: 24 }, (_, i) => i).sort(() => Math.random() - 0.5);

    // 7 cards each to 3 players, 3 cards in Talon
    const h0 = deck.slice(0, 7).sort((a, b) => a - b);
    const h1 = deck.slice(7, 14).sort((a, b) => a - b);
    const h2 = deck.slice(14, 21).sort((a, b) => a - b);
    const talon = deck.slice(21, 24).sort((a, b) => a - b);

    // Elder is player after dealer
    const elder = (currentDealer + 1) % 3;

    setPlayers((prev) =>
      prev.map((p, idx) => ({
        ...p,
        hand: idx === 0 ? h0 : idx === 1 ? h1 : h2,
        capturedCards: [],
        marriagePointsRound: 0,
        tricksWonCount: 0,
        bid: idx === elder ? 40 : null,
        hasPassed: false,
      }))
    );

    setTalonCards(talon);
    setIsTalonRevealed(false);
    setCurrentHighestBid(40);
    setCurrentHighestBidder(elder);
    setPlayerBidInput(elder === 0 ? 40 : 60);
    setSelectedForGive([]);
    setCurrentTrick([]);
    setTrumpSuit(-1);
    setDeclaredMarriages([]);
    setMarriageBanner(null);

    // Next bidder after elder
    const nextBidder = (elder + 1) % 3;
    setActiveTurn(nextBidder);
    setPhase('bid');

    const elderName = prevNameForId(elder);
    setStatusMessage(`Kartalar tarqatildi. ${elderName} 40 bilan savdoni boshladi.`);
  }, []);

  function prevNameForId(id: number) {
    if (id === 0) return "Siz";
    if (id === 1) return "Alisher";
    return "Jasur";
  }

  // Start initial game
  useEffect(() => {
    dealNewRound(dealerId);
  }, [dealerId, dealNewRound]);

  // Auto-sync player's bid input when it becomes player's turn in bidding (+20 step strictly)
  useEffect(() => {
    if (phase === 'bid' && activeTurn === 0) {
      setPlayerBidInput((prev) => {
        const nextMin = currentHighestBid + 20;
        return prev < nextMin ? nextMin : prev;
      });
    }
  }, [activeTurn, currentHighestBid, phase]);

  // Social emoji reactions
  const handlePlayerSendEmoji = (emoji: string) => {
    setActiveEmoji(emoji);
    setEmojiTriggerKey((k) => k + 1);

    // Opponents react
    setTimeout(() => {
      const replies = ['😎', '👍', '🔥', '🃏', '👏', '👀', '☕'];
      const chosen = replies[Math.floor(Math.random() * replies.length)];
      setActiveEmoji(chosen);
      setEmojiTriggerKey((k) => k + 1);
      setBot1Mood(emoji === '😂' ? 'laugh' : 'cool');
      setBot2Mood('clap');
    }, 1200);
  };

  // Bot bidding intelligence: Starts at 40, increments STRICTLY by +20 (60, 80, 100, 120, 140...), requires marj/kozir over 120
  const evaluateBotBid = useCallback(
    (botId: number, currentBid: number): { action: 'bid' | 'pass'; value?: number } => {
      const bot = players[botId];
      const hand = bot.hand;

      // Count high cards points (A=11, 10=10, K=4, Q=3, J=2)
      const baseCardPoints = hand.reduce((acc, c) => acc + PC(c), 0);
      const marriages = hasM(hand);
      const maxMarriage = marriages.length ? Math.max(...marriages.map((s) => MARRIAGE_POINTS[s])) : 0;

      // Barrel rule: player on barrel must bid 120 automatically or pass
      if (bot.isOnBarrel) {
        if (currentBid < 120) return { action: 'bid', value: 120 };
        return { action: 'pass' };
      }

      // Safe max estimation
      const maxSafeBid = baseCardPoints + maxMarriage - 15;

      // Strict +20 increment: 40 -> 60 -> 80 -> 100 -> 120 -> 140...
      const nextBid = currentBid + 20;

      // STRICT USER RULE: 120 gacha davom etadi, 120 dan keyin kozir (marj) kerak!
      if (nextBid > 120 && marriages.length === 0) {
        return { action: 'pass' };
      }

      // Bot willing to bid up to threshold if cards are reasonable
      const minThreshold = Math.max(60, Math.min(100, baseCardPoints));
      if (nextBid <= Math.max(minThreshold, maxSafeBid)) {
        return { action: 'bid', value: nextBid };
      }

      return { action: 'pass' };
    },
    [players]
  );

  // Check if player has marriage
  const playerMarriages = hasM(players[0]?.hand || []);
  const playerHasMarriage = playerMarriages.length > 0;

  // Handle Bidding Action
  const handleBidSubmit = useCallback(
    (amount: number) => {
      sounds.playChip();
      setCurrentHighestBid(amount);
      setCurrentHighestBidder(0);
      setPlayers((prev) =>
        prev.map((p) => (p.id === 0 ? { ...p, bid: amount } : p))
      );
      setStatusMessage(`Siz savdoni ${amount} ga ko'tardingiz!`);

      // Advance turn
      advanceBiddingTurn(0, amount, false);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [players]
  );

  const handleBidPass = useCallback(() => {
    sounds.playChip();
    setPlayers((prev) =>
      prev.map((p) => (p.id === 0 ? { ...p, bid: 'PAS', hasPassed: true } : p))
    );
    setStatusMessage("Siz pas dedingiz.");
    advanceBiddingTurn(0, currentHighestBid, true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentHighestBid, players]);

  // Turn progression for bidding
  const advanceBiddingTurn = useCallback(
    (justMovedPlayerId: number, highestBidVal: number, didPass: boolean) => {
      setPlayers((currentPlayers) => {
        const updatedPlayers = currentPlayers.map((p) =>
          p.id === justMovedPlayerId
            ? { ...p, hasPassed: didPass ? true : p.hasPassed, bid: (didPass ? 'PAS' : highestBidVal) as number | 'PAS' }
            : p
        );

        const activeBidders = updatedPlayers.filter((p) => !p.hasPassed);

        // If only 1 bidder left, bidding is complete!
        if (activeBidders.length === 1) {
          const winner = activeBidders[0];
          setCurrentHighestBidder(winner.id);
          setCurrentHighestBid(highestBidVal);
          setFinalContractInput(highestBidVal);

          // Transition to Talon reveal
          setTimeout(() => {
            setIsTalonRevealed(true);
            setPhase('talon_reveal');
            setActiveTurn(winner.id);
            sounds.playCardPlay();
            setStatusMessage(`Savdoni ${winner.name} (${highestBidVal} ochko) yutdi! Talon ochildi.`);
          }, 800);

          return updatedPlayers;
        }

        // Find next active bidder
        let next = (justMovedPlayerId + 1) % 3;
        while (updatedPlayers[next].hasPassed) {
          next = (next + 1) % 3;
        }

        setActiveTurn(next);
        return updatedPlayers;
      });
    },
    []
  );

  // Bot Turn Automation during Bidding
  useEffect(() => {
    if (phase !== 'bid') return;
    if (activeTurn === 0) return; // Player's turn

    const botId = activeTurn;
    if (botId === 1) setBot1Mood('thinking');
    if (botId === 2) setBot2Mood('thinking');

    botActionTimeoutRef.current = setTimeout(() => {
      const decision = evaluateBotBid(botId, currentHighestBid);
      const botName = botId === 1 ? 'Alisher' : 'Jasur';

      if (decision.action === 'bid' && decision.value) {
        sounds.playChip();
        setCurrentHighestBid(decision.value);
        setCurrentHighestBidder(botId);
        setStatusMessage(`${botName}: ${decision.value} ochko!`);
        if (botId === 1) setBot1Mood('cool');
        if (botId === 2) setBot2Mood('cool');
        advanceBiddingTurn(botId, decision.value, false);
      } else {
        sounds.playChip();
        setStatusMessage(`${botName}: Pas.`);
        if (botId === 1) setBot1Mood('idle');
        if (botId === 2) setBot2Mood('idle');
        advanceBiddingTurn(botId, currentHighestBid, true);
      }
    }, 1100);

    return () => {
      if (botActionTimeoutRef.current) clearTimeout(botActionTimeoutRef.current);
    };
  }, [activeTurn, phase, currentHighestBid, evaluateBotBid, advanceBiddingTurn]);

  // Handle Taking Talon
  const handleTakeTalon = useCallback(() => {
    sounds.playCardDeal();
    setPlayers((prev) =>
      prev.map((p) => {
        if (p.id === currentHighestBidder) {
          return {
            ...p,
            hand: [...p.hand, ...talonCards].sort((a, b) => a - b),
          };
        }
        return p;
      })
    );
    setTalonCards([]);
    setSelectedForGive([]);
    setPhase('give_cards');

    if (currentHighestBidder === 0) {
      setStatusMessage("Talonni oldingiz (10 ta karta). Endi raqiblarga 2 ta kartani bering!");
    } else {
      const winnerName = currentHighestBidder === 1 ? 'Alisher' : 'Jasur';
      setStatusMessage(`${winnerName} talonni oldi va kartalarni saralamoqda...`);
    }
  }, [currentHighestBidder, talonCards]);

  // Automatically take talon if bot won
  useEffect(() => {
    if (phase === 'talon_reveal' && currentHighestBidder !== 0) {
      botActionTimeoutRef.current = setTimeout(() => {
        handleTakeTalon();
      }, 1500);
    }
    return () => {
      if (botActionTimeoutRef.current) clearTimeout(botActionTimeoutRef.current);
    };
  }, [phase, currentHighestBidder, handleTakeTalon]);

  // Bot distribution of 2 cards
  useEffect(() => {
    if (phase === 'give_cards' && currentHighestBidder !== 0) {
      const botId = currentHighestBidder;
      botActionTimeoutRef.current = setTimeout(() => {
        setPlayers((prev) => {
          const bot = prev[botId];
          const hand = [...bot.hand];

          // Sort by card points ascending (give away lowest non-marriage cards)
          const marriages = hasM(hand);
          const marriageCards = new Set<number>();
          marriages.forEach((s) => {
            marriageCards.add(s * 6 + 2); // Q
            marriageCards.add(s * 6 + 3); // K
          });

          // Filter cards not part of marriages
          const nonMarriageCards = hand.filter((c) => !marriageCards.has(c));
          nonMarriageCards.sort((a, b) => PC(a) - PC(b));

          const giveCards = nonMarriageCards.slice(0, 2);
          if (giveCards.length < 2) {
            // Fallback: pick any 2 lowest
            hand.sort((a, b) => PC(a) - PC(b));
            giveCards.splice(0, giveCards.length, ...hand.slice(0, 2));
          }

          const cardForPlayer = giveCards[0];
          const cardForOtherBot = giveCards[1];
          const otherBotId = botId === 1 ? 2 : 1;

          sounds.playCardPlay();

          return prev.map((p) => {
            if (p.id === botId) {
              return {
                ...p,
                hand: p.hand.filter((c) => c !== cardForPlayer && c !== cardForOtherBot).sort((a, b) => a - b),
              };
            }
            if (p.id === 0) {
              return {
                ...p,
                hand: [...p.hand, cardForPlayer].sort((a, b) => a - b),
              };
            }
            if (p.id === otherBotId) {
              return {
                ...p,
                hand: [...p.hand, cardForOtherBot].sort((a, b) => a - b),
              };
            }
            return p;
          });
        });

        const botName = currentHighestBidder === 1 ? 'Alisher' : 'Jasur';
        setStatusMessage(`${botName} kartalarni tarqatdi. O'yin boshlandi!`);
        setPhase('play_trick');
        setActiveTurn(currentHighestBidder);
      }, 1600);
    }
    return () => {
      if (botActionTimeoutRef.current) clearTimeout(botActionTimeoutRef.current);
    };
  }, [phase, currentHighestBidder]);

  // Player gives 2 cards
  const handleToggleCardForGive = (cardNum: number) => {
    setSelectedForGive((prev) => {
      if (prev.includes(cardNum)) {
        return prev.filter((c) => c !== cardNum);
      }
      if (prev.length >= 2) return prev;
      return [...prev, cardNum];
    });
  };

  const handleConfirmGiveCards = () => {
    if (selectedForGive.length !== 2) return;
    sounds.playCardPlay();

    const [card1, card2] = selectedForGive;

    setPlayers((prev) =>
      prev.map((p) => {
        if (p.id === 0) {
          return {
            ...p,
            hand: p.hand.filter((c) => c !== card1 && c !== card2).sort((a, b) => a - b),
          };
        }
        if (p.id === 1) {
          return {
            ...p,
            hand: [...p.hand, card1].sort((a, b) => a - b),
          };
        }
        if (p.id === 2) {
          return {
            ...p,
            hand: [...p.hand, card2].sort((a, b) => a - b),
          };
        }
        return p;
      })
    );

    setCurrentHighestBid(finalContractInput);
    setSelectedForGive([]);
    setPhase('play_trick');
    setActiveTurn(0);
    setStatusMessage(`Kartalar yuborildi. Siz ${finalContractInput} ochko buyurtma qildingiz. Birinchi siz yurasiz!`);
  };

  // Split (Bo'lib yuborish / Rospis)
  const handleSplitRound = () => {
    sounds.playChip();
    const penalty = 120;
    const opponentBonus = 60;

    setPlayers((prev) =>
      prev.map((p) => {
        if (p.id === 0) {
          return { ...p, score: p.score - penalty };
        }
        return { ...p, score: p.score + opponentBonus };
      })
    );

    setStatusMessage(`Siz o'yinni bo'lib yubordingiz (-${penalty} ochko, raqiblarga +${opponentBonus})`);
    setTimeout(() => {
      checkGameEndAndNextRound();
    }, 1500);
  };

  // Play a card into the current trick
  const playCardIntoTrick = useCallback(
    (playerId: number, cardNum: number) => {
      sounds.playCardPlay();

      // Check marriage declaration:
      // Player must be leading trick (currentTrick.length === 0)
      // Must hold both K and Q
      // Must have already won at least 1 trick earlier this round
      const player = players[playerId];
      const hand = player.hand;
      const rank = RA(cardNum);
      const suit = SU(cardNum);

      let marriagePointsAwarded = 0;
      if (
        currentTrick.length === 0 &&
        (rank === 2 || rank === 3) && // Q or K
        !declaredMarriages.includes(suit) &&
        hand.includes(suit * 6 + (rank === 2 ? 3 : 2)) && // holds the partner
        player.tricksWonCount > 0
      ) {
        // Declare Marriage!
        const bonus = player.isOnBarrel ? 0 : MARRIAGE_POINTS[suit];
        marriagePointsAwarded = bonus;
        setTrumpSuit(suit);
        setDeclaredMarriages((prev) => [...prev, suit]);

        setMarriageBanner({
          suit,
          playerName: player.name,
          points: bonus,
        });
        sounds.playWin();

        setTimeout(() => setMarriageBanner(null), 3000);
      }

      // Remove card from player hand and update marriage points
      setPlayers((prev) =>
        prev.map((p) => {
          if (p.id === playerId) {
            return {
              ...p,
              hand: p.hand.filter((c) => c !== cardNum),
              marriagePointsRound: p.marriagePointsRound + marriagePointsAwarded,
            };
          }
          return p;
        })
      );

      // Add to current trick
      const updatedTrick = [...currentTrick, { playerId, card: cardNum }];
      setCurrentTrick(updatedTrick);

      // If trick is full (3 cards)
      if (updatedTrick.length === 3) {
        // Evaluate winner
        const trickForWin = updatedTrick.map((t) => ({ p: t.playerId, c: t.card }));
        const winningIndex = win(trickForWin, trumpSuit);
        const trickWinnerId = updatedTrick[winningIndex].playerId;
        const trickWinnerName = players[trickWinnerId].name;

        // Set mood
        if (trickWinnerId === 1) setBot1Mood('win');
        if (trickWinnerId === 2) setBot2Mood('win');

        setStatusMessage(`${trickWinnerName} vzatkani oldi!`);

        setTimeout(() => {
          // Collect trick cards into winner's capturedCards
          const collected = updatedTrick.map((t) => t.card);
          setPlayers((prev) =>
            prev.map((p) => {
              if (p.id === trickWinnerId) {
                return {
                  ...p,
                  capturedCards: [...p.capturedCards, ...collected],
                  tricksWonCount: p.tricksWonCount + 1,
                };
              }
              return p;
            })
          );

          setCurrentTrick([]);

          // Check if round finished (all hands empty)
          const remainingCards = player.hand.length - 1; // since current card was played
          if (remainingCards <= 0) {
            finishRound(trickWinnerId, collected);
          } else {
            setActiveTurn(trickWinnerId);
            setStatusMessage(`${trickWinnerName} yangi yurishni boshlaydi.`);
          }
        }, 1300);
      } else {
        // Next player in trick
        const next = (playerId + 1) % 3;
        setActiveTurn(next);
      }
    },
    [currentTrick, declaredMarriages, players, trumpSuit]
  );

  // Bot Turn Automation during Trick Play
  useEffect(() => {
    if (phase !== 'play_trick') return;
    if (activeTurn === 0) return; // Player's turn
    if (currentTrick.length === 3) return; // Waiting for trick resolution

    const botId = activeTurn;
    const bot = players[botId];
    if (!bot || bot.hand.length === 0) return;

    if (botId === 1) setBot1Mood('thinking');
    if (botId === 2) setBot2Mood('thinking');

    botActionTimeoutRef.current = setTimeout(() => {
      // Find legal moves
      const trickForLegal = currentTrick.map((t) => ({ p: t.playerId, c: t.card }));
      const legalMoves = legal(bot.hand, trickForLegal, trumpSuit);

      if (!legalMoves.length) return;

      let chosenCard = legalMoves[0];

      // Smart play heuristic:
      // 1. If leading trick and holds marriage + has tricksWonCount > 0, declare marriage!
      if (currentTrick.length === 0 && bot.tricksWonCount > 0) {
        const marriages = hasM(bot.hand).filter((s) => !declaredMarriages.includes(s));
        if (marriages.length > 0) {
          const bestSuit = marriages[0];
          // play Q or K of that suit
          const marriageCard = legalMoves.find((c) => SU(c) === bestSuit && (RA(c) === 2 || RA(c) === 3));
          if (marriageCard != null) {
            chosenCard = marriageCard;
          }
        }
      } else if (currentTrick.length > 0) {
        // Try to win trick with highest valid card, or discard lowest card (9 or J)
        const winningMoves = legalMoves.filter((c) => {
          const testTrick = [...trickForLegal, { p: botId, c }];
          return win(testTrick, trumpSuit) === testTrick.length - 1;
        });

        if (winningMoves.length > 0) {
          // Play lowest winning card
          winningMoves.sort((a, b) => PC(a) - PC(b));
          chosenCard = winningMoves[0];
        } else {
          // Discard lowest point card
          legalMoves.sort((a, b) => PC(a) - PC(b));
          chosenCard = legalMoves[0];
        }
      }

      playCardIntoTrick(botId, chosenCard);
    }, 1000);

    return () => {
      if (botActionTimeoutRef.current) clearTimeout(botActionTimeoutRef.current);
    };
  }, [activeTurn, currentTrick, declaredMarriages, phase, playCardIntoTrick, players, trumpSuit]);

  // Finish Round and Calculate Scores
  const finishRound = (lastTrickWinnerId: number, lastTrickCards: number[]) => {
    sounds.playWin();

    setPlayers((latestPlayers) => {
      const bidderId = currentHighestBidder;
      const bidder = latestPlayers[bidderId];
      const contract = currentHighestBid;

      const roundResults = latestPlayers.map((p) => {
        const captured = p.id === lastTrickWinnerId ? [...p.capturedCards, ...lastTrickCards] : p.capturedCards;
        const cardPoints = captured.reduce((acc, c) => acc + PC(c), 0);
        const marriagePoints = p.marriagePointsRound;
        const totalRoundPoints = cardPoints + marriagePoints;

        let scoreDelta = 0;
        let gotMinus = false;
        let newMinuses = p.minuses;
        let newBarrel = p.isOnBarrel;
        let newBarrelFails = p.barrelFails;

        if (p.id === bidderId) {
          // Bidder must score >= contract
          const madeContract = totalRoundPoints >= contract;
          if (madeContract) {
            scoreDelta = contract;
            if (newBarrel) {
              // Made contract while on barrel -> 1000!
              scoreDelta = 1000 - p.score;
            }
          } else {
            scoreDelta = -contract;
            if (newBarrel) {
              newBarrelFails += 1;
              if (newBarrelFails >= 3) {
                // Drop to 680
                scoreDelta = 680 - p.score;
                newBarrel = false;
                newBarrelFails = 0;
              }
            }
          }
        } else {
          // Non-bidders:
          // If totalPoints == 0, gets a minus «—»
          if (totalRoundPoints === 0) {
            gotMinus = true;
            newMinuses += 1;
            if (newMinuses >= 3) {
              scoreDelta = -120;
              newMinuses = 0;
            }
          } else {
            // Standard rounded points
            scoreDelta = Math.round(totalRoundPoints / 5) * 5;
          }
        }

        let newScore = p.score + scoreDelta;

        // Bo'chka threshold check (>= 800)
        if (newScore >= 800 && newScore < 1000 && !newBarrel) {
          newScore = 800;
          newBarrel = true;
          newBarrelFails = 0;
        }

        return {
          player: p,
          cardPoints,
          marriagePoints,
          totalPoints: totalRoundPoints,
          scoreDelta,
          newScore,
          gotMinus,
          newMinuses,
          newBarrel,
          newBarrelFails,
        };
      });

      // Update round summary state
      setRoundSummaryData({
        bidder,
        contract,
        results: roundResults.map((r) => ({
          player: r.player,
          cardPoints: r.cardPoints,
          marriagePoints: r.marriagePoints,
          totalPoints: r.totalPoints,
          scoreDelta: r.scoreDelta,
          newScore: r.newScore,
          gotMinus: r.gotMinus,
        })),
      });

      // Save to ledger
      setRoundHistory((prev) => [
        ...prev,
        {
          round: roundNumber,
          bidderName: bidder.name,
          contract,
          p0Delta: roundResults[0].scoreDelta,
          p1Delta: roundResults[1].scoreDelta,
          p2Delta: roundResults[2].scoreDelta,
          p0Total: roundResults[0].newScore,
          p1Total: roundResults[1].newScore,
          p2Total: roundResults[2].newScore,
        },
      ]);

      // Check if any player hit 1000
      const gameWinner = roundResults.find((r) => r.newScore >= 1000);
      if (gameWinner) {
        setWinnerPlayer(gameWinner.player);
        setPhase('game_over');
        if (gameWinner.player.id === 0) {
          confetti({ particleCount: 100, spread: 70 });
          onWin(1000);
        } else {
          onLose();
        }
      } else {
        setPhase('round_end');
      }

      // Return updated players state
      return latestPlayers.map((p, idx) => ({
        ...p,
        score: roundResults[idx].newScore,
        minuses: roundResults[idx].newMinuses,
        isOnBarrel: roundResults[idx].newBarrel,
        barrelFails: roundResults[idx].newBarrelFails,
      }));
    });
  };

  // Start Next Round
  const checkGameEndAndNextRound = () => {
    setRoundNumber((r) => r + 1);
    const nextDealer = (dealerId + 1) % 3;
    setDealerId(nextDealer);
    dealNewRound(nextDealer);
  };

  // Legal moves for player
  const playerHandNums = players[0]?.hand || [];
  const playerLegalNums =
    phase === 'play_trick' && activeTurn === 0
      ? legal(
          playerHandNums,
          currentTrick.map((t) => ({ p: t.playerId, c: t.card })),
          trumpSuit
        )
      : [];

  // Theme styling for table felt
  const feltBgClass =
    tableTheme === 'royal_blue'
      ? 'from-blue-950 via-indigo-950 to-slate-950'
      : tableTheme === 'crimson'
      ? 'from-rose-950 via-red-950 to-slate-950'
      : tableTheme === 'onyx'
      ? 'from-neutral-900 via-neutral-950 to-black'
      : 'from-emerald-950 via-green-950 to-slate-950';

  return (
    <div className="relative w-full min-h-[720px] rounded-3xl overflow-hidden border-4 border-amber-900/60 shadow-2xl flex flex-col select-none bg-slate-950">
      {/* Table Felt Surface */}
      <div className={`absolute inset-0 bg-radial ${feltBgClass} pointer-events-none`} />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.04)_0%,transparent_70%)] pointer-events-none" />

      {/* Top Header Bar */}
      <div className="relative z-20 flex items-center justify-between px-4 py-2.5 bg-black/50 backdrop-blur-md border-b border-amber-500/20 text-xs text-amber-200">
        <div className="flex items-center gap-2">
          {onExit && (
            <button
              onClick={onExit}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Chiqish</span>
            </button>
          )}
          <span className="font-serif font-bold text-amber-400 text-sm tracking-wide">
            1000 (Ming) — Raund #{roundNumber}
          </span>
        </div>

        {/* Trump Badge Indicator */}
        <div className="flex items-center gap-2">
          <div className="px-3 py-1 rounded-full bg-amber-950/80 border border-amber-500/40 text-amber-300 font-bold flex items-center gap-1.5 shadow-sm">
            <Crown className="w-3.5 h-3.5 text-amber-400" />
            <span>
              {trumpSuit >= 0 ? (
                <>
                  Kozir: <span className="text-white underline">{SUIT_NAMES_UZ[trumpSuit]}</span> (+{MARRIAGE_POINTS[trumpSuit]})
                </>
              ) : (
                "Kozir hali ochilmagan"
              )}
            </span>
          </div>
        </div>

        {/* Action Controls: Ledger & Rules */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsLedgerOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 font-medium transition-all"
          >
            <FileText className="w-3.5 h-3.5 text-amber-400" />
            <span>Daftar / Ochkolar</span>
          </button>
          <button
            onClick={() => setIsRulesOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-600 font-medium transition-all"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Qoidalar</span>
          </button>
        </div>
      </div>

      {/* Marriage Announcement Banner (Floating) */}
      {marriageBanner && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-40 px-6 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-slate-950 font-black shadow-2xl flex items-center gap-2 animate-bounce border-2 border-white">
          <Crown className="w-5 h-5 text-red-600 fill-red-600" />
          <span className="text-sm uppercase tracking-wider">
            👑 MARJ! {marriageBanner.playerName} {SUITS_CHARS[marriageBanner.suit]} Marjini ochdi (+{marriageBanner.points} ochko)! Kozir: {SUIT_NAMES_UZ[marriageBanner.suit]}
          </span>
        </div>
      )}

      {/* Main Table Felt Arena */}
      <div className="relative z-10 flex-1 flex flex-col justify-between p-3 sm:p-5">
        {/* Top: Opponents Row (Alisher on Left, Jasur on Right) */}
        <div className="grid grid-cols-2 gap-4 max-w-4xl mx-auto w-full">
          {/* Alisher (Bot 1) */}
          <div className="flex items-center gap-3 p-2.5 rounded-2xl bg-black/40 border border-white/10 backdrop-blur-sm relative">
            <div className="w-20 h-24 rounded-xl overflow-hidden bg-slate-900 border border-amber-500/20 relative shadow-inner">
              <ThreeDCharacter
                name="Alisher"
                variant="alisher"
                mood={bot1Mood}
                isThinking={activeTurn === 1 && phase === 'bid'}
                cardsCount={players[1].hand.length}
                activeEmoji={activeEmoji}
                triggerKey={emojiTriggerKey}
                nameplatePosition="none"
              />
            </div>
            <div className="flex-1 space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-slate-200">Alisher</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-amber-300 font-mono font-bold">
                  {players[1].score} / 1000
                </span>
              </div>
              <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono">
                <span>Kartalar: {players[1].hand.length} ta</span>
                {players[1].minuses > 0 && (
                  <span className="text-red-400 font-bold" title="Minuses">
                    Minus: {'—'.repeat(players[1].minuses)}
                  </span>
                )}
                {players[1].isOnBarrel && (
                  <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">
                    🛢 Bo'chkada
                  </span>
                )}
              </div>
              {/* Status pill during bidding/game */}
              <div className="text-xs text-amber-300 font-medium">
                {phase === 'bid' && (
                  players[1].hasPassed ? (
                    <span className="text-slate-500">Pas</span>
                  ) : players[1].bid ? (
                    <span className="text-emerald-400 font-bold">Savdo: {players[1].bid}</span>
                  ) : activeTurn === 1 ? (
                    <span className="text-amber-400 animate-pulse">O'ylamoqda...</span>
                  ) : (
                    <span className="text-slate-400">Kutmoqda</span>
                  )
                )}
                {phase === 'play_trick' && activeTurn === 1 && (
                  <span className="text-emerald-400 animate-pulse">Yurish qilmoqda...</span>
                )}
              </div>
            </div>
          </div>

          {/* Jasur (Bot 2) */}
          <div className="flex items-center gap-3 p-2.5 rounded-2xl bg-black/40 border border-white/10 backdrop-blur-sm relative">
            <div className="w-20 h-24 rounded-xl overflow-hidden bg-slate-900 border border-amber-500/20 relative shadow-inner">
              <ThreeDCharacter
                name="Jasur"
                variant="karleone"
                mood={bot2Mood}
                isThinking={activeTurn === 2 && phase === 'bid'}
                cardsCount={players[2].hand.length}
                activeEmoji={activeEmoji}
                triggerKey={emojiTriggerKey}
                nameplatePosition="none"
              />
            </div>
            <div className="flex-1 space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-slate-200">Jasur</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-amber-300 font-mono font-bold">
                  {players[2].score} / 1000
                </span>
              </div>
              <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono">
                <span>Kartalar: {players[2].hand.length} ta</span>
                {players[2].minuses > 0 && (
                  <span className="text-red-400 font-bold" title="Minuses">
                    Minus: {'—'.repeat(players[2].minuses)}
                  </span>
                )}
                {players[2].isOnBarrel && (
                  <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">
                    🛢 Bo'chkada
                  </span>
                )}
              </div>
              {/* Status pill during bidding/game */}
              <div className="text-xs text-amber-300 font-medium">
                {phase === 'bid' && (
                  players[2].hasPassed ? (
                    <span className="text-slate-500">Pas</span>
                  ) : players[2].bid ? (
                    <span className="text-emerald-400 font-bold">Savdo: {players[2].bid}</span>
                  ) : activeTurn === 2 ? (
                    <span className="text-amber-400 animate-pulse">O'ylamoqda...</span>
                  ) : (
                    <span className="text-slate-400">Kutmoqda</span>
                  )
                )}
                {phase === 'play_trick' && activeTurn === 2 && (
                  <span className="text-emerald-400 animate-pulse">Yurish qilmoqda...</span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Center: Table Action Field (Talon, Bidding Controls, Center Trick Cards) */}
        <div className="my-auto py-2 flex flex-col items-center justify-center min-h-[260px]">
          {/* Phase 1: Bidding (Savdo) */}
          {phase === 'bid' && (
            <div className="flex flex-col items-center text-center space-y-4 max-w-md w-full bg-black/60 backdrop-blur-md p-5 rounded-3xl border border-amber-500/30 shadow-2xl">
              <div className="flex items-center gap-2">
                <Layers className="w-5 h-5 text-amber-400" />
                <span className="text-base font-bold text-amber-300 uppercase tracking-wider">
                  Savdo Jarayoni (Bidding)
                </span>
              </div>

              {/* Talon 3 cards face-down in center */}
              <div className="flex items-center justify-center gap-2 py-1">
                {talonCards.map((c, i) => (
                  <PlayingCard
                    key={i}
                    card={cardFromNum(c)}
                    faceUp={false}
                    cardBackTheme={cardBackTheme}
                    size="sm"
                  />
                ))}
              </div>

              <div className="text-sm text-slate-300">
                Eng yuqori taklif:{' '}
                <span className="text-amber-400 font-bold text-base">
                  {currentHighestBid} ochko
                </span>{' '}
                ({players[currentHighestBidder]?.name})
              </div>

              {/* Status message */}
              <p className="text-xs text-slate-400 italic">{statusMessage}</p>

              {/* If it's Player's Turn */}
              {activeTurn === 0 ? (
                <div className="w-full space-y-2.5 pt-2 border-t border-white/10">
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-300">Sizning taklifingiz (+20 qadam):</span>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setPlayerBidInput((v) => Math.max(currentHighestBid + 20, v - 20))}
                          disabled={playerBidInput <= currentHighestBid + 20}
                          className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-amber-300 font-black text-xs flex items-center justify-center border border-slate-600 transition-all"
                          title="-20"
                        >
                          -20
                        </button>
                        <span className="text-lg font-mono font-black text-amber-300 px-3 py-1 rounded-lg bg-slate-900 border border-amber-500/40 min-w-[60px] text-center shadow-inner">
                          {playerBidInput}
                        </span>
                        <button
                          onClick={() => setPlayerBidInput((v) => v + 20)}
                          className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 font-black text-xs flex items-center justify-center border border-slate-600 transition-all"
                          title="+20"
                        >
                          +20
                        </button>
                      </div>
                    </div>

                    {/* Quick Preset Buttons (Strictly 20 step: 60, 80, 100, 120, 140) */}
                    <div className="flex items-center justify-between gap-1.5">
                      <span className="text-[11px] text-slate-400">Tezkor:</span>
                      <div className="flex items-center gap-1.5">
                        {[60, 80, 100, 120, 140].map((preset) => (
                          <button
                            key={preset}
                            type="button"
                            onClick={() => setPlayerBidInput(preset)}
                            disabled={preset <= currentHighestBid}
                            className={`px-2 py-1 rounded-lg text-xs font-mono font-bold transition-all border ${
                              playerBidInput === preset
                                ? 'bg-amber-500 text-slate-950 border-amber-300 shadow-md scale-105'
                                : preset <= currentHighestBid
                                ? 'bg-slate-900/40 text-slate-600 border-slate-800 cursor-not-allowed'
                                : 'bg-slate-800 hover:bg-slate-700 text-amber-300 border-amber-500/30'
                            }`}
                          >
                            {preset}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Warning / Notice about Kozir (Marj) */}
                  {playerBidInput <= 120 ? (
                    <div className="p-2 rounded-xl text-[11px] flex items-center gap-1.5 bg-blue-950/60 text-blue-200 border border-blue-500/30">
                      <Check className="w-3.5 h-3.5 text-blue-400" />
                      <span>120 gacha erkin savdo (Kozir shart emas)</span>
                    </div>
                  ) : (
                    <div
                      className={`p-2 rounded-xl text-[11px] flex items-center gap-1.5 ${
                        playerHasMarriage
                          ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/30'
                          : 'bg-red-950/60 text-red-300 border border-red-500/30'
                      }`}
                    >
                      {playerHasMarriage ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span>
                            Qo'lda Kozir / Marj bor ({playerMarriages.map((s) => SUITS_CHARS[s]).join(' ')})! 120 dan oshiq savdo qila olasiz.
                          </span>
                        </>
                      ) : (
                        <>
                          <AlertTriangle className="w-3.5 h-3.5 text-red-400 shrink-0" />
                          <span>120 dan oshirish uchun qo'lingizda Kozir / Marj (K+Q juftligi) bo'lishi shart!</span>
                        </>
                      )}
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="grid grid-cols-2 gap-3 pt-1">
                    <button
                      onClick={() => handleBidSubmit(playerBidInput)}
                      disabled={playerBidInput <= currentHighestBid || (playerBidInput > 120 && !playerHasMarriage)}
                      className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 disabled:opacity-40 text-white font-bold text-xs shadow-lg transition-transform active:scale-95"
                    >
                      Taklif: {playerBidInput}
                    </button>
                    <button
                      onClick={handleBidPass}
                      className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-600 transition-colors"
                    >
                      Pas qilish
                    </button>
                  </div>
                </div>
              ) : (
                <div className="text-xs text-amber-400 animate-pulse font-medium">
                  {players[activeTurn]?.name} o'ylamoqda...
                </div>
              )}
            </div>
          )}

          {/* Phase 2: Talon Revealed (Talon Ochilishi) */}
          {phase === 'talon_reveal' && (
            <div className="flex flex-col items-center text-center space-y-4 max-w-md w-full bg-black/60 backdrop-blur-md p-5 rounded-3xl border border-amber-500/40 shadow-2xl animate-fade-in">
              <span className="text-sm font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                <Crown className="w-4 h-4 text-amber-400" />
                Talon Kartalari ({players[currentHighestBidder]?.name} oldi)
              </span>

              {/* 3 Revealed Talon Cards */}
              <div className="flex items-center justify-center gap-3 py-2">
                {talonCards.map((c, i) => (
                  <PlayingCard
                    key={i}
                    card={cardFromNum(c)}
                    faceUp={isTalonRevealed}
                    cardBackTheme={cardBackTheme}
                    size="md"
                    className="ring-2 ring-amber-400 shadow-xl"
                  />
                ))}
              </div>

              <p className="text-xs text-slate-300">{statusMessage}</p>

              {currentHighestBidder === 0 && (
                <button
                  onClick={handleTakeTalon}
                  className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs shadow-lg transition-transform active:scale-95"
                >
                  Talonni Qo'lga Olish (10 ta karta)
                </button>
              )}
            </div>
          )}

          {/* Phase 3: Give 2 Cards (Kartalarni Yuborish) */}
          {phase === 'give_cards' && currentHighestBidder === 0 && (
            <div className="flex flex-col items-center text-center space-y-3 max-w-lg w-full bg-black/60 backdrop-blur-md p-4 rounded-3xl border border-amber-500/30 shadow-2xl">
              <span className="text-sm font-bold text-amber-300 uppercase tracking-wider">
                Kartalarni Yuborish & Kontrakt
              </span>
              <p className="text-xs text-slate-300">
                Qo'lingizdan 2 ta ortiqcha kartani belgilang (Alisher va Jasurga 1 tadan yuboriladi):
              </p>

              <div className="flex items-center gap-2 text-xs font-mono">
                <span className="text-amber-400 font-bold">
                  Belgilandi: {selectedForGive.length} / 2 ta
                </span>
              </div>

              {/* Final Contract Adjustment */}
              <div className="flex items-center justify-between w-full max-w-xs px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700">
                <span className="text-xs text-slate-300">Yakuniy buyurtma:</span>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setFinalContractInput((v) => Math.max(currentHighestBid, v - 20))}
                    disabled={finalContractInput <= currentHighestBid}
                    className="w-7 h-7 rounded bg-slate-800 disabled:opacity-40 text-amber-300 text-xs font-bold border border-slate-700"
                  >
                    -20
                  </button>
                  <span className="text-xs font-bold font-mono text-amber-400 px-2 min-w-[36px] text-center">
                    {finalContractInput}
                  </span>
                  <button
                    onClick={() => setFinalContractInput((v) => v + 20)}
                    className="w-7 h-7 rounded bg-slate-800 text-amber-300 text-xs font-bold border border-slate-700"
                  >
                    +20
                  </button>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-3 pt-2">
                <button
                  onClick={handleConfirmGiveCards}
                  disabled={selectedForGive.length !== 2}
                  className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 disabled:opacity-40 text-white font-bold text-xs shadow-lg transition-transform active:scale-95"
                >
                  Kartalarni Yuborish ({selectedForGive.length}/2)
                </button>
                <button
                  onClick={handleSplitRound}
                  className="py-2.5 px-3 rounded-xl bg-red-950/80 hover:bg-red-900 text-red-200 border border-red-700/60 font-medium text-xs transition-colors"
                  title="Bo'lib yuborish: Sizga -120, raqiblarga +60"
                >
                  Bo'lib yuborish (-120)
                </button>
              </div>
            </div>
          )}

          {/* Phase 4: Center Trick Area (O'yin / Vzatkalar) */}
          {phase === 'play_trick' && (
            <div className="relative w-72 h-56 flex items-center justify-center">
              {/* Active Trump Badge in Center Field */}
              <div className="absolute -top-6 text-center">
                <span className="px-3 py-1 rounded-full bg-black/60 border border-amber-500/30 text-[11px] font-bold text-amber-300">
                  {trumpSuit >= 0 ? `Kozir: ${SUITS_CHARS[trumpSuit]} ${SUIT_NAMES_UZ[trumpSuit]}` : "Kozir: Marj hali ochilmagan"}
                </span>
              </div>

              {/* Trick Cards Display */}
              {currentTrick.length === 0 ? (
                <div className="text-xs text-slate-400 font-mono tracking-wide px-4 py-2 rounded-xl bg-black/30 border border-dashed border-white/10">
                  {activeTurn === 0 ? "Sizning navbatingiz (karta tashlang)" : `${players[activeTurn]?.name} yurmoqda...`}
                </div>
              ) : (
                <div className="relative w-full h-full flex items-center justify-center">
                  {currentTrick.map((tc, idx) => {
                    // Position by player
                    const isP0 = tc.playerId === 0;
                    const isP1 = tc.playerId === 1;
                    const isP2 = tc.playerId === 2;

                    const posClass = isP0
                      ? 'translate-y-8 z-20'
                      : isP1
                      ? '-translate-x-12 -translate-y-6 z-10'
                      : 'translate-x-12 -translate-y-6 z-10';

                    return (
                      <div
                        key={idx}
                        className={`absolute transition-all duration-300 flex flex-col items-center ${posClass}`}
                      >
                        <PlayingCard
                          card={cardFromNum(tc.card)}
                          faceUp={true}
                          cardBackTheme={cardBackTheme}
                          size="md"
                          trumpSuit={trumpSuit >= 0 ? SUITS_MAP[trumpSuit] : undefined}
                          className="shadow-2xl"
                        />
                        <span className="mt-1 px-1.5 py-0.5 rounded bg-black/70 text-[10px] font-bold text-amber-200">
                          {players[tc.playerId]?.name}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Bottom: Player Area (You) */}
        <div className="w-full max-w-4xl mx-auto flex flex-col items-center space-y-2">
          {/* Player status strip */}
          <div className="w-full flex items-center justify-between px-4 py-1.5 rounded-xl bg-black/40 border border-white/10 text-xs">
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-200">{players[0].name}</span>
              <span className="px-2 py-0.5 rounded-full bg-slate-800 text-amber-300 font-mono font-bold">
                {players[0].score} / 1000
              </span>
              {players[0].minuses > 0 && (
                <span className="text-red-400 font-bold" title="Minuses">
                  Minus: {'—'.repeat(players[0].minuses)}
                </span>
              )}
              {players[0].isOnBarrel && (
                <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">
                  🛢 Bo'chkada
                </span>
              )}
            </div>

            {/* Marj indicator in hand */}
            <div className="flex items-center gap-2">
              {playerHasMarriage && (
                <div className="flex items-center gap-1 px-2 py-0.5 rounded bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[11px] font-bold">
                  <Crown className="w-3 h-3 text-amber-400" />
                  <span>
                    Qo'lda Marj: {playerMarriages.map((s) => `${SUITS_CHARS[s]} (+${MARRIAGE_POINTS[s]})`).join(' ')}
                  </span>
                </div>
              )}

              <span className="text-[11px] text-slate-400 font-mono">
                Olingan kartalar: {players[0].capturedCards.length} ta
              </span>
            </div>
          </div>

          {/* Player Cards (Hand) */}
          <div className="flex items-center justify-center gap-1 sm:gap-2 overflow-x-auto py-2 px-4 max-w-full">
            {players[0].hand.map((cardNum) => {
              const card = cardFromNum(cardNum);
              const isPlayable = phase === 'play_trick' && activeTurn === 0 && playerLegalNums.includes(cardNum);
              const isSelectedForGive = selectedForGive.includes(cardNum);

              return (
                <div key={cardNum} className="relative transition-transform">
                  <PlayingCard
                    card={card}
                    faceUp={true}
                    size="md"
                    isPlayable={isPlayable}
                    isSelected={isSelectedForGive}
                    trumpSuit={trumpSuit >= 0 ? SUITS_MAP[trumpSuit] : undefined}
                    cardBackTheme={cardBackTheme}
                    onClick={() => {
                      if (phase === 'give_cards' && currentHighestBidder === 0) {
                        handleToggleCardForGive(cardNum);
                      } else if (isPlayable) {
                        playCardIntoTrick(0, cardNum);
                      }
                    }}
                    className={`${
                      phase === 'play_trick' && activeTurn === 0 && !isPlayable
                        ? 'opacity-50 cursor-not-allowed'
                        : ''
                    }`}
                  />
                  {isSelectedForGive && (
                    <div className="absolute -top-2 left-1/2 -translate-x-1/2 px-1.5 py-0.5 rounded bg-amber-500 text-slate-950 font-black text-[9px]">
                      {selectedForGive.indexOf(cardNum) + 1}-karta
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* In-Game Social Bar (Mic, 150 Emojis & Chat) */}
      <InGameSocialBar
        playerName={players[0].name}
        opponentName="Alisher va Jasur"
        onSendEmoji={handlePlayerSendEmoji}
        onMicToggle={setIsMicActive}
        isMicActive={isMicActive}
      />

      {/* Round End Modal (Raund Yakuni) */}
      {phase === 'round_end' && roundSummaryData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-md bg-slate-900 border border-amber-500/40 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="text-center space-y-1">
              <h3 className="text-lg font-black font-serif text-amber-300">
                Raund #{roundNumber} Yakunlandi
              </h3>
              <p className="text-xs text-slate-400">
                Savdo g'olibi:{' '}
                <span className="text-amber-400 font-bold">
                  {roundSummaryData.bidder.name} ({roundSummaryData.contract} ochko)
                </span>
              </p>
            </div>

            {/* Results Table */}
            <div className="space-y-2 rounded-2xl bg-black/40 border border-white/10 p-3">
              {roundSummaryData.results.map((res, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between py-2 border-b border-white/5 last:border-none text-xs"
                >
                  <div className="space-y-0.5">
                    <span className="font-bold text-slate-200 block">{res.player.name}</span>
                    <span className="text-[11px] text-slate-400 font-mono">
                      Kartalar: {res.cardPoints} {res.marriagePoints > 0 && `+ Marj: ${res.marriagePoints}`}
                    </span>
                  </div>

                  <div className="text-right">
                    <span
                      className={`font-black font-mono text-sm block ${
                        res.scoreDelta >= 0 ? 'text-emerald-400' : 'text-red-400'
                      }`}
                    >
                      {res.scoreDelta >= 0 ? `+${res.scoreDelta}` : res.scoreDelta}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">
                      Jami: {res.newScore}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={checkGameEndAndNextRound}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-sm shadow-lg transition-transform active:scale-95"
            >
              Keyingi Raundga O'tish
            </button>
          </div>
        </div>
      )}

      {/* Game Over Modal (1000 ochko yig'ildi) */}
      {phase === 'game_over' && winnerPlayer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-md bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-amber-500 rounded-3xl p-6 text-center space-y-4 shadow-2xl">
            <div className="w-16 h-16 rounded-full bg-amber-500/20 border-2 border-amber-400 flex items-center justify-center mx-auto text-amber-300">
              <Trophy className="w-9 h-9" />
            </div>

            <h3 className="text-2xl font-black font-serif text-amber-300">
              {winnerPlayer.id === 0 ? "G'ALABA! SIZ CHEMPIONSIZ!" : `${winnerPlayer.name} G'ALABA QOZONDI!`}
            </h3>

            <p className="text-sm text-slate-300">
              {winnerPlayer.name} birinchi bo'lib 1000 ochkoga yetdi va match g'olibi bo'ldi!
            </p>

            <div className="p-3 rounded-2xl bg-black/50 border border-white/10 space-y-2 text-xs">
              {players.map((p) => (
                <div key={p.id} className="flex justify-between items-center text-slate-300">
                  <span className="font-bold">{p.name}</span>
                  <span className="font-mono font-bold text-amber-300">{p.score} ochko</span>
                </div>
              ))}
            </div>

            <button
              onClick={() => {
                setRoundNumber(1);
                setPlayers((prev) =>
                  prev.map((p) => ({
                    ...p,
                    score: 0,
                    minuses: 0,
                    isOnBarrel: false,
                    barrelFails: 0,
                  }))
                );
                setRoundHistory([]);
                setDealerId(0);
                dealNewRound(0);
              }}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-sm shadow-lg transition-transform active:scale-95"
            >
              Yana O'ynash
            </button>
          </div>
        </div>
      )}

      {/* Ledger Modal (Daftar / Ochkolar jadvali) */}
      {isLedgerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-xl bg-slate-900 border border-amber-500/40 rounded-3xl p-5 shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-amber-400" />
                <h3 className="font-black font-serif text-amber-300 text-base">
                  Daftar / Ochkolar Jadvali
                </h3>
              </div>
              <button
                onClick={() => setIsLedgerOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-white/10 text-slate-400 font-mono">
                    <th className="py-2 px-2">Raund</th>
                    <th className="py-2 px-2">Savdo (Kim)</th>
                    <th className="py-2 px-2 text-center text-amber-300">Siz</th>
                    <th className="py-2 px-2 text-center">Alisher</th>
                    <th className="py-2 px-2 text-center">Jasur</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 font-mono text-xs text-slate-300">
                  {roundHistory.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="text-center py-6 text-slate-500">
                        Hozircha yakunlangan raundlar yo'q
                      </td>
                    </tr>
                  ) : (
                    roundHistory.map((h, i) => (
                      <tr key={i} className="hover:bg-white/5">
                        <td className="py-2 px-2 font-bold text-slate-400">#{h.round}</td>
                        <td className="py-2 px-2 text-[11px] text-amber-200">
                          {h.bidderName} ({h.contract})
                        </td>
                        <td className="py-2 px-2 text-center">
                          <span className={h.p0Delta >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                            {h.p0Delta >= 0 ? `+${h.p0Delta}` : h.p0Delta}
                          </span>
                          <span className="text-[10px] text-slate-500 block">({h.p0Total})</span>
                        </td>
                        <td className="py-2 px-2 text-center">
                          <span className={h.p1Delta >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                            {h.p1Delta >= 0 ? `+${h.p1Delta}` : h.p1Delta}
                          </span>
                          <span className="text-[10px] text-slate-500 block">({h.p1Total})</span>
                        </td>
                        <td className="py-2 px-2 text-center">
                          <span className={h.p2Delta >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                            {h.p2Delta >= 0 ? `+${h.p2Delta}` : h.p2Delta}
                          </span>
                          <span className="text-[10px] text-slate-500 block">({h.p2Total})</span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            <div className="pt-2 border-t border-white/10 flex justify-between items-center text-xs font-mono font-bold text-amber-300">
              <span>Hozirgi Jami:</span>
              <div className="flex gap-4">
                <span>Siz: {players[0].score}</span>
                <span>Alisher: {players[1].score}</span>
                <span>Jasur: {players[2].score}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Rules Modal (Qoidalar) */}
      {isRulesOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-xl bg-slate-900 border border-amber-500/40 rounded-3xl p-5 shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-amber-400" />
                <h3 className="font-black font-serif text-amber-300 text-base">
                  1000 (Ming) O'yini Qoidalari
                </h3>
              </div>
              <button
                onClick={() => setIsRulesOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-3 text-xs text-slate-300 leading-relaxed pr-1">
              <div className="p-3 rounded-xl bg-black/40 border border-white/10 space-y-1">
                <span className="font-bold text-amber-300 block">🎯 O'yin Maqsadi:</span>
                <p>3 kishi o'ynaydi. Savdoda yutib, kartalar va marjlar orqali birinchi bo'lib 1000 ochko to'plash.</p>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/10 space-y-1">
                <span className="font-bold text-amber-300 block">🗣️ Savdo Qoidalari (Faqat +20 qadam):</span>
                <p>
                  Savdo 40 ochkodan boshlanadi va faqat 20 tadan qo'shilib boradi (40 → 60 → 80 → 100 → 120 → 140...). +5 va +10 mavjud emas! 120 gacha erkin savdo qilinadi, 120 dan oshirish uchun esa qo'lda albatta Kozir / Marj (K+Q juftligi) bo'lishi shart!
                </p>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/10 space-y-1">
                <span className="font-bold text-amber-300 block">🃏 Kartalar va Ochkolar (Jami 120):</span>
                <p>O'yinda 24 ta karta: 9 (0 ochko), Valet (2), Dama (3), Karol (4), 10 (10), Tuz (11).</p>
                <p className="text-slate-400 font-mono">Kuch tartibi: 9 &lt; J &lt; Q &lt; K &lt; 10 &lt; A</p>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/10 space-y-1">
                <span className="font-bold text-amber-300 block">👑 Marjlar (Kozirlar):</span>
                <ul className="list-disc pl-4 space-y-0.5 text-slate-300">
                  <li>♠ Qarg'a (Pika): K♠ + Q♠ = +40 ochko</li>
                  <li>♣ Chillak (Tref): K♣ + Q♣ = +60 ochko</li>
                  <li>♦ G'isht (Bubna): K♦ + Q♦ = +80 ochko</li>
                  <li>♥ Yurak (Cherva): K♥ + Q♥ = +100 ochko</li>
                </ul>
                <p className="text-amber-200 text-[11px] mt-1">
                  Marj ochish uchun o'yinchi avval kamida bitta vzatkani olgan bo'lishi va stolga birinchi bo'lib Dama yoki Karol bilan yurishi shart!
                </p>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/10 space-y-1">
                <span className="font-bold text-amber-300 block">🛢 Bo'chka (800 ochko):</span>
                <p>800 ochkoga yetgan o'yinchi "bo'chka"ga chiqadi. U savdoda avtomatik 120 da o'ynab, 1000 ochkoni bir martada to'plashi kerak.</p>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/10 space-y-1">
                <span className="font-bold text-amber-300 block">➖ Minus (Bolt) qoidasi:</span>
                <p>Raundda birorta ham vzatka ololmagan o'yinchiga minus «—» yoziladi. 3 ta minus to'plansa: -120 jarima yoziladi.</p>
              </div>
            </div>

            <button
              onClick={() => setIsRulesOpen(false)}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-600 transition-colors"
            >
              Tushundim
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
