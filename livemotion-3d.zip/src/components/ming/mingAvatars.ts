import * as THREE from 'three';

export interface CharacterDef {
  id: string;
  n: string;
  ic: string;
  k: 'h' | 'a';
  skin?: string;
  hair?: string;
  st?: string;
  shirt: string;
  fur?: string;
  belly?: string;
  ear?: 'cone' | 'ball' | 'long';
  hat?: string;
  cap?: string;
}

export const CHARS: CharacterDef[] = [
  { id: 'yigit', n: 'Yigit', ic: '🧑', k: 'h', skin: '#f0c29a', hair: '#2a1a10', st: 'short', shirt: '#2f6fd6' },
  { id: 'qiz', n: 'Qiz', ic: '👩', k: 'h', skin: '#f6d3b3', hair: '#1b1210', st: 'long', shirt: '#d6457f' },
  { id: 'chol', n: 'Cholim', ic: '👴', k: 'h', skin: '#e6b78f', hair: '#e8e8e8', st: 'beard', hat: '#161616', shirt: '#2f8a58' },
  { id: 'bola', n: 'Bola', ic: '🧒', k: 'h', skin: '#f3c9a0', hair: '#7a4a22', st: 'cap', cap: '#e05a2b', shirt: '#f0b429' },
  { id: 'mushuk', n: 'Mushuk', ic: '🐱', k: 'a', fur: '#e8a24f', belly: '#fff1d9', ear: 'cone', shirt: '#7a4ad6' },
  { id: 'ayiq', n: 'Ayiq', ic: '🐻', k: 'a', fur: '#8a5a3a', belly: '#d9b48f', ear: 'ball', shirt: '#d65a3a' },
  { id: 'quyon', n: 'Quyon', ic: '🐰', k: 'a', fur: '#f1f1f1', belly: '#ffe3ec', ear: 'long', shirt: '#3aa6a6' },
  { id: 'tulki', n: 'Tulki', ic: '🦊', k: 'a', fur: '#e0642a', belly: '#fff4e6', ear: 'cone', shirt: '#2a4a8a' },
];

export const LOOK: Record<string, [number, number]> = {
  front: [0, 0],
  left: [-0.75, 0],
  right: [0.75, 0],
  up: [0, -0.4],
  down: [0, 0.38],
};

const _hg = (() => {
  const s = new THREE.Shape();
  s.moveTo(0, -0.5);
  s.bezierCurveTo(-0.1, -0.4, -0.55, -0.1, -0.5, 0.17);
  s.bezierCurveTo(-0.46, 0.42, -0.1, 0.5, 0, 0.22);
  s.bezierCurveTo(0.1, 0.5, 0.46, 0.42, 0.5, 0.17);
  s.bezierCurveTo(0.55, -0.1, 0.1, -0.4, 0, -0.5);
  const g = new THREE.ExtrudeGeometry(s, { depth: 0.2, bevelEnabled: false });
  g.translate(0, 0, -0.1);
  return g;
})();

const _sg = (() => {
  const s = new THREE.Shape();
  for (let i = 0; i < 10; i++) {
    const a = -Math.PI / 2 + (i * Math.PI) / 5;
    const r = i % 2 ? 0.22 : 0.5;
    if (i) s.lineTo(Math.cos(a) * r, Math.sin(a) * r);
    else s.moveTo(Math.cos(a) * r, Math.sin(a) * r);
  }
  s.closePath();
  const g = new THREE.ExtrudeGeometry(s, { depth: 0.2, bevelEnabled: false });
  g.translate(0, 0, -0.1);
  return g;
})();

const _et: Record<string, THREE.CanvasTexture> = {};
export function emojiTex(ch: string): THREE.CanvasTexture {
  if (_et[ch]) return _et[ch];
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const g = c.getContext('2d')!;
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.font = '92px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif';
  g.fillText(ch, 64, 70);
  const tex = new THREE.CanvasTexture(c);
  _et[ch] = tex;
  return tex;
}

const _ab = Math.abs;
const _sn = Math.sin;
const _cs = Math.cos;

export interface AnimParams {
  ey?: 'open' | 'wide' | 'happy' | 'closed' | 'heart' | 'star' | 'x' | 'shades';
  mo?: 'smile' | 'op' | 'flat' | 'frown' | 'tongue';
  ms?: number;
  msy?: number;
  rx?: number;
  ry?: number;
  rz?: number;
  tz?: number;
  tx?: number;
  by?: number;
  k?: number;
  wk?: number;
  sc?: number;
  br?: { a: number; h?: number };
  A?: [[number, number], [number, number]];
  fx?: 'tears' | 'sweat' | 'hearts' | 'spark';
}

export const ANIM_PRESETS: Record<string, (u: number) => AnimParams> = {
  smile: (u) => ({ ey: 'happy', mo: 'smile', ms: 1.05, rz: _sn(u * 2) * 0.05, rx: -0.05 }),
  grin: (u) => ({ ey: 'happy', mo: 'op', ms: 1.1, msy: 0.55, rz: _sn(u * 3) * 0.07, by: _ab(_sn(u * 6)) * 0.05, A: [[0.35, 0], [0.35, 0]] }),
  laugh: (u) => ({ ey: 'happy', mo: 'op', ms: 1, msy: 0.7 + 0.3 * _ab(_sn(u * 16)), rx: -0.15 + _sn(u * 18) * 0.12, by: _ab(_sn(u * 14)) * 0.07, k: 0.3, A: [[0.1 + _ab(_sn(u * 14)) * 0.35, 0], [0.1 + _ab(_sn(u * 14)) * 0.35, 0]] }),
  wink: () => ({ ey: 'open', wk: 0, mo: 'smile', ms: 1.1, rz: 0.17, ry: 0.2, k: 0.3 }),
  blush: (u) => ({ ey: 'happy', mo: 'smile', ms: 0.9, rx: 0.18, rz: _sn(u * 2) * 0.1, k: 0.3, A: [[-0.8, -2.1], [-0.8, -2.1]] }),
  heart: (u) => ({ ey: 'heart', mo: 'smile', ms: 1.1, rx: -0.22, rz: _sn(u * 2.2) * 0.12, tz: _sn(u * 2.6) * 0.1, by: _sn(u * 5) * 0.03, k: 0.2, fx: 'hearts', A: [[0.1, -1.1], [0.1, -1.1]] }),
  love: (u) => ({ ey: 'heart', mo: 'smile', ms: 1.05, rz: _sn(u * 2) * 0.15, tz: _sn(u * 2) * 0.12, by: _ab(_sn(u * 4)) * 0.04, k: 0.2, fx: 'hearts', A: [[-0.9, -1.35], [-0.9, -1.35]] }),
  kiss: (u) => ({ ey: 'happy', mo: 'op', ms: 0.35, msy: 0.9 + 0.15 * _sn(u * 6), rx: -0.12, tz: _sn(u * 2.5) * 0.05, k: 0.3, fx: 'hearts', A: [[0.1, 0], [-0.8, -2.1 + _sn(u * 3) * 0.3]] }),
  tongue: (u) => ({ ey: 'open', mo: 'tongue', ms: 1.1, rz: _sn(u * 4) * 0.08, by: _ab(_sn(u * 5)) * 0.03 }),
  tongueWink: (u) => ({ ey: 'open', wk: 0, mo: 'tongue', ms: 1.1, rz: 0.15 + _sn(u * 4) * 0.08, k: 0.3 }),
  yum: (u) => ({ ey: 'happy', mo: 'tongue', ms: 1.1, rz: _sn(u * 3) * 0.14, tz: _sn(u * 3) * 0.05, by: _ab(_sn(u * 3)) * 0.03 }),
  crazy: (u) => ({ ey: 'wide', mo: 'tongue', ms: 1.2, rx: _sn(u * 9) * 0.2, rz: _sn(u * 7) * 0.25, ry: _sn(u * 5) * 0.4, k: 0, tz: _sn(u * 8) * 0.1, by: _ab(_sn(u * 9)) * 0.05, A: [[0.1 + _ab(_sn(u * 8)) * 0.9, 0], [0.1 + _ab(_sn(u * 8 + 1)) * 0.9, 0]] }),
  silly: (u) => ({ ey: 'wide', mo: 'smile', ms: 1.2, rz: _sn(u * 3) * 0.5, tz: _sn(u * 3) * 0.2, by: _ab(_sn(u * 6)) * 0.05, k: 0.3, A: [[0.1 + _ab(_sn(u * 6)) * 0.5, 0], [0.1 + _ab(_sn(u * 6 + 2)) * 0.5, 0]] }),
  money: (u) => ({ ey: 'star', mo: 'op', ms: 0.9, msy: 0.6, by: _ab(_sn(u * 6)) * 0.08, rz: _sn(u * 3) * 0.08, fx: 'spark', A: [[0.5, -0.8 + _sn(u * 8) * 0.2], [0.5, -0.8 + _sn(u * 8 + 1) * 0.2]] }),
  hug: (u) => ({ ey: 'happy', mo: 'smile', ms: 1.1, rz: _sn(u * 2) * 0.12, tz: _sn(u * 2) * 0.1, by: _ab(_sn(u * 3)) * 0.03, fx: 'hearts', A: [[-1.0 - 0.15 * _sn(u * 4), -1.1], [-1.0 - 0.15 * _sn(u * 4), -1.1]] }),
  giggle: (u) => ({ ey: 'happy', mo: 'smile', ms: 1, rx: _sn(u * 14) * 0.06, rz: _sn(u * 14) * 0.05, by: _ab(_sn(u * 14)) * 0.04, k: 0.3, A: [[0.1, 0], [-0.85, -2.1]] }),
  shh: () => ({ ey: 'wide', mo: 'flat', ms: 0.6, rx: 0.05, k: 0.4, A: [[0.1, 0], [-0.85, -2.1]] }),
  think: () => ({ ey: 'open', mo: 'flat', ms: 0.7, rz: 0.18, ry: 0.35, rx: -0.25, k: 0, A: [[0.1, 0], [-0.85, -2.0]] }),
  deadpan: () => ({ ey: 'open', mo: 'flat', ms: 0.9, k: 0.1 }),
  smirk: () => ({ ey: 'open', mo: 'smile', ms: 0.6, rz: 0.12, ry: 0.15, rx: -0.05, k: 0.2, br: { a: 0.25 } }),
  sideeye: () => ({ ey: 'open', mo: 'flat', ms: 0.9, ry: 0.5, k: 0, rz: 0.05, br: { a: 0.3 } }),
  eyeroll: (u) => ({ ey: 'open', mo: 'flat', ms: 0.8, k: 0, rx: -0.35, ry: _sn(u * 3) * 0.5, rz: _sn(u * 3) * 0.08 }),
  awkward: (u) => ({ ey: 'wide', mo: 'flat', ms: 1.3, tz: _sn(u * 30) * 0.015, rz: _sn(u * 2) * 0.05, k: 0.3, fx: 'sweat' }),
  confused: (u) => ({ ey: 'open', mo: 'frown', ms: 0.7, rz: 0.25, ry: _sn(u * 1.2) * 0.4, rx: 0.05, k: 0, br: { a: -0.3 } }),
  shock: (u) => ({ ey: 'wide', mo: 'flat', ms: 0.8, k: 0, rx: -0.05, tz: _sn(u * 40) * 0.008, by: -0.02, br: { a: -0.1, h: 0.08 } }),
  surprised: (u) => ({ ey: 'wide', mo: 'op', ms: 1, msy: 0.9, rx: -0.12, k: 0, by: (u < 0.6 ? _ab(_sn(u * 5)) * 0.05 : 0) + (u < 0.3 ? 0.1 : 0), br: { a: -0.1, h: 0.1 }, A: [[0.6, 0], [0.6, 0]] }),
  scream: (u) => ({ ey: 'wide', mo: 'op', ms: 1.5, msy: 1.1 + 0.2 * _sn(u * 20), rx: -0.2, k: 0, tz: _sn(u * 34) * 0.03, by: _sn(u * 30) * 0.015, br: { a: -0.3, h: 0.1 }, A: [[-0.8, -2.1], [-0.8, -2.1]] }),
  fear: (u) => ({ ey: 'wide', mo: 'frown', ms: 1, tz: _sn(u * 28) * 0.03, rz: _sn(u * 26) * 0.03, k: 0.2, fx: 'sweat', A: [[-0.9, -1.4], [-0.9, -1.4]] }),
  sweat: (u) => ({ ey: 'open', mo: 'flat', ms: 0.9, rz: _sn(u * 2) * 0.05, k: 0.3, ry: 0.25, fx: 'sweat', tz: _sn(u * 18) * 0.01 }),
  cry: (u) => ({ ey: 'closed', mo: 'op', ms: 0.7, msy: 0.45 + 0.2 * _ab(_sn(u * 9)), rx: 0.28, k: 0.2, tz: _sn(u * 26) * 0.035, fx: 'tears' }),
  sob: (u) => ({ ey: 'closed', mo: 'op', ms: 0.9, msy: 0.6 + 0.3 * _ab(_sn(u * 8)), rx: 0.35, k: 0, tz: _sn(u * 22) * 0.05, tx: 0.15 + _sn(u * 10) * 0.05, by: _sn(u * 20) * 0.03, fx: 'tears', A: [[-0.7, -2.1], [-0.7, -2.1]] }),
  sad: () => ({ ey: 'open', mo: 'frown', ms: 1, rx: 0.3, k: 0.2, tx: 0.1, br: { a: -0.35 } }),
  angry: (u) => ({ ey: 'open', mo: 'frown', ms: 0.9, rx: 0.08, k: 0, tz: _sn(u * 30) * 0.02, br: { a: 0.5 }, A: [[0.2, -0.35], [0.2, -0.35]] }),
  rage: (u) => ({ ey: 'open', mo: 'op', ms: 1.2, msy: 0.5 + 0.1 * _sn(u * 25), rx: 0.05, k: 0, tz: _sn(u * 34) * 0.04, rz: _sn(u * 30) * 0.04, by: _ab(_sn(u * 16)) * 0.05, br: { a: 0.6 }, A: [[1.0 + _sn(u * 14) * 0.3, -0.5], [1.0 + _sn(u * 14 + 1) * 0.3, -0.5]] }),
  weary: (u) => ({ ey: 'closed', mo: 'op', ms: 1.1, msy: 0.8, rx: -0.3, k: 0, tx: -0.12, tz: _sn(u * 2) * 0.03, br: { a: -0.4 } }),
  evil: (u) => ({ ey: 'open', mo: 'smile', ms: 1.4, rz: _sn(u * 2) * 0.05, k: 0.2, br: { a: 0.5 }, A: [[-0.55, -1.5 + _sn(u * 5) * 0.12], [-0.55, -1.5 - _sn(u * 5) * 0.12]] }),
  dead: (u) => ({ ey: 'x', mo: 'op', ms: 0.7, msy: 0.5, rx: u < 0.5 ? 0.1 : 0.55, k: 0, tx: u < 0.5 ? 0 : 0.35, tz: u < 0.5 ? 0 : 0.1 }),
  boo: (u) => ({ ey: 'wide', mo: 'op', ms: 1.4, msy: 1 + 0.1 * _sn(u * 20), rx: -0.1, k: 0, tz: _sn(u * 8) * 0.1, by: _ab(_sn(u * 7)) * 0.08, A: [[1.9 + _sn(u * 10) * 0.3, -0.2], [1.9 + _sn(u * 10 + 2) * 0.3, -0.2]] }),
  robot: (u) => {
    const q = Math.round(_sn(u * 2.5));
    return { ey: 'open', mo: 'flat', ms: 1.2, k: 0, ry: q * 0.5, A: [[0.1, q * 0.7], [0.1, -q * 0.7]] };
  },
  thumbs: (u) => ({ ey: 'happy', mo: 'smile', ms: 1.1, rx: _sn(u * 6) * 0.1, k: 0.2, A: [[0.1, 0], [-0.35, -1.9 + _sn(u * 8) * 0.1]] }),
  no: (u) => ({ ey: 'open', mo: 'frown', ms: 0.9, ry: _sn(u * 9) * 0.5, k: 0, br: { a: 0.3 }, A: [[0.1, 0], [-0.35, -1.6]] }),
  yes: (u) => ({ ey: 'open', mo: 'smile', ms: 1, rx: _sn(u * 7) * 0.22, k: 0.1 }),
  peace: (u) => ({ ey: 'happy', mo: 'smile', ms: 1.1, rz: 0.1, k: 0.3, A: [[0.1, 0], [2.0 + _sn(u * 5) * 0.1, -0.2]] }),
  stop: (u) => ({ ey: 'open', mo: 'flat', ms: 0.9, k: 0.2, br: { a: 0.2 }, A: [[0.1, 0], [-0.15, -1.55 + _sn(u * 10) * 0.05]] }),
  salute: () => ({ ey: 'open', mo: 'smile', ms: 0.8, rx: -0.05, k: 0, A: [[0.1, 0], [-0.3, -2.6]] }),
  bow: (u) => {
    const f = u < 1.3 ? Math.min(1, u * 2.5) : Math.max(0, 1 - (u - 1.3) * 1.5);
    return { ey: 'closed', mo: 'smile', ms: 0.8, k: 0, tx: 0.75 * f, rx: 0.3 * f, A: [[0.1, 0.2], [0.1, 0.2]] };
  },
  wave: (u) => ({ ey: 'happy', mo: 'smile', ms: 1.1, k: 0.4, rz: _sn(u * 3) * 0.05, A: [[0.1, 0], [2.2 + _sn(u * 9) * 0.45, 0]] }),
  clap: (u) => ({ ey: 'happy', mo: 'op', ms: 1, msy: 0.5, by: _ab(_sn(u * 8)) * 0.04, A: [[-0.9 + _ab(_sn(u * 8)) * 0.45, -1.4], [-0.9 + _ab(_sn(u * 8)) * 0.45, -1.4]] }),
  hooray: (u) => ({ ey: 'happy', mo: 'op', ms: 1.2, msy: 0.8, by: _ab(_sn(u * 7)) * 0.12, rx: -0.15, k: 0.2, A: [[2.7 + _sn(u * 9) * 0.2, 0], [2.7 + _sn(u * 9 + 1) * 0.2, 0]] }),
  party: (u) => ({ ey: 'happy', mo: 'op', ms: 1.2, msy: 0.8, by: _ab(_sn(u * 8)) * 0.15, tz: _sn(u * 5) * 0.12, rx: -0.15, k: 0.2, fx: 'spark', A: [[2.5 + _sn(u * 9) * 0.3, 0], [2.5 + _sn(u * 9 + 1.5) * 0.3, 0]] }),
  hype: (u) => ({ ey: 'happy', mo: 'op', ms: 1.1, msy: 0.7, by: _ab(_sn(u * 10)) * 0.14, tz: _sn(u * 8) * 0.1, k: 0.2, fx: 'spark', A: [[1.9 + _sn(u * 10) * 0.5, -0.3], [1.9 - _sn(u * 10) * 0.5, -0.3]] }),
  flex: (u) => ({ ey: 'happy', mo: 'smile', ms: 1.2, sc: 0.03 * _sn(u * 6), k: 0.2, rx: -0.1, A: [[1.9, -0.35 + _sn(u * 6) * 0.08], [1.9, -0.35 + _sn(u * 6) * 0.08]] }),
  pray: () => ({ ey: 'closed', mo: 'smile', ms: 0.8, rx: 0.2, k: 0, A: [[-0.9, -1.4], [-0.9, -1.4]] }),
  dance: (u) => ({ ey: 'happy', mo: 'op', ms: 1, msy: 0.5, tz: _sn(u * 6) * 0.15, by: _ab(_sn(u * 6)) * 0.1, rz: _sn(u * 6) * 0.15, k: 0.2, A: [[1.6 + 1.4 * _sn(u * 6), 0], [1.6 - 1.4 * _sn(u * 6), 0]] }),
  sparkle: (u) => ({ ey: 'star', mo: 'op', ms: 1, msy: 0.6, rz: _sn(u * 2) * 0.1, by: _ab(_sn(u * 4)) * 0.04, fx: 'spark', A: [[0.3, -0.5], [0.3, -0.5]] }),
  calm: (u) => ({ ey: 'closed', mo: 'smile', ms: 0.9, rx: -0.08, tz: _sn(u * 1.2) * 0.05, k: 0.1 }),
  sleep: (u) => ({ ey: 'closed', mo: 'op', ms: 0.5, msy: 0.3 + 0.25 * (_sn(u * 1.6) * 0.5 + 0.5), rx: 0.3 + _sn(u * 1.6) * 0.08, k: 0, tz: _sn(u * 1.2) * 0.05, tx: 0.12 }),
  sick: (u) => ({ ey: 'closed', mo: 'frown', ms: 0.9, rx: 0.25, k: 0, tz: _sn(u * 6) * 0.03, tx: 0.1, A: [[0.05, 0], [-0.85, -2.1]] }),
  hot: (u) => ({ ey: 'open', mo: 'tongue', ms: 1.3, rx: -0.1, k: 0, by: _ab(_sn(u * 8)) * 0.02, fx: 'sweat', A: [[0.2, -0.8 + _sn(u * 14) * 0.35], [0.2, -0.8 + _sn(u * 14 + 2) * 0.35]] }),
  cold: (u) => ({ ey: 'closed', mo: 'frown', ms: 1, tz: _sn(u * 40) * 0.03, rz: _sn(u * 36) * 0.03, by: _sn(u * 44) * 0.012, k: 0.1, A: [[-1.2, -1.1], [-1.2, -1.1]] }),
  dizzy: (u) => ({ ey: 'x', mo: 'tongue', ms: 1, rx: _sn(u * 4) * 0.25, rz: _cs(u * 4) * 0.3, tz: _sn(u * 4) * 0.1, k: 0 }),
  mind: (u) => ({ ey: 'wide', mo: 'op', ms: 1.2, msy: 1, rx: -0.25 + _sn(u * 20) * 0.03, k: 0, tz: _sn(u * 24) * 0.03, by: u < 0.4 ? 0.15 * _sn(u * 8) : _ab(_sn(u * 12)) * 0.02, fx: 'spark', A: [[-0.12, -2.57], [-0.12, -2.57]] }),
  cool: (u) => ({ ey: 'shades', mo: 'smile', ms: 0.7, rz: 0.1 + _sn(u * 2) * 0.04, ry: 0.15, rx: -0.05, k: 0.2 }),
};

ANIM_PRESETS.joy = (u) => ({ ...ANIM_PRESETS.laugh(u), fx: 'tears' });
ANIM_PRESETS.rofl = (u) => ({ ...ANIM_PRESETS.laugh(u), tz: _sn(u * 9) * 0.45, rz: _sn(u * 9) * 0.35, by: _ab(_sn(u * 12)) * 0.12, tx: -0.1 + _sn(u * 10) * 0.1, fx: 'tears' });

export class MingAvatar {
  g: THREE.Group;
  tor: THREE.Group;
  head: THREE.Group;
  arm: (THREE.Group & { _z?: number; _s?: number })[];
  ey: (THREE.Group & { o?: THREE.Group; h?: THREE.Mesh; c?: THREE.Mesh; ht?: THREE.Mesh; stz?: THREE.Mesh; xx?: THREE.Group; br?: THREE.Mesh })[];
  sg: THREE.Mesh;
  mo: THREE.Group;
  mm: { sm: THREE.Mesh; op: THREE.Group; fr: THREE.Mesh; fl: THREE.Mesh; tg: THREE.Mesh };
  tr: THREE.Mesh[];
  hf: THREE.Mesh[];
  spr: THREE.Sprite[];
  spk: THREE.Mesh[];
  t0: number = 0;
  ch: string | null = null;
  st: string = 'idle';
  until: number = 0;
  _t: number = 0;
  lk: [number, number] = LOOK.front;
  nl: number = 0;
  lkFix: string | null = null;
  lkT: number = 0;
  nb: number;
  be: number = 0;
  ph: number;
  talk: boolean = false;

  constructor(d: CharacterDef) {
    const M = (c: string, o?: any) => new THREE.MeshStandardMaterial(Object.assign({ color: c, roughness: 0.65 }, o || {}));
    const Sp = (r: number, m: THREE.Material, sx = 1, sy = 1, sz = 1) => {
      const x = new THREE.Mesh(new THREE.SphereGeometry(r, 24, 16), m);
      x.scale.set(sx, sy, sz);
      return x;
    };
    const add = (p: THREE.Group | THREE.Object3D, o: THREE.Object3D, x = 0, y = 0, z = 0) => {
      o.position.set(x, y, z);
      p.add(o);
      return o;
    };

    const hum = d.k === 'h';
    const skin = M(hum ? d.skin || '#f0c29a' : d.fur || '#8a5a3a');
    const shirt = M(d.shirt);
    const dark = M('#16161d', { roughness: 0.3 });
    const white = M('#ffffff', { roughness: 0.3 });

    const g = (this.g = new THREE.Group());
    const tor = (this.tor = new THREE.Group());
    const head = (this.head = new THREE.Group());
    g.add(tor);

    // Tana (belidan yuqori)
    add(tor, new THREE.Mesh(new THREE.CylinderGeometry(0.74, 0.88, 1.3, 28), shirt), 0, 0.65, 0);
    add(tor, Sp(0.8, shirt, 1.1, 0.38, 0.75), 0, 1.28, 0);
    add(tor, new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.2, 0.35, 16), skin), 0, 1.5, 0);

    this.arm = [-1, 1].map((s) => {
      const a = new THREE.Group() as THREE.Group & { _z?: number; _s?: number };
      a.position.set(s * 0.98, 1.22, 0);
      tor.add(a);
      add(a, new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.13, 0.85, 14), shirt), 0, -0.42, 0);
      add(a, Sp(0.16, skin), 0, -0.9, 0);
      a.rotation.z = s * 0.1;
      a._z = s * 0.1;
      a._s = s;
      return a;
    });

    // Bosh
    add(tor, head, 0, 2.0, 0);
    add(head, Sp(0.62, skin));

    // Ko'zlar
    this.ey = [-1, 1].map((s) => {
      const e = new THREE.Group() as THREE.Group & { o?: THREE.Group; h?: THREE.Mesh; c?: THREE.Mesh; ht?: THREE.Mesh; stz?: THREE.Mesh; xx?: THREE.Group; br?: THREE.Mesh };
      add(head, e, s * 0.22, 0.1, 0.56);
      const o = new THREE.Group();
      add(o, Sp(0.085, dark, 1, 1.15, 0.6));
      add(o, Sp(0.03, white), 0.025, 0.035, 0.045);
      e.add(o);

      const h = new THREE.Mesh(new THREE.TorusGeometry(0.075, 0.022, 8, 16, Math.PI), dark);
      const c = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.03, 0.03), dark);
      const ht = new THREE.Mesh(_hg, M('#ff2d55', { emissive: '#a00020', roughness: 0.4 }));
      ht.scale.setScalar(0.3);
      const stz = new THREE.Mesh(_sg, M('#ffd23f', { emissive: '#ff9d00', roughness: 0.4 }));
      stz.scale.setScalar(0.2);
      stz.position.z = 0.03;

      const xx = new THREE.Group();
      [0.785, -0.785].forEach((a) => {
        const b = new THREE.Mesh(new THREE.BoxGeometry(0.19, 0.035, 0.03), dark);
        b.rotation.z = a;
        xx.add(b);
      });

      const br = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.04, 0.03), dark);
      br.position.set(0, 0.19, -0.05);

      e.add(h, c, ht, stz, xx, br);
      e.o = o;
      e.h = h;
      e.c = c;
      e.ht = ht;
      e.stz = stz;
      e.xx = xx;
      e.br = br;
      return e;
    });

    // Quyosh ko'zoynagi
    this.sg = new THREE.Mesh(new THREE.BoxGeometry(0.66, 0.17, 0.08), M('#0b0b10', { roughness: 0.15 }));
    add(head, this.sg, 0, 0.1, 0.64);
    this.sg.visible = false;

    // Yuzdagi qizillik
    [-1, 1].forEach((s) => add(head, Sp(0.1, M('#ff8fa3', { transparent: true, opacity: 0.55 }), 1, 0.7, 0.3), s * 0.4, -0.08, 0.45));

    // Og'iz
    const m = (this.mo = new THREE.Group());
    add(head, m, 0, hum ? -0.24 : -0.25, hum ? 0.57 : 0.69);
    const sm = new THREE.Mesh(new THREE.TorusGeometry(0.15, 0.025, 8, 20, Math.PI), dark);
    sm.rotation.z = Math.PI;
    sm.position.y = 0.05;

    const op = new THREE.Group();
    add(op, Sp(0.15, M('#4a0d1c', { roughness: 0.5 }), 1, 0.85, 0.5));
    add(op, Sp(0.08, M('#e8607a')), 0, -0.07, 0.02);
    op.position.y = -0.03;

    const fr = new THREE.Mesh(new THREE.TorusGeometry(0.15, 0.025, 8, 20, Math.PI), dark);
    fr.position.y = -0.1;

    const fl = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.035, 0.03), dark);
    fl.position.y = -0.02;

    const tg = Sp(0.085, M('#e8607a'), 1, 1.25, 0.45);
    tg.position.set(0, -0.13, 0.04);

    m.add(sm, op, fr, fl, tg);
    this.mm = { sm, op, fr, fl, tg };

    if (hum) {
      [-1, 1].forEach((s) => add(head, Sp(0.12, skin, 0.6, 1, 1), s * 0.61, 0, 0));
      add(head, Sp(0.065, skin), 0, -0.04, 0.6);
      const hm = M(d.hair || '#2a1a10', { roughness: 0.9 });
      const capMesh = (mat: THREE.Material) => {
        const c = new THREE.Mesh(new THREE.SphereGeometry(0.655, 24, 12, 0, Math.PI * 2, 0, Math.PI * 0.46), mat);
        c.rotation.x = -0.3;
        head.add(c);
      };
      if (d.st === 'short') capMesh(hm);
      if (d.st === 'long') {
        capMesh(hm);
        add(head, Sp(0.7, hm, 1, 1.1, 0.62), 0, -0.2, -0.28);
        [-1, 1].forEach((s) => add(head, new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.1, 0.9, 12), hm), s * 0.56, -0.3, 0));
      }
      if (d.st === 'cap') {
        const cm = M(d.cap || '#e05a2b', { roughness: 0.8 });
        capMesh(cm);
        const v = add(head, new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.05, 0.4), cm), 0, 0.3, 0.68);
        v.rotation.x = 0.2;
      }
      if (d.st === 'beard') {
        add(head, new THREE.Mesh(new THREE.CylinderGeometry(0.46, 0.6, 0.34, 28), M(d.hat || '#161616')), 0, 0.52, 0);
        const b = add(head, new THREE.Mesh(new THREE.TorusGeometry(0.53, 0.02, 6, 32), white), 0, 0.5, 0);
        b.rotation.x = Math.PI / 2;
        [-1, 1].forEach((s) => add(head, Sp(0.16, hm, 0.6, 1.4, 0.8), s * 0.58, -0.02, -0.05));
        add(head, Sp(0.42, hm, 1, 0.7, 0.65), 0, -0.5, 0.24);
        add(head, Sp(0.1, hm, 2.2, 0.5, 0.6), 0, -0.1, 0.58);
      }
    } else {
      add(head, Sp(0.27, M(d.belly || '#ffffff'), 1, 0.72, 0.8), 0, -0.16, 0.46);
      add(head, Sp(0.065, dark, 1.2, 0.8, 0.8), 0, -0.07, 0.71);
      const pink = M('#ffb3c0');
      if (d.ear === 'cone') {
        [-1, 1].forEach((s) => {
          const e = add(head, new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.5, 4), skin), s * 0.38, 0.62, 0);
          e.rotation.z = -s * 0.35;
          const i = add(head, new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.3, 4), pink), s * 0.37, 0.6, 0.07);
          i.rotation.z = -s * 0.35;
        });
      }
      if (d.ear === 'ball') {
        [-1, 1].forEach((s) => {
          add(head, Sp(0.22, skin), s * 0.46, 0.5, -0.02);
          add(head, Sp(0.12, M(d.belly || '#ffffff'), 1, 1, 0.5), s * 0.46, 0.5, 0.12);
        });
      }
      if (d.ear === 'long') {
        [-1, 1].forEach((s) => {
          const e = add(head, Sp(0.17, skin, 1, 3.2, 0.55), s * 0.24, 1.0, -0.05);
          e.rotation.z = -s * 0.12;
          const i = add(head, Sp(0.09, pink, 1, 2.8, 0.4), s * 0.24, 0.98, 0.06);
          i.rotation.z = -s * 0.12;
        });
      }
    }

    // Ko'z yoshlari
    this.tr = [0, 1, 2, 3].map(() => {
      const t = Sp(0.05, M('#6ec6ff', { emissive: '#2a7ab0' }), 0.8, 1.3, 0.8);
      t.visible = false;
      head.add(t);
      return t;
    });

    // Uchib chiqadigan yuraklar
    this.hf = [0, 1, 2, 3, 4].map(() => {
      const h = new THREE.Mesh(_hg, M('#ff4d7a', { emissive: '#b0002a' }));
      h.visible = false;
      g.add(h);
      return h;
    });

    this.spr = [0, 1, 2, 3, 4, 5].map(() => {
      const sp = new THREE.Sprite(new THREE.SpriteMaterial({ transparent: true, depthTest: false, depthWrite: false }));
      sp.visible = false;
      sp.renderOrder = 10;
      g.add(sp);
      return sp;
    });

    this.spk = [0, 1, 2, 3, 4, 5].map(() => {
      const m = Sp(0.06, M('#ffe066', { emissive: '#ffb300', roughness: 0.3 }));
      m.visible = false;
      g.add(m);
      return m;
    });

    this.nb = 1 + Math.random() * 3;
    this.ph = Math.random() * 6;
  }

  look(dir: string, dur = 2.5) {
    this.lkFix = dir;
    this.lkT = this._t + dur;
  }

  play(s: string, dur = 2.4, ch?: string) {
    this.st = s;
    this.t0 = this._t;
    this.until = this._t + dur;
    this.ch = ch || null;
    if (ch) {
      const tx = emojiTex(ch);
      this.spr.forEach((sp) => {
        sp.material.map = tx;
        sp.material.needsUpdate = true;
      });
    }
  }

  update(t: number, dt: number) {
    this._t = t;
    const ph = this.ph;
    const head = this.head;
    const tor = this.tor;

    if (this.st !== 'idle' && t > this.until) {
      this.st = 'idle';
      this.ch = null;
    }
    if (this.lkFix && t > this.lkT) this.lkFix = null;
    if (!this.lkFix && t > this.nl) {
      const dirs = ['front', 'front', 'left', 'right', 'up', 'down'];
      this.lk = LOOK[dirs[Math.floor(Math.random() * dirs.length)]];
      this.nl = t + 1.6 + Math.random() * 2.4;
    }

    const u = Math.max(0, t - this.t0);
    const P = this.st !== 'idle' && ANIM_PRESETS[this.st] ? ANIM_PRESETS[this.st](u) : null;
    const k = Math.min(1, dt * (P ? 18 : 8));
    const L = this.lkFix ? LOOK[this.lkFix] : this.lk;
    const lk = P && P.k != null ? P.k : 1;

    let ry = L[0] * lk + (P && P.ry || 0);
    let rx = L[1] * lk + (P && P.rx || 0);
    let rz = P && P.rz || 0;
    const tbz = P && P.tz != null ? P.tz : Math.sin(t * 1.1 + ph) * 0.02;
    const tbx = P && P.tx || 0;
    const by = P && P.by || 0;
    let eyes = P && P.ey || 'open';
    let mouth = P && P.mo || 'smile';
    let ms = P && P.ms != null ? P.ms : 0.75;
    let msy = P && P.msy != null ? P.msy : 1;
    const wk = P && P.wk != null ? P.wk : -1;

    if (t > this.nb) {
      this.be = t + 0.12;
      this.nb = t + 2 + Math.random() * 3.5;
    }
    if (t < this.be && eyes === 'open') eyes = 'closed';

    if (this.talk && !P) {
      mouth = 'op';
      ms = 0.6;
      msy = 0.12 + 0.62 * Math.abs(Math.sin(t * 9.5) * Math.sin(t * 4.1 + 1));
      rx += Math.sin(t * 5.2) * 0.04;
      rz += Math.sin(t * 2.7) * 0.03;
    }

    head.rotation.y += (ry - head.rotation.y) * k;
    head.rotation.x += (rx - head.rotation.x) * k;
    head.rotation.z += (rz - head.rotation.z) * k;
    tor.rotation.z += (tbz - tor.rotation.z) * k;
    tor.rotation.x += (tbx - tor.rotation.x) * k;
    tor.position.y = by;
    tor.scale.y = 1 + Math.sin(t * 2 + ph) * 0.012 + (P && P.sc || 0);

    this.sg.visible = eyes === 'shades';
    this.ey.forEach((e, i) => {
      const m = wk === i ? 'closed' : eyes;
      const sd = i ? 1 : -1;
      if (e.o) {
        e.o.visible = m === 'open' || m === 'wide';
        e.o.scale.setScalar(m === 'wide' ? 1.45 : 1);
      }
      if (e.h) e.h.visible = m === 'happy';
      if (e.c) e.c.visible = m === 'closed';
      if (e.ht) {
        e.ht.visible = m === 'heart';
        if (m === 'heart') e.ht.scale.setScalar(0.3 + 0.06 * Math.sin(t * 9));
      }
      if (e.stz) {
        e.stz.visible = m === 'star';
        if (m === 'star') {
          e.stz.rotation.z = t * 2;
          e.stz.scale.setScalar(0.2 + 0.04 * Math.sin(t * 10));
        }
      }
      if (e.xx) e.xx.visible = m === 'x';
      const bw = P && P.br;
      if (e.br) {
        e.br.visible = !!bw;
        if (bw) {
          e.br.rotation.z = sd * bw.a;
          e.br.position.y = 0.19 + (bw.h || 0);
        }
      }
    });

    const mm = this.mm;
    mm.sm.visible = mouth === 'smile' || mouth === 'tongue';
    mm.op.visible = mouth === 'op';
    mm.fr.visible = mouth === 'frown';
    mm.fl.visible = mouth === 'flat';
    mm.tg.visible = mouth === 'tongue';
    if (mouth === 'tongue') mm.tg.position.y = -0.13 - 0.025 * Math.sin(t * 10);
    this.mo.scale.set(ms, mouth === 'op' ? msy : 1, 1);

    const AP = P && P.A;
    this.arm.forEach((a, i) => {
      const p = AP && AP[i];
      const tz = (a._s || 1) * (p ? p[0] : 0.1);
      const tx = p ? p[1] : Math.sin(t * 1.4 + i) * 0.04;
      a.rotation.z += (tz - a.rotation.z) * k;
      a.rotation.x += (tx - a.rotation.x) * k;
    });

    const fx = P && P.fx;
    this.tr.forEach((tr, i) => {
      const f = (t * 1.3 + i * 0.27) % 1;
      const sd = i % 2 ? 1 : -1;
      if (fx === 'tears') {
        tr.visible = true;
        tr.position.set(sd * (0.22 + 0.03 * f), 0.05 - f * 0.65, 0.52 + f * 0.05);
        tr.scale.setScalar(1 - f * 0.4);
      } else if (fx === 'sweat' && i < 2) {
        const g2 = (u * 0.8 + i * 0.5) % 1;
        tr.visible = true;
        tr.position.set(sd * 0.42, 0.42 - g2 * 0.6, 0.42);
        tr.scale.setScalar(1 - g2 * 0.35);
      } else {
        tr.visible = false;
      }
    });

    this.hf.forEach((h, i) => {
      if (fx === 'hearts') {
        const f = (t * 0.7 + i * 0.2) % 1;
        h.visible = true;
        h.position.set(Math.sin(i * 2.3 + t) * 0.7, 2.8 + f * 1.3, 0.4);
        h.scale.setScalar(Math.sin(f * Math.PI) * 0.4 + 0.02);
        h.rotation.y = Math.sin(t * 3 + i) * 0.5;
      } else {
        h.visible = false;
      }
    });

    this.spk.forEach((m, i) => {
      if (fx === 'spark') {
        const a = u * 3 + i * 1.05;
        const r = 0.95 + 0.2 * Math.sin(u * 2 + i);
        m.visible = true;
        m.position.set(Math.cos(a) * r, 2.1 + Math.sin(u * 3 + i * 1.7) * 0.55, Math.sin(a) * r * 0.5 + 0.35);
        m.scale.setScalar(0.6 + 0.5 * Math.abs(Math.sin(u * 6 + i)));
      } else {
        m.visible = false;
      }
    });

    const on = !!this.ch && this.st !== 'idle';
    const tail = Math.max(0, Math.min(1, (this.until - t) / 0.45));
    this.spr.forEach((sp, j) => {
      if (!on) {
        sp.visible = false;
        return;
      }
      if (j === 0) {
        const pop = (1 - Math.exp(-u * 14)) * (1 + 0.18 * Math.sin(u * 14) * Math.exp(-u * 2.5));
        sp.visible = true;
        sp.position.set(0, 3.4 + Math.sin(t * 4) * 0.05, 0.3);
        sp.scale.setScalar(pop * (0.4 + 0.6 * tail));
        sp.material.opacity = tail;
      } else {
        const d0 = u - j * 0.12;
        if (d0 < 0) {
          sp.visible = false;
          return;
        }
        const f = (d0 * 0.55) % 1;
        sp.visible = true;
        sp.position.set((j - 3) * 0.36 + Math.sin(u * 3 + j * 2) * 0.12, 2.95 + f * 1.1, 0.35);
        sp.scale.setScalar((0.1 + 0.3 * Math.sin(f * Math.PI)) * tail);
        sp.material.opacity = Math.sin(f * Math.PI) * tail;
      }
    });
  }
}
