import React, { useState, useEffect } from 'react';
import { sounds } from '../utils/audio';
import { Sparkles, Play } from 'lucide-react';

interface Splash3DProps {
  onComplete: () => void;
}

export const Splash3D: React.FC<Splash3DProps> = ({ onComplete }) => {
  const [stage, setStage] = useState<'intro' | 'fan' | 'ready'>('intro');

  useEffect(() => {
    sounds.playCardDeal();

    const t1 = setTimeout(() => {
      setStage('fan');
      sounds.playCardPlay();
    }, 900);

    const t2 = setTimeout(() => {
      setStage('ready');
      sounds.playChip();
    }, 2000);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  const cards = [
    { rank: 'A', suit: '♠', isRed: false, rotZ: -28, transX: -140, transY: 20 },
    { rank: 'K', suit: '♥', isRed: true, rotZ: -14, transX: -70, transY: -10 },
    { rank: 'Q', suit: '♦', isRed: true, rotZ: 0, transX: 0, transY: -25 },
    { rank: 'J', suit: '♣', isRed: false, rotZ: 14, transX: 70, transY: -10 },
    { rank: 'A', suit: '♥', isRed: true, rotZ: 28, transX: 140, transY: 20 },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-radial from-slate-900 via-slate-950 to-black flex flex-col items-center justify-center overflow-hidden select-none">
      {/* 3D background ambient grid and casino spotlight */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_35%,rgba(16,185,129,0.18),transparent_65%)] pointer-events-none" />
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] pointer-events-none" />

      {/* 3D Scene Viewport */}
      <div
        style={{ perspective: '1400px', transformStyle: 'preserve-3d' }}
        className="relative w-80 h-96 flex items-center justify-center transition-all duration-700"
      >
        {/* Floating 3D Cards */}
        {cards.map((c, i) => {
          const isFan = stage === 'fan' || stage === 'ready';
          const rotZ = isFan ? c.rotZ : 0;
          const transX = isFan ? c.transX : (i - 2) * 5;
          const transY = isFan ? c.transY : (i - 2) * 3;
          const transZ = isFan ? 40 - Math.abs(i - 2) * 20 : (i - 2) * 10;
          const rotY = stage === 'ready' ? (i - 2) * 8 : (i - 2) * 3;
          const rotX = stage === 'ready' ? 12 : 5;

          return (
            <div
              key={i}
              style={{
                transform: `translateX(${transX}px) translateY(${transY}px) translateZ(${transZ}px) rotateZ(${rotZ}deg) rotateY(${rotY}deg) rotateX(${rotX}deg)`,
                transition: 'all 0.85s cubic-bezier(0.16, 1, 0.3, 1)',
              }}
              className="absolute w-36 h-52 sm:w-44 sm:h-64 rounded-2xl bg-white border-2 border-amber-300/80 shadow-[0_25px_50px_-12px_rgba(0,0,0,0.8)] p-3 flex flex-col justify-between overflow-hidden"
            >
              {/* Card Holographic Gloss */}
              <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/40 to-amber-200/20 pointer-events-none" />

              {/* Corner Value */}
              <div className={`flex flex-col items-center leading-none ${c.isRed ? 'text-red-600' : 'text-slate-900'}`}>
                <span className="font-bold text-lg sm:text-2xl font-sans tracking-tight">{c.rank}</span>
                <span className="text-base sm:text-xl">{c.suit}</span>
              </div>

              {/* Center Emblem */}
              <div className="flex flex-col items-center justify-center">
                <span className={`text-4xl sm:text-6xl font-serif ${c.isRed ? 'text-red-600' : 'text-slate-900'}`}>
                  {c.suit}
                </span>
                <span className="text-[10px] font-mono tracking-widest uppercase text-slate-400 mt-1">
                  ROYAL 3D
                </span>
              </div>

              {/* Inverted Corner */}
              <div className={`flex flex-col items-center leading-none rotate-180 ${c.isRed ? 'text-red-600' : 'text-slate-900'}`}>
                <span className="font-bold text-lg sm:text-2xl font-sans tracking-tight">{c.rank}</span>
                <span className="text-base sm:text-xl">{c.suit}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Title & Brand presentation */}
      <div className="relative z-10 text-center mt-8 px-4 flex flex-col items-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold">
          <Sparkles className="w-3.5 h-3.5" />
          O'zbek Milliy & Dunyo Karta O'yinlari
        </div>

        <h1 className="text-3xl sm:text-5xl font-black font-serif text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-amber-200 tracking-tight drop-shadow-lg">
          GRAND KARTA KLUBI
        </h1>

        <p className="text-sm sm:text-base text-slate-300 max-w-md mx-auto">
          Durak, 21 Ochko, Solitaire va do'stlar bilan jonli multiplayer karta xonalari.
        </p>

        {/* Enter Button */}
        <div className="pt-3 flex items-center gap-4">
          <button
            onClick={() => {
              sounds.playWin();
              onComplete();
            }}
            className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-base shadow-[0_10px_30px_rgba(245,158,11,0.4)] hover:scale-105 active:scale-95 transition-all flex items-center gap-2.5"
          >
            <Play className="w-5 h-5 fill-slate-950" />
            O'yinga Kirish
          </button>

          <button
            onClick={onComplete}
            className="px-4 py-3 text-xs text-slate-400 hover:text-slate-200 transition-colors"
          >
            O'tkazib yuborish
          </button>
        </div>
      </div>
    </div>
  );
};
