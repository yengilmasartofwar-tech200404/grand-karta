/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { GameMode } from './types/cards';
import { UserProfileData, getOrCreateUser, saveUserProfile, MultiplayerRoom } from './lib/firebase';
import { Header } from './components/Header';
import { Splash3D } from './components/Splash3D';
import { GameCatalog } from './components/GameCatalog';
import { SaveProgressBanner } from './components/SaveProgressBanner';
import { ProfileModal } from './components/ProfileModal';
import { AvatarStudioModal } from './components/profile/AvatarStudioModal';
import { CharacterCustomization } from './components/ThreeDCharacter';
import { FriendsMultiplayerModal } from './components/FriendsMultiplayerModal';
import { LeaderboardModal } from './components/LeaderboardModal';
import { RulesModal } from './components/RulesModal';
import { DurakGame } from './components/durak/DurakGame';
import { OchkoGame } from './components/ochko/OchkoGame';
import { SolitaireGame } from './components/solitaire/SolitaireGame';
import { MingGame } from './components/ming/MingGame';
import { LevelRoadmapModal, LEVEL_ROADMAP } from './components/LevelRoadmapModal';
import { LuckyWheelModal } from './components/LuckyWheelModal';
import { sounds } from './utils/audio';
import confetti from 'canvas-confetti';
import { ArrowLeft } from 'lucide-react';

export default function App() {
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [activeView, setActiveView] = useState<'catalog' | 'game' | 'friends' | 'leaderboard'>('catalog');
  const [activeGame, setActiveGame] = useState<GameMode>('durak');
  const [activeVariant, setActiveVariant] = useState<string>('podkidnoy');
  const [isPassAndPlay, setIsPassAndPlay] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [tableTheme, setTableTheme] = useState<string>(() => localStorage.getItem('grand_table_theme') || 'green');
  const [cardBackTheme, setCardBackTheme] = useState<string>(() => localStorage.getItem('grand_card_back') || 'royal_blue');

  // Modals
  const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);
  const [isAvatarStudioOpen, setIsAvatarStudioOpen] = useState<boolean>(false);
  const [isFriendsOpen, setIsFriendsOpen] = useState<boolean>(false);
  const [isLeaderboardOpen, setIsLeaderboardOpen] = useState<boolean>(false);
  const [isRulesOpen, setIsRulesOpen] = useState<boolean>(false);
  const [isLevelRoadmapOpen, setIsLevelRoadmapOpen] = useState<boolean>(false);
  const [isLuckyWheelOpen, setIsLuckyWheelOpen] = useState<boolean>(false);

  // Character 3D Customization
  const [characterCustom, setCharacterCustom] = useState<CharacterCustomization>(() => {
    try {
      const saved = localStorage.getItem('grand_character_custom');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      modelId: 'alisher',
      hairColor: '#18181b',
      hairStyle: 'classic',
      suitColor: '#1e3a8a',
      suitStyle: 'classic',
      accessory: 'none',
      facialHair: 'none',
      earring: 'none',
      skinColor: '#fed7aa',
    };
  });

  // User Profile
  const [profile, setProfile] = useState<UserProfileData>({
    uid: 'local_user',
    displayName: "O'yinchi",
    avatar: '👑',
    chips: 1000,
    level: 1,
    durakWins: 0,
    durakLosses: 0,
    ochkoWins: 0,
    ochkoLosses: 0,
    solitaireWins: 0,
  });

  // Load from Firebase on start
  useEffect(() => {
    getOrCreateUser().then((userData) => {
      setProfile(userData);
    });

    // Check if URL has ?room=XYZ
    const params = new URLSearchParams(window.location.search);
    const roomParam = params.get('room');
    if (roomParam) {
      setIsFriendsOpen(true);
    }
  }, []);

  const toggleSound = () => {
    sounds.soundEnabled = !soundEnabled;
    setSoundEnabled(!soundEnabled);
  };

  const handleUpdateProfile = (updated: UserProfileData) => {
    setProfile(updated);
    saveUserProfile(updated);
  };

  const handleClaimCoinsBonus = () => {
    sounds.playChip();
    const bonus = 500;
    const updated = { ...profile, chips: profile.chips + bonus };
    handleUpdateProfile(updated);
    confetti({ particleCount: 60, spread: 50 });
  };

  const handleSelectGame = (mode: GameMode, variant?: string) => {
    setActiveGame(mode);
    if (variant) setActiveVariant(variant);
    setIsPassAndPlay(false);
    setActiveView('game');
  };

  const handleStartPassAndPlay = (game: 'durak' | 'ochko') => {
    setActiveGame(game);
    setIsPassAndPlay(true);
    setActiveView('game');
  };

  const handleStartRoomGame = (room: MultiplayerRoom) => {
    setActiveGame(room.gameType);
    setIsPassAndPlay(false);
    setActiveView('game');
  };

  // Helper to add XP and check level-up progression (1 to 100)
  const addXpAndProgression = (baseXp: number, chipsEarned: number, gameType: 'durak' | 'ochko' | 'solitaire' | 'ming') => {
    const isVip = (profile.vipExpiresAt || 0) > Date.now();
    const finalXp = isVip ? baseXp * 2 : baseXp;
    let currentXp = (profile.xp || 0) + finalXp;
    let currentLvl = profile.level || 1;

    // Check if user reached next level(s)
    let leveledUp = false;
    while (currentLvl < 100) {
      const nextLvlConfig = LEVEL_ROADMAP[currentLvl]; // index currentLvl = level (currentLvl + 1)
      if (nextLvlConfig && currentXp >= nextLvlConfig.xpRequired) {
        currentLvl += 1;
        leveledUp = true;
      } else {
        break;
      }
    }

    if (leveledUp) {
      sounds.playWin();
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    }

    const updated: UserProfileData = {
      ...profile,
      chips: profile.chips + chipsEarned,
      xp: currentXp,
      level: currentLvl,
      durakWins: (gameType === 'durak' || gameType === 'ming') ? profile.durakWins + 1 : profile.durakWins,
      ochkoWins: gameType === 'ochko' ? profile.ochkoWins + 1 : profile.ochkoWins,
      solitaireWins: gameType === 'solitaire' ? profile.solitaireWins + 1 : profile.solitaireWins,
    };
    handleUpdateProfile(updated);
  };

  // Win / Loss handlers
  const handleDurakWin = (reward: number) => {
    addXpAndProgression(120, reward, 'durak');
  };

  const handleDurakLose = () => {
    const updated = {
      ...profile,
      durakLosses: profile.durakLosses + 1,
    };
    handleUpdateProfile(updated);
  };

  const handleMingWin = (reward: number) => {
    addXpAndProgression(200, reward, 'ming');
  };

  const handleMingLose = () => {
    const updated = {
      ...profile,
      durakLosses: profile.durakLosses + 1,
    };
    handleUpdateProfile(updated);
  };

  const handleUpdateChips = (newChips: number) => {
    const chipsDelta = newChips - profile.chips;
    if (chipsDelta > 0) {
      addXpAndProgression(80, chipsDelta, 'ochko');
    } else {
      const updated = {
        ...profile,
        chips: newChips,
        ochkoLosses: chipsDelta < 0 ? profile.ochkoLosses + 1 : profile.ochkoLosses,
      };
      handleUpdateProfile(updated);
    }
  };

  const handleSolitaireWin = (reward: number) => {
    addXpAndProgression(100, reward, 'solitaire');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* 3D Intro Animation */}
      {showSplash && <Splash3D onComplete={() => setShowSplash(false)} />}

      {/* Header: Top-Left Profile, Center Play navigation, Top-Right Coins */}
      <Header
        profile={profile}
        activeView={activeView}
        onNavigate={(view) => {
          if (view === 'friends') setIsFriendsOpen(true);
          else if (view === 'leaderboard') setIsLeaderboardOpen(true);
          else setActiveView('catalog');
        }}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenRules={() => setIsRulesOpen(true)}
        onClaimCoinsBonus={handleClaimCoinsBonus}
        onOpenLevelRoadmap={() => setIsLevelRoadmapOpen(true)}
        onOpenLuckyWheel={() => setIsLuckyWheelOpen(true)}
        soundEnabled={soundEnabled}
        onToggleSound={toggleSound}
      />

      {/* Main App Body */}
      <main className="flex-1 w-full max-w-7xl mx-auto p-3 sm:p-6 flex flex-col">
        {activeView === 'catalog' ? (
          <div className="space-y-6">
            <GameCatalog
              onSelectGame={handleSelectGame}
              onOpenFriends={() => setIsFriendsOpen(true)}
              onOpenLeaderboard={() => setIsLeaderboardOpen(true)}
              onOpenLevelRoadmap={() => setIsLevelRoadmapOpen(true)}
              onOpenLuckyWheel={() => setIsLuckyWheelOpen(true)}
              level={profile.level}
              spinTickets={profile.spinTickets}
            />
          </div>
        ) : (
          /* Active Playing Arena */
          <div className="w-full space-y-4">
            {/* Back button and Current Game Title */}
            <div className="flex items-center justify-between border-b border-slate-900 pb-3">
              <button
                onClick={() => {
                  sounds.playChip();
                  setActiveView('catalog');
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-xs font-bold text-slate-300 border border-slate-800 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>O'yinlar Ro'yxatiga Qaytish</span>
              </button>

              <div className="text-right">
                <span className="text-sm font-bold font-serif text-amber-300 block">
                  {activeGame === 'ming' && '1000 (Ming / Тысяча)'}
                  {activeGame === 'durak' && (activeVariant === 'perevodnoy' ? 'Durak (O\'tkazma / Perevodnoy)' : activeVariant === 'devyatka' ? 'To\'qqizlik (Devyatka 9)' : 'Durak (Podkidnoy)')}
                  {activeGame === 'ochko' && (activeVariant === 'seka' ? 'Seka (3 Karta)' : activeVariant === 'bura' ? 'Bura / 31 (Ochko)' : '21 Ochko (Blackjack)')}
                  {activeGame === 'solitaire' && (activeVariant === 'spider' ? 'Pauk (Spider) Pas\'yans' : 'Klondike Pas\'yans')}
                </span>
                <span className="text-[11px] text-slate-400 font-mono">
                  {activeGame === 'ming' ? 'Alisher va Jasurga qarshi (3 O\'yinchi)' : isPassAndPlay ? '2 O\'yinchi (Pass & Play)' : 'Bot Alisherga qarshi'}
                </span>
              </div>
            </div>

            {/* Game Screen */}
            {activeGame === 'ming' && (
              <MingGame
                onWin={handleMingWin}
                onLose={handleMingLose}
                tableTheme={tableTheme}
                cardBackTheme={cardBackTheme}
                characterCustom={characterCustom}
                onExit={() => setActiveView('catalog')}
              />
            )}
            {activeGame === 'durak' && (
              <DurakGame
                onWin={handleDurakWin}
                onLose={handleDurakLose}
                isPassAndPlay={isPassAndPlay}
                variant={activeVariant}
                tableTheme={tableTheme}
                cardBackTheme={cardBackTheme}
                characterCustom={characterCustom}
                onExit={() => setActiveView('catalog')}
              />
            )}
            {activeGame === 'ochko' && (
              <OchkoGame
                chips={profile.chips}
                onUpdateChips={handleUpdateChips}
                variant={activeVariant}
                tableTheme={tableTheme}
                cardBackTheme={cardBackTheme}
                characterCustom={characterCustom}
                onExit={() => setActiveView('catalog')}
              />
            )}
            {activeGame === 'solitaire' && (
              <SolitaireGame
                onWin={handleSolitaireWin}
                variant={activeVariant}
                tableTheme={tableTheme}
                cardBackTheme={cardBackTheme}
                onExit={() => setActiveView('catalog')}
              />
            )}
          </div>
        )}
      </main>

      {/* Save Progress Banner (Matching user screenshot) */}
      <SaveProgressBanner onOpenLoginOrProfile={() => setIsProfileOpen(true)} />

      {/* Profile Modal */}
      <ProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        profile={profile}
        onUpdateProfile={handleUpdateProfile}
        tableTheme={tableTheme}
        onChangeTableTheme={(t) => {
          setTableTheme(t);
          localStorage.setItem('grand_table_theme', t);
        }}
        cardBackTheme={cardBackTheme}
        onChangeCardBackTheme={(cb) => {
          setCardBackTheme(cb);
          localStorage.setItem('grand_card_back', cb);
        }}
        onOpenAvatarStudio={() => setIsAvatarStudioOpen(true)}
      />

      {/* 3D Avatar Studio & Wardrobe Shop Modal */}
      <AvatarStudioModal
        isOpen={isAvatarStudioOpen}
        onClose={() => setIsAvatarStudioOpen(false)}
        profile={profile}
        onUpdateProfile={handleUpdateProfile}
        currentCustomization={characterCustom}
        onSaveCustomization={(custom) => setCharacterCustom(custom)}
      />

      {/* Friends Multiplayer Modal */}
      <FriendsMultiplayerModal
        isOpen={isFriendsOpen}
        onClose={() => setIsFriendsOpen(false)}
        currentUser={profile}
        onStartRoomGame={handleStartRoomGame}
        onStartPassAndPlay={handleStartPassAndPlay}
      />

      {/* Leaderboard Modal */}
      <LeaderboardModal
        isOpen={isLeaderboardOpen}
        onClose={() => setIsLeaderboardOpen(false)}
        currentUser={profile}
      />

      {/* 100 LVL Chempionlik Yo'li Modal */}
      <LevelRoadmapModal
        isOpen={isLevelRoadmapOpen}
        onClose={() => setIsLevelRoadmapOpen(false)}
        profile={profile}
        onUpdateProfile={handleUpdateProfile}
        onOpenLuckyWheel={() => setIsLuckyWheelOpen(true)}
      />

      {/* Omad G'ildiragi (Lucky Spin) Modal */}
      <LuckyWheelModal
        isOpen={isLuckyWheelOpen}
        onClose={() => setIsLuckyWheelOpen(false)}
        profile={profile}
        onUpdateProfile={handleUpdateProfile}
      />

      {/* Rules Modal */}
      <RulesModal
        isOpen={isRulesOpen}
        onClose={() => setIsRulesOpen(false)}
        defaultMode={activeGame}
      />

      {/* Footer */}
      <footer className="w-full border-t border-slate-900 bg-slate-950 py-3.5 px-6 text-center text-xs text-slate-500">
        <p>Grand Karta Klubi — Durak, 21 Ochko, Pas'yans va Do'stlar bilan onlayn xonalar.</p>
      </footer>
    </div>
  );
}
